// Local-only demo API. Data is stored in this browser and never sent to a server.
const KEY = 'citytransit-demo-database-v1'
const roles = ['Administrator','Transport Manager','Dispatcher','Driver','Booking Clerk','Passenger','Auditor/Viewer']
const iso = n => {
  const d = new Date()
  d.setDate(d.getDate() + n)
  const local = new Date(d.getTime() - d.getTimezoneOffset() * 60000)
  return local.toISOString().slice(0, 10)
}
const seed = () => {
  const stops = [
    {id:1,stop_code:'ST-001',name:'Miyapur Metro',area:'Miyapur',active:true},
    {id:2,stop_code:'ST-002',name:'Kukatpally',area:'Kukatpally',active:true},
    {id:3,stop_code:'ST-003',name:'Ameerpet',area:'Ameerpet',active:true},
    {id:4,stop_code:'ST-004',name:'Secunderabad Station',area:'Secunderabad',active:true},
    {id:5,stop_code:'ST-005',name:'Mehdipatnam',area:'Mehdipatnam',active:true},
    {id:6,stop_code:'ST-006',name:'RGIA Airport',area:'Shamshabad',active:true},
    {id:7,stop_code:'ST-007',name:'Gachibowli',area:'Gachibowli',active:true},
    {id:8,stop_code:'ST-008',name:'LB Nagar',area:'LB Nagar',active:true},
  ]
  const routes = [
    {id:1,route_code:'CT-101',name:'Miyapur – Airport Express',origin:'Miyapur',destination:'Airport',distance_note:'38 km',active:true,stops_count:4},
    {id:2,route_code:'CT-102',name:'Secunderabad – Mehdipatnam',origin:'Secunderabad',destination:'Mehdipatnam',distance_note:'19 km',active:true,stops_count:4},
    {id:3,route_code:'CT-103',name:'Kukatpally – Gachibowli',origin:'Kukatpally',destination:'Gachibowli',distance_note:'16 km',active:true,stops_count:3},
    {id:4,route_code:'CT-104',name:'LB Nagar – Airport',origin:'LB Nagar',destination:'Airport',distance_note:'27 km',active:true,stops_count:3},
  ]
  const routeStops = {
    1:[{id:1,stop_id:1,sequence:1,estimated_offset_min:0,stop:stops[0]},{id:2,stop_id:2,sequence:2,estimated_offset_min:12,stop:stops[1]},{id:3,stop_id:3,sequence:3,estimated_offset_min:25,stop:stops[2]},{id:4,stop_id:6,sequence:4,estimated_offset_min:55,stop:stops[5]}],
    2:[{id:5,stop_id:4,sequence:1,estimated_offset_min:0,stop:stops[3]},{id:6,stop_id:3,sequence:2,estimated_offset_min:15,stop:stops[2]},{id:7,stop_id:5,sequence:3,estimated_offset_min:32,stop:stops[4]}],
    3:[{id:8,stop_id:2,sequence:1,estimated_offset_min:0,stop:stops[1]},{id:9,stop_id:7,sequence:2,estimated_offset_min:25,stop:stops[6]}],
    4:[{id:10,stop_id:8,sequence:1,estimated_offset_min:0,stop:stops[7]},{id:11,stop_id:6,sequence:2,estimated_offset_min:40,stop:stops[5]}],
  }
  const buses = [
    {id:1,bus_no:'TS-09-UB-1001',registration_demo:'DEMO-1001',bus_type:'AC Seater',capacity:40,status:'Available'},
    {id:2,bus_no:'TS-09-UB-1002',registration_demo:'DEMO-1002',bus_type:'Electric',capacity:32,status:'Assigned'},
    {id:3,bus_no:'TS-09-UB-1003',registration_demo:'DEMO-1003',bus_type:'Non-AC',capacity:45,status:'Available'},
    {id:4,bus_no:'TS-09-UB-1004',registration_demo:'DEMO-1004',bus_type:'Mini Bus',capacity:24,status:'Maintenance'},
    {id:5,bus_no:'TS-09-UB-1005',registration_demo:'DEMO-1005',bus_type:'AC Seater',capacity:40,status:'Available'},
  ]
  const drivers = [
    {id:1,employee_code:'DRV-001',name:'Ravi Kumar',license_demo:'DL-DEMO-001',contact_demo:'9000000101',status:'Available',active:true},
    {id:2,employee_code:'DRV-002',name:'Suresh Reddy',license_demo:'DL-DEMO-002',contact_demo:'9000000102',status:'Assigned',active:true},
    {id:3,employee_code:'DRV-003',name:'Anil Sharma',license_demo:'DL-DEMO-003',contact_demo:'9000000103',status:'Available',active:true},
    {id:4,employee_code:'DRV-004',name:'Kiran Rao',license_demo:'DL-DEMO-004',contact_demo:'9000000104',status:'On Leave',active:true},
  ]
  const users = roles.map((name,i)=>({id:i+1,name:['Mahender Demo','Priya Manager','Arjun Dispatcher','Ravi Driver','Sita Clerk','Demo Passenger','Audit Viewer'][i],email:['admin@citytransit.demo','manager@citytransit.demo','dispatcher@citytransit.demo','driver1@citytransit.demo','clerk@citytransit.demo','passenger@citytransit.demo','auditor@citytransit.demo'][i],active:true,role_id:i+1,role:{id:i+1,name}}))
  const schedules = [
    {id:1,route_id:1,route:routes[0],departure_time:'08:00:00',duration_min:60,fare:120,service_rule:'Daily',published:true},
    {id:2,route_id:2,route:routes[1],departure_time:'09:15:00',duration_min:40,fare:55,service_rule:'Daily',published:true},
    {id:3,route_id:3,route:routes[2],departure_time:'10:30:00',duration_min:35,fare:45,service_rule:'Weekdays',published:true},
    {id:4,route_id:4,route:routes[3],departure_time:'17:00:00',duration_min:50,fare:85,service_rule:'Daily',published:true},
  ]
  const trips = Array.from({length:8},(_,i)=>{
    const sch=schedules[i%4], route=sch.route, bus=buses[i%3], driver=drivers[i%3]
    const date=iso(i<4?0:1), time=sch.departure_time
    const dep=new Date(`${date}T${time}`).toISOString()
    return {id:i+1,trip_no:`TR-${String(2601+i).padStart(4,'0')}`,service_date:date,departure_at:dep,estimated_arrival_at:new Date(new Date(dep).getTime()+sch.duration_min*60000).toISOString(),status:['Scheduled','Assigned','Boarding','In Progress','Completed','Delayed','Scheduled','Assigned'][i],schedule:{...sch,route:{...route,route_stops:routeStops[route.id]}},schedule_id:sch.id,bus_id:bus.id,driver_id:driver.id,bus,driver,available_seats:bus.capacity-[8,14,21,5,31,12,2,18][i],passenger_count:[8,14,21,5,31,12,2,18][i],fare_snapshot:sch.fare}
  })
  const bookings = [
    {id:1,booking_ref:'CTB-2026-0001',passenger_name:'Aarav Mehta',contact_demo:'9000000201',quantity:2,total_fare:240,payment_status_demo:'Paid (Demo)',status:'Confirmed',trip:tripSummary(trips[0])},
    {id:2,booking_ref:'CTB-2026-0002',passenger_name:'Diya Reddy',contact_demo:'9000000202',quantity:1,total_fare:55,payment_status_demo:'Paid (Demo)',status:'Confirmed',trip:tripSummary(trips[1])},
    {id:3,booking_ref:'CTB-2026-0003',passenger_name:'Vikram Rao',contact_demo:'9000000203',quantity:3,total_fare:135,payment_status_demo:'Paid (Demo)',status:'Confirmed',trip:tripSummary(trips[2])},
    {id:4,booking_ref:'CTB-2026-0004',passenger_name:'Neha Sharma',contact_demo:'9000000204',quantity:1,total_fare:85,payment_status_demo:'Paid (Demo)',status:'Cancelled',trip:tripSummary(trips[3])},
  ]
  return {stops,routes,routeStops,buses,drivers,users,schedules,trips,bookings,events:[],fareRules:[{id:1,route_id:1,fare_amount:120,effective_date:iso(0),active:true}],nextId:100}
}
function tripSummary(t){return {id:t.id,trip_no:t.trip_no,service_date:t.service_date,departure_at:t.departure_at,status:t.status,origin:t.schedule.route.origin,destination:t.schedule.route.destination,route_name:t.schedule.route.name,bus_no:t.bus.bus_no}}
let db
function load() {
  if (db) return db

  try {
    db = JSON.parse(localStorage.getItem(KEY))
  } catch {
    db = null
  }

  if (!db) {
    db = seed()
    return db
  }

  // Keep the four seeded demo bookings aligned with the dashboard's local "Today" date.
  // This also repairs demo data already saved in localStorage before this fix.
  const currentDate = iso(0)
  const seededTrips = (db.trips || []).filter(trip =>
    [1, 2, 3, 4].includes(Number(trip.id))
  )

  const needsDateSync = seededTrips.length === 4 && (
    seededTrips.some(trip => trip.service_date !== currentDate) ||
    (db.bookings || []).some(booking =>
      seededTrips.some(trip =>
        Number(trip.id) === Number(booking.trip?.id)
      ) && booking.trip?.service_date !== currentDate
    )
  )

  if (needsDateSync) {
    seededTrips.forEach(trip => {
      trip.service_date = currentDate
      const time = trip.schedule?.departure_time || '08:00:00'
      const departure = new Date(currentDate + 'T' + time)
      trip.departure_at = departure.toISOString()
      trip.estimated_arrival_at = new Date(
        departure.getTime() +
        (Number(trip.schedule?.duration_min) || 60) * 60000
      ).toISOString()
    })

    const tripMap = new Map(
      seededTrips.map(trip => [Number(trip.id), trip])
    )

    ;(db.bookings || []).forEach(booking => {
      const trip = tripMap.get(Number(booking.trip?.id))
      if (trip) {
        booking.trip = {
          ...booking.trip,
          service_date: trip.service_date,
          departure_at: trip.departure_at
        }
      }
    })

    localStorage.setItem(KEY, JSON.stringify(db))
  }

  return db
}
function save(){localStorage.setItem(KEY,JSON.stringify(db))}
const clone=x=>JSON.parse(JSON.stringify(x))
const ok=data=>Promise.resolve({data:clone(data),status:200})
const paged=(items,params={})=>({items:items.slice(0,Number(params.size)||items.length),total:items.length,page:1,size:Number(params.size)||items.length})
function fail(message){const e=new Error(message);e.response={data:{error:{message}}};throw e}
function byId(list,id){return list.find(x=>x.id===Number(id))}
function get(path,params={}) {
 const d=load(), p=path.replace(/^\/api/,'').split('?')[0]
 if(p==='/auth/me'){const id=Number(localStorage.getItem('citytransit-demo-user')||1);return ok(byId(d.users,id))}
 if(p==='/dashboard/summary') {const target=params.target_date;const trips=target?d.trips.filter(t=>t.service_date===target):d.trips;const bookings=d.bookings.filter(b=>b.status==='Confirmed'&&(!target||b.trip?.service_date===target));return ok({scheduled_trips:trips.length,completed_trips:trips.filter(t=>t.status==='Completed').length,delayed_trips:trips.filter(t=>t.status==='Delayed').length,cancelled_trips:trips.filter(t=>t.status==='Cancelled').length,available_buses:d.buses.filter(b=>b.status==='Available').length,total_buses:d.buses.length,maintenance_buses:d.buses.filter(b=>b.status==='Maintenance').length,available_drivers:d.drivers.filter(x=>x.status==='Available').length,total_drivers:d.drivers.length,unassigned_trips:trips.filter(t=>!t.bus_id||!t.driver_id).length,total_bookings:bookings.length,total_passengers_booked:bookings.reduce((a,b)=>a+b.quantity,0),revenue_demo:bookings.reduce((a,b)=>a+b.total_fare,0),bookings_by_route:d.routes.map(r=>({route_code:r.route_code,booking_count:bookings.filter(b=>b.trip?.route_name===r.name).length,seats_booked:bookings.filter(b=>b.trip?.route_name===r.name).reduce((a,b)=>a+b.quantity,0)}))})}
 if(p==='/users/roles')return ok(roles.map((name,i)=>({id:i+1,name})))
 if(p==='/users')return ok(paged(d.users,params))
 if(p==='/buses')return ok(paged(d.buses,params))
 if(p==='/drivers')return ok(paged(d.drivers,params))
 if(p==='/routes')return ok(paged(d.routes.map(r=>({...r,stops_count:d.routeStops[r.id]?.length||r.stops_count})),params))
 if(p==='/stops')return ok(paged(d.stops.filter(x=>params.active===undefined||String(x.active)===String(params.active)),params))
 if(p==='/schedules')return ok(paged(d.schedules,params))
 if(p==='/fare-rules')return ok(d.fareRules)
 if(p.startsWith('/fare-rules/'))return ok(byId(d.fareRules,p.split('/')[2])||{})
 if(p==='/trips')return ok(paged(d.trips,params))
 if(p==='/public/trips/search') {let ts=d.trips.filter(t=>t.status!=='Cancelled');if(params.origin)ts=ts.filter(t=>t.schedule.route.origin.toLowerCase().includes(params.origin.toLowerCase()));if(params.destination)ts=ts.filter(t=>t.schedule.route.destination.toLowerCase().includes(params.destination.toLowerCase()));if(params.service_date)ts=ts.filter(t=>t.service_date===params.service_date);return ok(ts)}
 if(p==='/bookings'||p==='/bookings/me')return ok(paged(d.bookings.map(b=>({...b,trip:{...b.trip,origin:b.trip?.origin,destination:b.trip?.destination}})),params))
 if(p.startsWith('/reports/')) {const key=p.split('/').pop();const ts=d.trips; if(key==='trips')return ok(ts.map(t=>({trip_id:t.id,trip_no:t.trip_no,service_date:t.service_date,route_id:t.schedule.route.id,route_name:t.schedule.route.name,bus_id:t.bus_id,bus_no:t.bus?.bus_no,driver_id:t.driver_id,driver_name:t.driver?.name,departure_at:t.departure_at,booked_seats:t.passenger_count,passenger_count:t.passenger_count,delay_category:t.status==='Delayed'?'Traffic':'—',status:t.status})));if(key==='route-schedules')return ok(d.schedules.map(s=>({route_code:s.route.route_code,route_name:s.route.name,stop_sequence:d.routeStops[s.route_id]?.length,departure_time:s.departure_time,fare:s.fare,published:s.published,active:true})));if(key==='bookings')return ok(d.bookings.map(b=>({booking_ref:b.booking_ref,service_date:b.trip.service_date,trip_id:b.trip.id,trip_no:b.trip.trip_no,route_id:d.trips.find(t=>t.id===b.trip.id)?.schedule.route.id,route_name:b.trip.route_name,passenger_name:b.passenger_name,quantity:b.quantity,total_fare:b.total_fare,payment_status_demo:b.payment_status_demo,status:b.status})));if(key==='bus-utilization')return ok(d.buses.flatMap(b=>[...new Set(d.trips.filter(t=>t.bus_id===b.id).map(t=>t.service_date))].map(date=>{const assigned=d.trips.filter(t=>t.bus_id===b.id&&t.service_date===date);const seats=assigned.reduce((a,t)=>a+t.passenger_count,0);return {bus_id:b.id,bus_no:b.bus_no,bus_type:b.bus_type,capacity:b.capacity,service_date:date,trips_assigned:assigned.length,booked_seats:seats,total_passengers_carried:assigned.filter(t=>t.status==='Completed').reduce((a,t)=>a+t.passenger_count,0),utilization_percent:Math.min(100,Math.round(seats/Math.max(1,b.capacity*assigned.length)*100))}})));if(key==='driver-assignments')return ok(d.drivers.map(x=>({employee_code:x.employee_code,driver_name:x.name,service_date:iso(0),trips_assigned:d.trips.filter(t=>t.driver_id===x.id).length,trip_numbers:d.trips.filter(t=>t.driver_id===x.id).map(t=>t.trip_no).join(', '),driver_status:x.status})));return ok([])}
 if(p==='/audit-logs')return ok([])
 const m=p.match(/^\/(buses|drivers|routes|stops|schedules|trips|bookings|users)\/(\d+)(?:\/(.*))?$/)
 if(m){const [,type,id,sub]=m;const item=byId(d[type],id);if(sub==='assignments')return ok([]);if(type==='routes'&&sub==='stops')return ok(d.routeStops[id]||[]);if(type==='trips'&&sub==='events')return ok(d.events.filter(e=>e.trip_id===Number(id)));if(type==='trips'&&sub==='bookings')return ok(d.bookings.filter(b=>b.trip?.id===Number(id)));if(type==='trips')return ok(item);return ok(item||{})}
 return ok([])
}
function write(method,path,body={}) {
 const d=load(), p=path.replace(/^\/api/,'')
 if(p==='/auth/login'||p==='/auth/register'){let u=d.users.find(x=>x.email===body.email);if(!u&&p.endsWith('register')){u={id:++d.nextId,name:body.name,email:body.email,active:true,role_id:6,role:{id:6,name:'Passenger'},contact_demo:body.contact_demo};d.users.push(u)}if(!u)fail('Demo account not found. Choose one of the demo roles.');localStorage.setItem('citytransit-demo-user',String(u.id));return ok({access_token:'citytransit-local-demo-token',user:u})}
 if(p==='/auth/logout')return ok({ok:true})
 if(p==='/bookings'){const t=byId(d.trips,body.trip_id);if(!t)fail('Trip not found');const qty=Number(body.quantity)||1;if(qty>t.available_seats)fail('Not enough seats available');t.available_seats-=qty;t.passenger_count+=qty;const b={id:++d.nextId,booking_ref:`CTB-DEMO-${String(d.nextId).padStart(4,'0')}`,passenger_name:body.passenger_name,contact_demo:body.contact_demo,quantity:qty,total_fare:qty*t.fare_snapshot,payment_status_demo:'Paid (Demo)',status:'Confirmed',trip:tripSummary(t)};d.bookings.unshift(b);save();return ok(b)}
 if(p==='/fare-rules'){const item={id:++d.nextId,...body};d.fareRules.push(item);save();return ok(item)}
 if(p.startsWith('/fare-rules/')&&method==='patch'){const item=byId(d.fareRules,p.split('/')[2]);Object.assign(item,body);save();return ok(item)}
 if(p.startsWith('/schedules/')&&p.endsWith('/generate-trips')){save();return ok({created_count:(body.service_dates||[]).length})}
 if(p.startsWith('/trips/')&&p.endsWith('/assignment')){const id=p.split('/')[2],t=byId(d.trips,id);t.bus_id=body.bus_id;t.driver_id=body.driver_id;t.bus=byId(d.buses,body.bus_id);t.driver=byId(d.drivers,body.driver_id);t.status='Assigned';save();return ok(t)}
 if(p.startsWith('/trips/')&&p.endsWith('/status')){const t=byId(d.trips,p.split('/')[2]);t.status=body.status;save();return ok(t)}
 if(p.startsWith('/trips/')&&p.endsWith('/events')){const e={id:++d.nextId,trip_id:Number(p.split('/')[2]),...body,created_at:new Date().toISOString()};d.events.push(e);const t=byId(d.trips,e.trip_id);if(body.event_type==='departure')t.status='In Progress';if(body.event_type==='arrival')t.status='Completed';if(body.event_type==='delay')t.status='Delayed';if(body.passenger_count!==null&&body.passenger_count!==undefined)t.passenger_count=body.passenger_count;save();return ok(e)}
 if(p.startsWith('/bookings/')&&p.endsWith('/cancel')){const b=byId(d.bookings,p.split('/')[2]);b.status='Cancelled';b.cancel_reason=body.reason;save();return ok(b)}
 if(p.startsWith('/bookings/')&&p.endsWith('/status')){const b=byId(d.bookings,p.split('/')[2]);b.status=body.status;save();return ok(b)}
 if(p.startsWith('/routes/')&&p.endsWith('/stops')){const id=p.split('/')[2];d.routeStops[id]=body.map((x,i)=>({...x,id:i+1,stop:byId(d.stops,x.stop_id)}));save();return ok(d.routeStops[id])}
 // Permanent demo deletion with referential-integrity checks.
 const deleteMatch = p.match(/^\/(buses|drivers|routes|stops|schedules|trips|bookings|users)\/(\d+)$/)
 if (method === 'delete' && deleteMatch) {
   const [, type, rawId] = deleteMatch
   const id = Number(rawId)
   const list = d[type]
   const item = byId(list, id)
   if (!item) fail(`${type.slice(0, -1)} was not found.`)

   if (type === 'buses' && d.trips.some(t => Number(t.bus_id) === id))
     fail('This bus is assigned to one or more trips. Reassign those trips before deleting the bus.')
   // A driver can be deleted even when assigned. Preserve every trip, but
   // clear this driver's assignment references before removing the profile.
   if (type === 'drivers') {
     d.trips.forEach(trip => {
       if (Number(trip.driver_id) === id) {
         trip.driver_id = null
         trip.driver = null
         if (trip.status === 'Assigned') trip.status = 'Scheduled'
       }
     })
   }
   if (type === 'routes' && (d.schedules.some(x => Number(x.route_id) === id) || d.fareRules.some(x => Number(x.route_id) === id) || d.trips.some(t => Number(t.schedule?.route?.id) === id)))
     fail('This route is linked to schedules, trips, or fare rules. Remove or reassign those records before deleting the route.')
   if (type === 'stops' && Object.values(d.routeStops).some(items => items.some(x => Number(x.stop_id) === id)))
     fail('This stop is part of one or more routes. Remove it from the route stop lists before deleting the stop.')
   if (type === 'schedules' && d.trips.some(t => Number(t.schedule_id) === id))
     fail('This schedule has generated trips. Delete or reassign its trips before deleting the schedule.')
   if (type === 'trips' && d.bookings.some(b => Number(b.trip?.id) === id))
     fail('This trip has bookings. Delete or cancel its bookings before deleting the trip.')
   if (type === 'trips' && d.events.some(e => Number(e.trip_id) === id))
     fail('This trip has operational events. Its history must be retained, so it cannot be deleted.')
   if (type === 'users' && Number(localStorage.getItem('citytransit-demo-user') || 1) === id)
     fail('You cannot delete the account currently signed in. Sign in with another administrator first.')

   if (type === 'bookings' && item.status === 'Confirmed') {
     const trip = byId(d.trips, item.trip?.id)
     if (trip) {
       trip.available_seats = Math.min(Number(trip.bus?.capacity || trip.available_seats + item.quantity), Number(trip.available_seats || 0) + Number(item.quantity || 0))
       trip.passenger_count = Math.max(0, Number(trip.passenger_count || 0) - Number(item.quantity || 0))
     }
   }
   if (type === 'routes') delete d.routeStops[id]
   const index = list.findIndex(x => x.id === id)
   list.splice(index, 1)
   save()
   return ok({ ok: true, deleted_id: id, type })
 }
 const match=p.match(/^\/(buses|drivers|routes|stops|schedules|users)\/?(\d+)?$/)
 if(match){const [,type,id]=match,list=d[type];if(method==='post'){const item={id:++d.nextId,...body};if(type==='routes')item.stops_count=0;if(type==='schedules'){item.route=byId(d.routes,item.route_id)}if(type==='users'){item.role={id:item.role_id,name:roles[item.role_id-1]}}list.push(item);save();return ok(item)}if(method==='patch'&&id){const item=byId(list,id);Object.assign(item,body);if(type==='schedules')item.route=byId(d.routes,item.route_id);if(type==='users'&&body.role_id)item.role={id:item.role_id,name:roles[item.role_id-1]};save();return ok(item)}}
 save();return ok({ok:true})
}
export const mockApi = {
 get: async (url,config={})=>get(url,config.params||{}),
 post: async (url,body,config)=>write('post',url,body),
 patch: async (url,body)=>write('patch',url,body),
 put: async (url,body)=>write('put',url,body),
 delete: async url=>write('delete',url),
}
