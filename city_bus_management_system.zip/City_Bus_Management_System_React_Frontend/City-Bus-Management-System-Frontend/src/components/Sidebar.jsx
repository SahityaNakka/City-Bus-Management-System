import { NavLink } from 'react-router-dom'
import { ROLES, useAuth } from '../context/AuthContext'

const STAFF = [ROLES.ADMIN, ROLES.MANAGER, ROLES.DISPATCHER, ROLES.DRIVER, ROLES.CLERK, ROLES.AUDITOR]

const MENU_GROUPS = [
  {
    title: 'OVERVIEW',
    items: [{ to: '/', label: 'Dashboard', icon: 'bi-grid-1x2-fill', roles: STAFF }],
  },
  {
    title: 'FLEET & OPERATIONS',
    items: [
      { to: '/buses', label: 'Bus Management', icon: 'bi-bus-front', roles: [ROLES.ADMIN, ROLES.MANAGER, ROLES.DISPATCHER, ROLES.AUDITOR] },
      { to: '/drivers', label: 'Drivers', icon: 'bi-person-badge', roles: [ROLES.ADMIN, ROLES.MANAGER, ROLES.DISPATCHER, ROLES.AUDITOR] },
      { to: '/routes', label: 'Routes', icon: 'bi-signpost-2', roles: [ROLES.ADMIN, ROLES.MANAGER, ROLES.DISPATCHER, ROLES.AUDITOR] },
      { to: '/stops', label: 'Bus Stops', icon: 'bi-geo-alt', roles: [ROLES.ADMIN, ROLES.MANAGER, ROLES.DISPATCHER] },
      { to: '/schedules', label: 'Schedules', icon: 'bi-calendar-week', roles: [ROLES.ADMIN, ROLES.MANAGER, ROLES.DISPATCHER, ROLES.AUDITOR] },
      { to: '/trips', label: 'Trip Operations', icon: 'bi-map', roles: [ROLES.ADMIN, ROLES.MANAGER, ROLES.DISPATCHER, ROLES.DRIVER, ROLES.AUDITOR] },
    ],
  },
  {
    title: 'PASSENGERS',
    items: [
      { to: '/search-trips', label: 'Search Trips', icon: 'bi-search', roles: [ROLES.PASSENGER, ROLES.CLERK, ROLES.ADMIN, ROLES.MANAGER] },
      { to: '/bookings', label: 'Bookings', icon: 'bi-ticket-perforated', roles: [ROLES.PASSENGER, ROLES.CLERK, ROLES.ADMIN, ROLES.MANAGER, ROLES.DISPATCHER] },
    ],
  },
  {
    title: 'ADMINISTRATION',
    items: [
      { to: '/reports', label: 'Reports & Audit', icon: 'bi-bar-chart', roles: [ROLES.ADMIN, ROLES.MANAGER, ROLES.DISPATCHER, ROLES.CLERK, ROLES.AUDITOR] },
      { to: '/users', label: 'User Management', icon: 'bi-people', roles: [ROLES.ADMIN] },
    ],
  },
]

export default function Sidebar({ open, onNavigate }) {
  const { hasRole, roleName } = useAuth()

  return (
    <aside className={`sidebar ${open ? 'sidebar-open' : ''}`}>
      <div className="brand">
        <div className="brand-mark"><i className="bi bi-bus-front-fill" /></div>
        <div>
          <div className="brand-name">CityTransit</div>
          <div className="brand-caption">MANAGEMENT PORTAL</div>
        </div>
      </div>

      <div className="sidebar-role-card">
        <small>Active Role</small>
        <strong>{roleName || 'Guest'}</strong>
      </div>

      <div className="sidebar-scroll">
        {MENU_GROUPS.map(group => {
          const items = group.items.filter(item => hasRole(item.roles))
          if (!items.length) return null
          return (
            <div className="nav-group" key={group.title}>
              <div className="nav-heading">{group.title}</div>
              {items.map(item => (
                <NavLink
                  key={item.to}
                  to={item.to}
                  end={item.to === '/'}
                  onClick={onNavigate}
                  className={({ isActive }) => `side-link ${isActive ? 'active' : ''}`}
                >
                  <i className={`bi ${item.icon}`} />
                  <span>{item.label}</span>
                </NavLink>
              ))}
            </div>
          )
        })}
      </div>

      <div className="sidebar-foot">
        <span><span className="online-dot" /> React UI + FastAPI</span>
        <a
          href="/docs"
          target="_blank"
          rel="noreferrer"
          className="version"
          style={{ textDecoration: 'none' }}
          title="Open FastAPI Swagger API Docs"
        >
          API Docs
        </a>
      </div>
    </aside>
  )
}
