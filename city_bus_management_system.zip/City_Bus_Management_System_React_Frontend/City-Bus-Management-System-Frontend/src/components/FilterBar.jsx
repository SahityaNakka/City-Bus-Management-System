export default function FilterBar({ children, onReset, extraAction }) {
  return (
    <div className="content-card mb-3" style={{ padding: '14px 18px' }}>
      <div className="d-flex flex-wrap align-items-end gap-3">
        {children}
        <div className="d-flex gap-2 ms-auto">
          {extraAction}
          {onReset && (
            <button type="button" className="btn btn-light btn-sm" onClick={onReset}>
              <i className="bi bi-arrow-counterclockwise me-1" />Reset Filters
            </button>
          )}
        </div>
      </div>
    </div>
  )
}
