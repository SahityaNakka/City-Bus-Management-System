import { useEffect, useMemo, useState } from 'react'
import Pagination from './Pagination'

export default function DataTable({
  columns,
  rows,
  searchKeys = [],
  emptyText = 'No records found',
  actions,
  pageSize = 10,
  statusKey = null,
  loading = false,
  error = '',
  tableClassName = '',
}) {
  const [query, setQuery] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [page, setPage] = useState(1)

  const statusOptions = useMemo(() => {
    if (!statusKey) return []
    return Array.from(new Set(rows.map(r => r[statusKey]).filter(Boolean)))
  }, [rows, statusKey])

  const filtered = useMemo(() => {
    return rows.filter(row => {
      if (statusKey && statusFilter && String(row[statusKey]) !== statusFilter) return false
      if (!query.trim()) return true
      const haystack = searchKeys.map(key => row[key]).join(' ').toLowerCase()
      return haystack.includes(query.toLowerCase())
    })
  }, [rows, query, searchKeys, statusKey, statusFilter])

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize))
  useEffect(() => {
    if (page > totalPages) setPage(1)
  }, [page, totalPages])

  const pagedRows = useMemo(() => {
    const start = (page - 1) * pageSize
    return filtered.slice(start, start + pageSize)
  }, [filtered, page, pageSize])

  return (
    <div className="table-card">
      <div className="table-toolbar" style={{ flexWrap: 'wrap', gap: 10 }}>
        <div style={{ display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap' }}>
          <div className="table-search">
            <i className="bi bi-search" />
            <input
              value={query}
              onChange={e => {
                setQuery(e.target.value)
                setPage(1)
              }}
              placeholder="Search records..."
            />
          </div>
          {statusKey && statusOptions.length > 0 && (
            <select
              className="form-select"
              style={{ width: 'auto', minWidth: 145, padding: '6px 12px', fontSize: 12.5 }}
              value={statusFilter}
              onChange={e => {
                setStatusFilter(e.target.value)
                setPage(1)
              }}
            >
              <option value="">All Statuses</option>
              {statusOptions.map(opt => (
                <option key={String(opt)} value={String(opt)}>
                  {String(opt)}
                </option>
              ))}
            </select>
          )}
        </div>
        <div className="table-count">{filtered.length} records</div>
      </div>

      {error && <div className="alert alert-danger m-3 py-2">{error}</div>}

      <div className="table-responsive">
        <table className={`table align-middle mb-0 ${tableClassName}`}>
          <thead>
            <tr>
              {columns.map(col => (
                <th key={col.key}>{col.label}</th>
              ))}
              {actions && <th className="text-end">ACTIONS</th>}
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan={columns.length + (actions ? 1 : 0)} className="empty-cell">
                  <div className="spinner-border spinner-border-sm text-primary me-2" role="status" />
                  <span>Loading records...</span>
                </td>
              </tr>
            ) : pagedRows.length ? (
              pagedRows.map((row, index) => (
                <tr key={row.id ?? index}>
                  {columns.map(col => (
                    <td key={col.key}>
                      {col.render ? col.render(row[col.key], row) : (row[col.key] ?? '—')}
                    </td>
                  ))}
                  {actions && (
                    <td className="text-end">
                      <div className="row-actions">{actions(row)}</div>
                    </td>
                  )}
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={columns.length + (actions ? 1 : 0)} className="empty-cell">
                  <i className="bi bi-inbox" />
                  <span>{emptyText}</span>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <Pagination page={page} totalPages={totalPages} totalItems={filtered.length} onPageChange={setPage} />
    </div>
  )
}
