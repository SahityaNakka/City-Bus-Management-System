import { useEffect, useRef, useState } from 'react'
import { useLocation } from 'react-router-dom'
import api from '../api'
import { useAuth } from '../context/AuthContext'

const ROUTE_TITLES = {
  '/': 'Operations Dashboard',
  '/buses': 'Bus Management',
  '/drivers': 'Driver Management',
  '/routes': 'Routes & Stops',
  '/stops': 'Bus Stops',
  '/schedules': 'Schedules & Fares',
  '/trips': 'Trip Operations & Dispatch',
  '/search-trips': 'Search & Book Trips',
  '/bookings': 'Bookings & Tickets',
  '/reports': 'Reports & Audit Trail',
  '/users': 'User Management',
}

export default function Header({ onMenu }) {
  const { user, roleName, logout } = useAuth()
  const location = useLocation()
  const [notifications, setNotifications] = useState([])
  const [open, setOpen] = useState(false)
  const wrapRef = useRef(null)

  const currentPage = ROUTE_TITLES[location.pathname] || 'Operations Portal'

  const initials = (user?.name || 'CT')
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map(p => p[0].toUpperCase())
    .join('')

  const unreadCount = notifications.filter(n => !n.is_read).length

  useEffect(() => {
    if (!user) return undefined
    let active = true
    const loadNotifications = () => {
      api.get('/notifications')
        .then(res => {
          if (active) setNotifications(Array.isArray(res.data) ? res.data : [])
        })
        .catch(() => {})
    }
    loadNotifications()
    const timer = setInterval(loadNotifications, 30000)
    return () => {
      active = false
      clearInterval(timer)
    }
  }, [user?.id])

  useEffect(() => {
    if (!open) return undefined
    const handleOutside = e => {
      if (wrapRef.current && !wrapRef.current.contains(e.target)) {
        setOpen(false)
      }
    }
    document.addEventListener('mousedown', handleOutside)
    return () => document.removeEventListener('mousedown', handleOutside)
  }, [open])

  const markAllRead = async () => {
    try {
      await api.put('/notifications')
      setNotifications(prev => prev.map(n => ({ ...n, is_read: true })))
    } catch {
      // ignore transient error
    }
  }

  return (
    <header className="topbar">
      <div className="d-flex align-items-center gap-3">
        <button className="icon-button mobile-menu" onClick={onMenu} aria-label="Open menu">
          <i className="bi bi-list" />
        </button>
        <div className="breadcrumb-line">
          <span>CityTransit</span>
          <i className="bi bi-chevron-right" />
          <strong>{currentPage}</strong>
        </div>
      </div>

      <div className="topbar-actions">
        <span className="environment-pill"><span /> DEMO SYSTEM</span>

        <div className="notif-wrap" ref={wrapRef}>
          <button
            type="button"
            className="notification-button"
            onClick={() => setOpen(v => !v)}
            title="Notifications"
            aria-label="Notifications"
          >
            <i className="bi bi-bell" />
            {unreadCount > 0 && <span className="notif-count-badge">{unreadCount > 9 ? '9+' : unreadCount}</span>}
          </button>

          {open && (
            <div className="notif-dropdown">
              <div className="notif-head">
                <strong>Notifications ({unreadCount} unread)</strong>
                {unreadCount > 0 && (
                  <button type="button" className="notif-mark" onClick={markAllRead}>
                    Mark all read
                  </button>
                )}
              </div>
              <div className="notif-list">
                {notifications.length === 0 ? (
                  <p className="notif-empty">No notifications yet.</p>
                ) : (
                  notifications.map(n => (
                    <div key={n.id} className={`notif-item ${n.is_read ? '' : 'unread'}`}>
                      <p>{n.message}</p>
                      <small>{new Date(n.created_at).toLocaleString()}</small>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        <div className="profile">
          <div className="avatar">{initials}</div>
          <div className="profile-info">
            <strong>{user?.name || 'User'}</strong>
            <small>{roleName || 'Guest'}</small>
          </div>
        </div>

        <button className="logout-button" onClick={logout} title="Sign out and switch role">
          <i className="bi bi-box-arrow-right" />
          <span className="logout-text">Logout</span>
        </button>
      </div>
    </header>
  )
}
