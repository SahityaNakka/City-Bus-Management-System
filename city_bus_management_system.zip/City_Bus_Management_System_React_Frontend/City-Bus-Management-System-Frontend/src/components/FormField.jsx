export default function FormField({ label, required = false, hint, error, full = false, children }) {
  return (
    <div className={`form-field ${full ? 'full' : ''}`}>
      {label && (
        <label>
          {label} {required && <span>*</span>}
        </label>
      )}
      {children}
      {error && <small className="text-danger d-block mt-1">{error}</small>}
      {!error && hint && <small className="text-muted d-block mt-1">{hint}</small>}
    </div>
  )
}
