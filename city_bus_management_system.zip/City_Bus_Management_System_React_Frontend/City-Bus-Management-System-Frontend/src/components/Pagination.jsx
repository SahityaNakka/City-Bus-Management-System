export default function Pagination({ page, totalPages, totalItems, onPageChange }) {
  if (totalPages <= 1) return null

  return (
    <div className="table-toolbar" style={{ borderTop: '1px solid var(--border)', borderBottom: 0 }}>
      <span className="table-count">
        Page {page} of {totalPages} {typeof totalItems === 'number' ? `(${totalItems} records)` : ''}
      </span>
      <div className="d-flex gap-2">
        <button
          type="button"
          className="btn btn-light btn-sm"
          disabled={page <= 1}
          onClick={() => onPageChange(page - 1)}
        >
          <i className="bi bi-chevron-left me-1" />Previous
        </button>
        <button
          type="button"
          className="btn btn-light btn-sm"
          disabled={page >= totalPages}
          onClick={() => onPageChange(page + 1)}
        >
          Next<i className="bi bi-chevron-right ms-1" />
        </button>
      </div>
    </div>
  )
}
