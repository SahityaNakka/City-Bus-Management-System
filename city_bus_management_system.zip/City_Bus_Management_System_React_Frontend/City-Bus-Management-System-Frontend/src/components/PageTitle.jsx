export default function PageTitle({ eyebrow = 'CITY BUS OPERATIONS', title, subtitle, action }) {
  return (
    <div className="page-title-row">
      <div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1>{subtitle && <p>{subtitle}</p>}</div>
      {action && <div className="page-title-action">{action}</div>}
    </div>
  )
}
