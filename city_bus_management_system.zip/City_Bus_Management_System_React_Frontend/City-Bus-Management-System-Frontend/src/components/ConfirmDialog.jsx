import Modal from './Modal'

export default function ConfirmDialog({
  title = 'Confirm Action',
  eyebrow = 'CONFIRMATION',
  message,
  confirmLabel = 'Confirm',
  confirmTone = 'danger',
  busy = false,
  onConfirm,
  onClose,
}) {
  return (
    <Modal title={title} eyebrow={eyebrow} onClose={onClose}>
      <p className="mb-0" style={{ fontSize: 14, color: 'var(--text)' }}>{message}</p>
      <div className="modal-footer-actions">
        <button type="button" className="btn btn-light" onClick={onClose} disabled={busy}>
          Cancel
        </button>
        <button
          type="button"
          className={`btn btn-${confirmTone}`}
          onClick={onConfirm}
          disabled={busy}
        >
          {busy ? 'Please wait...' : confirmLabel}
        </button>
      </div>
    </Modal>
  )
}
