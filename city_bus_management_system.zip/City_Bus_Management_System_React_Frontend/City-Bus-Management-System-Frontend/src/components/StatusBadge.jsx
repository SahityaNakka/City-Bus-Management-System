export default function StatusBadge({ status }) {
  const value = String(status || 'Unknown').toLowerCase().replaceAll(' ', '-')
  return <span className={`status-badge status-${value}`}>{status || 'Unknown'}</span>
}
