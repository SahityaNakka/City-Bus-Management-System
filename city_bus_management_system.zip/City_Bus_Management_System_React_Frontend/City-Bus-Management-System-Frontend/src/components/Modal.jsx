export default function Modal({ title, eyebrow = 'DETAILS', wide = false, onClose, children }) {
  return (
    <div className="modal-backdrop-custom" onMouseDown={onClose}>
      <div
        className="record-modal"
        style={wide ? { width: 'min(700px, 100%)' } : undefined}
        onMouseDown={e => e.stopPropagation()}
      >
        <div className="modal-heading">
          <div>
            <span className="eyebrow">{eyebrow}</span>
            <h2>{title}</h2>
          </div>
          <button type="button" className="icon-button" onClick={onClose} aria-label="Close">
            <i className="bi bi-x-lg" />
          </button>
        </div>
        <div style={{ padding: '20px 23px' }}>{children}</div>
      </div>
    </div>
  )
}
