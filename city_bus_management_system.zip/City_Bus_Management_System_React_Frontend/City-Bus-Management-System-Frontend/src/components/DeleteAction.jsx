import { useState } from 'react'
import api, { extractError } from '../api'
import ConfirmDialog from './ConfirmDialog'

export default function DeleteAction({ endpoint, itemLabel, confirmMessage, onDeleted, onError, onNotice, disabled = false }) {
  const [open, setOpen] = useState(false)
  const [busy, setBusy] = useState(false)

  const confirmDelete = async () => {
    setBusy(true)
    try {
      await api.delete(endpoint)
      setOpen(false)
      onNotice?.(`${itemLabel} deleted successfully.`)
      await onDeleted?.()
    } catch (error) {
      onError?.(extractError(error, `Could not delete ${itemLabel.toLowerCase()}.`))
      setOpen(false)
    } finally {
      setBusy(false)
    }
  }

  return (
    <>
      <button type="button" className="table-action danger" title={`Delete ${itemLabel}`} aria-label={`Delete ${itemLabel}`} disabled={disabled} onClick={() => setOpen(true)}>
        <i className="bi bi-trash3" /> Delete
      </button>
      {open && (
        <ConfirmDialog
          title={`Delete ${itemLabel}?`}
          message={confirmMessage || `Are you sure you want to delete this ${itemLabel.toLowerCase()}? This action cannot be undone. If other records depend on it, deletion will be blocked to protect linked data.`}
          confirmLabel="Delete"
          busy={busy}
          onConfirm={confirmDelete}
          onClose={() => !busy && setOpen(false)}
        />
      )}
    </>
  )
}
