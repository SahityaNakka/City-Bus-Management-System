import axios from 'axios'
import { mockApi } from './mockApi'

// Demo mode is enabled by default for frontend-only testing.
// Set VITE_DEMO_MODE=false when the real FastAPI backend is ready.
const DEMO_MODE = import.meta.env.VITE_DEMO_MODE !== 'false'

const realApi = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || '/api',
  timeout: 15000,
  headers: { 'Content-Type': 'application/json' },
})

realApi.interceptors.request.use(config => {
  const token = localStorage.getItem('citytransit-access-token')
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

export function extractError(err, fallback = 'Request failed. Please check your input.') {
  const errObj = err?.response?.data?.error
  if (errObj?.message) {
    const fields = errObj.details?.fields
    if (fields && Object.keys(fields).length > 0) {
      const [field, msg] = Object.entries(fields)[0]
      return `${errObj.message} (${field}: ${msg})`
    }
    return errObj.message
  }
  if (!err?.response) {
    return 'Cannot reach the CityTransit backend on http://127.0.0.1:8000. Make sure "python run.py" is running and refresh the page.'
  }
  return err?.response?.data?.detail || err?.message || fallback
}

const api = DEMO_MODE ? mockApi : realApi
export default api
