import { useCallback, useEffect, useMemo, useState } from 'react'
import {
  Bar, BarChart, CartesianGrid, Legend,
  ResponsiveContainer, Tooltip, XAxis, YAxis,
} from 'recharts'
import api, { extractError } from '../api'
import DataTable from '../components/DataTable'
import FilterBar from '../components/FilterBar'
import PageTitle from '../components/PageTitle'
import StatusBadge from '../components/StatusBadge'
import StatCard from '../components/StatCard'
import { ROLES, useAuth } from '../context/AuthContext'

const TABS = [
  { id: 'trips', label: 'Trip Operations', url: '/reports/trips', roles: [ROLES.ADMIN, ROLES.MANAGER, ROLES.DISPATCHER, ROLES.AUDITOR] },
  { id: 'bookings', label: 'Booking Summary', url: '/reports/bookings', roles: [ROLES.ADMIN, ROLES.MANAGER, ROLES.CLERK, ROLES.AUDITOR] },
  { id: 'busUtil', label: 'Bus Utilization', url: '/reports/bus-utilization', roles: [ROLES.ADMIN, ROLES.MANAGER, ROLES.DISPATCHER, ROLES.AUDITOR] },
  { id: 'routeSchedules', label: 'Route Schedule', url: '/reports/route-schedules', roles: [ROLES.ADMIN, ROLES.MANAGER, ROLES.DISPATCHER, ROLES.AUDITOR] },
  { id: 'driverAssign', label: 'Driver Assignment', url: '/reports/driver-assignments', roles: [ROLES.ADMIN, ROLES.MANAGER, ROLES.DISPATCHER, ROLES.AUDITOR] },
  { id: 'cancellations', label: 'Cancellations', url: '/reports/cancellations', roles: [ROLES.ADMIN, ROLES.MANAGER, ROLES.DISPATCHER, ROLES.CLERK, ROLES.AUDITOR] },
  { id: 'audit', label: 'Audit Logs', url: '/audit-logs', roles: [ROLES.ADMIN, ROLES.MANAGER, ROLES.AUDITOR] },
]

const EMPTY_FILTERS = {
  date_from: '', date_to: '', service_date: '',
  route_id: '', bus_id: '', driver_id: '', trip_id: '', status: '',
}

const CHART_COLORS = ['#2563eb', '#16a34a', '#d97706', '#dc2626', '#7c3aed', '#0891b2']

function downloadCsv(filename, rows) {
  if (!rows.length) return
  const keys = Object.keys(rows[0])
  const csv = [keys.join(','), ...rows.map(row => keys.map(key => `"${String(row[key] ?? '').replaceAll('"', '""')}"`).join(','))].join('\n')
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
  const link = document.createElement('a')
  link.href = URL.createObjectURL(blob)
  link.download = filename
  link.click()
  URL.revokeObjectURL(link.href)
}

function inDateRange(date, from, to) {
  if (!date) return !from && !to
  const day = String(date).slice(0, 10)
  return (!from || day >= from) && (!to || day <= to)
}

function Metric({ label, value, helper, icon, tone = 'blue' }) {
  return <StatCard label={label} value={value} change={helper} icon={icon} tone={tone} />
}

export default function Reports() {
  const { roleName, hasRole } = useAuth()
  const visibleTabs = TABS.filter(item => hasRole(item.roles))
  const [tab, setTab] = useState(visibleTabs[0]?.id || 'trips')
  const [filters, setFilters] = useState(EMPTY_FILTERS)
  const [lookups, setLookups] = useState({ routes: [], buses: [], drivers: [], trips: [] })
  const [rows, setRows] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    let alive = true
    const canSeeFleet = [ROLES.ADMIN, ROLES.MANAGER, ROLES.DISPATCHER, ROLES.AUDITOR].includes(roleName)
    Promise.all([
      api.get('/routes', { params: { size: 200 } }).catch(() => ({ data: { items: [] } })),
      canSeeFleet ? api.get('/buses', { params: { size: 200 } }).catch(() => ({ data: { items: [] } })) : Promise.resolve({ data: { items: [] } }),
      canSeeFleet ? api.get('/drivers', { params: { size: 200 } }).catch(() => ({ data: { items: [] } })) : Promise.resolve({ data: { items: [] } }),
      api.get('/trips', { params: { size: 200 } }).catch(() => ({ data: { items: [] } })),
    ]).then(([routesRes, busesRes, driversRes, tripsRes]) => {
      if (!alive) return
      setLookups({
        routes: routesRes.data.items || [],
        buses: busesRes.data.items || [],
        drivers: driversRes.data.items || [],
        trips: tripsRes.data.items || [],
      })
    })
    return () => { alive = false }
  }, [roleName])

  const loadReport = useCallback(async () => {
    const activeTab = TABS.find(item => item.id === tab)
    if (!activeTab) return
    setError('')
    setLoading(true)
    try {
      const { data } = await api.get(activeTab.url, { params: {} })
      setRows(Array.isArray(data) ? data : data.items || [])
    } catch (err) {
      setRows([])
      setError(extractError(err, 'Could not load report data.'))
    } finally {
      setLoading(false)
    }
  }, [tab])

  useEffect(() => { loadReport() }, [loadReport])

  const filteredRows = useMemo(() => rows.filter(row => {
    const date = row.service_date || row.cancellation_date || ''
    if (filters.service_date && String(date).slice(0, 10) !== filters.service_date) return false
    if ((filters.date_from || filters.date_to) && !inDateRange(date, filters.date_from, filters.date_to)) return false
    if (filters.route_id && Number(row.route_id) !== Number(filters.route_id)) {
      const route = lookups.routes.find(item => Number(item.id) === Number(filters.route_id))
      if (!route || row.route_name !== route.name) return false
    }
    if (filters.bus_id && Number(row.bus_id) !== Number(filters.bus_id)) {
      const bus = lookups.buses.find(item => Number(item.id) === Number(filters.bus_id))
      if (!bus || row.bus_no !== bus.bus_no) return false
    }
    if (filters.driver_id && Number(row.driver_id) !== Number(filters.driver_id)) {
      const driver = lookups.drivers.find(item => Number(item.id) === Number(filters.driver_id))
      if (!driver || row.driver_name !== driver.name) return false
    }
    if (filters.trip_id && Number(row.trip_id) !== Number(filters.trip_id) && row.trip_no !== lookups.trips.find(t => Number(t.id) === Number(filters.trip_id))?.trip_no) return false
    if (tab === 'busUtil' && filters.status) {
      const utilization = Number(row.utilization_percent || 0)
      if (filters.status === 'high' && utilization < 70) return false
      if (filters.status === 'medium' && (utilization < 40 || utilization >= 70)) return false
      if (filters.status === 'low' && utilization >= 40) return false
    } else if (filters.status && row.status !== filters.status && row.driver_status !== filters.status) return false
    return true
  }), [rows, filters, lookups])

  const setFilter = (key, value) => setFilters(current => ({ ...current, [key]: value }))
  const resetFilters = () => setFilters(EMPTY_FILTERS)

  const colsMap = {
    trips: [
      { key: 'trip_no', label: 'TRIP NO' },
      { key: 'service_date', label: 'DATE' },
      { key: 'route_name', label: 'ROUTE' },
      { key: 'bus_no', label: 'BUS' },
      { key: 'driver_name', label: 'DRIVER' },
      { key: 'departure_at', label: 'DEPARTURE', render: value => value ? new Date(value).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '—' },
      { key: 'booked_seats', label: 'BOOKED SEATS' },
      { key: 'passenger_count', label: 'PASSENGERS' },
      { key: 'delay_category', label: 'DELAY' },
      { key: 'status', label: 'STATUS', render: value => <StatusBadge status={value} /> },
    ],
    bookings: [
      { key: 'booking_ref', label: 'BOOKING REF' },
      { key: 'service_date', label: 'DATE' },
      { key: 'trip_no', label: 'TRIP' },
      { key: 'route_name', label: 'ROUTE' },
      { key: 'passenger_name', label: 'PASSENGER' },
      { key: 'quantity', label: 'SEATS' },
      { key: 'total_fare', label: 'FARE', render: value => `₹${Number(value || 0).toLocaleString('en-IN')}` },
      { key: 'payment_status_demo', label: 'PAYMENT', render: value => <StatusBadge status={value} /> },
      { key: 'status', label: 'BOOKING STATUS', render: value => <StatusBadge status={value} /> },
    ],
    busUtil: [
      { key: 'bus_no', label: 'BUS' },
      { key: 'bus_type', label: 'TYPE' },
      { key: 'capacity', label: 'CAPACITY / TRIP' },
      { key: 'service_date', label: 'DATE' },
      { key: 'trips_assigned', label: 'TRIPS ASSIGNED' },
      { key: 'booked_seats', label: 'BOOKED SEATS' },
      { key: 'total_passengers_carried', label: 'PASSENGERS CARRIED' },
      { key: 'utilization_percent', label: 'UTILIZATION', render: value => <strong>{Number(value || 0)}%</strong> },
    ],
    routeSchedules: [
      { key: 'route_code', label: 'CODE' }, { key: 'route_name', label: 'ROUTE' },
      { key: 'stop_sequence', label: 'STOPS' }, { key: 'departure_time', label: 'DEPARTURE' },
      { key: 'fare', label: 'FARE', render: value => `₹${value}` },
      { key: 'published', label: 'PUBLISH', render: value => <StatusBadge status={value ? 'Published' : 'Draft'} /> },
      { key: 'active', label: 'ACTIVE', render: value => <StatusBadge status={value ? 'Active' : 'Inactive'} /> },
    ],
    driverAssign: [
      { key: 'employee_code', label: 'EMPLOYEE CODE' }, { key: 'driver_name', label: 'DRIVER' },
      { key: 'service_date', label: 'DATE' }, { key: 'trips_assigned', label: 'TRIPS' },
      { key: 'trip_numbers', label: 'TRIP NUMBERS' },
      { key: 'driver_status', label: 'STATUS', render: value => <StatusBadge status={value} /> },
    ],
    cancellations: [
      { key: 'status', label: 'TYPE', render: value => <StatusBadge status={value} /> },
      { key: 'cancellation_date', label: 'CANCELLED AT', render: value => value ? new Date(value).toLocaleString() : '—' },
      { key: 'booking_ref', label: 'BOOKING' }, { key: 'trip_no', label: 'TRIP' },
      { key: 'route_name', label: 'ROUTE' }, { key: 'reason', label: 'REASON' },
      { key: 'cancelled_by_name', label: 'USER' },
    ],
    audit: [
      { key: 'created_at', label: 'TIMESTAMP', render: value => value ? new Date(value).toLocaleString() : '—' },
      { key: 'actor_name', label: 'ACTOR' }, { key: 'action', label: 'ACTION' },
      { key: 'entity', label: 'ENTITY' }, { key: 'entity_id', label: 'ID' }, { key: 'reason', label: 'REASON' },
    ],
  }

  const tripStats = useMemo(() => ({
    total: filteredRows.length,
    completed: filteredRows.filter(row => row.status === 'Completed').length,
    delayed: filteredRows.filter(row => row.status === 'Delayed').length,
    cancelled: filteredRows.filter(row => row.status === 'Cancelled').length,
  }), [filteredRows])

  const bookingStats = useMemo(() => ({
    total: filteredRows.length,
    confirmed: filteredRows.filter(row => row.status === 'Confirmed').length,
    cancelled: filteredRows.filter(row => row.status === 'Cancelled').length,
    seats: filteredRows.reduce((sum, row) => sum + Number(row.quantity || 0), 0),
    revenue: filteredRows.filter(row => row.status !== 'Cancelled').reduce((sum, row) => sum + Number(row.total_fare || 0), 0),
  }), [filteredRows])

  const utilizationStats = useMemo(() => ({
    buses: filteredRows.length,
    trips: filteredRows.reduce((sum, row) => sum + Number(row.trips_assigned || 0), 0),
    capacity: filteredRows.reduce((sum, row) => sum + Number(row.capacity || 0), 0),
    seats: filteredRows.reduce((sum, row) => sum + Number(row.booked_seats || 0), 0),
    average: filteredRows.length ? Math.round(filteredRows.reduce((sum, row) => sum + Number(row.utilization_percent || 0), 0) / filteredRows.length) : 0,
  }), [filteredRows])

  const tripChart = useMemo(() => ['Scheduled', 'Assigned', 'Boarding', 'In Progress', 'Completed', 'Delayed', 'Cancelled']
    .map(status => ({ status, trips: filteredRows.filter(row => row.status === status).length }))
    .filter(row => row.trips > 0), [filteredRows])

  const bookingChart = useMemo(() => {
    const grouped = new Map()
    filteredRows.forEach(row => {
      const name = row.route_name || 'Other'
      const current = grouped.get(name) || { route: name, bookings: 0, seats: 0, revenue: 0 }
      current.bookings += 1
      current.seats += Number(row.quantity || 0)
      if (row.status !== 'Cancelled') current.revenue += Number(row.total_fare || 0)
      grouped.set(name, current)
    })
    return [...grouped.values()]
  }, [filteredRows])

  const utilChart = useMemo(() => filteredRows.map(row => ({
    bus: row.bus_no,
    utilization: Number(row.utilization_percent || 0),
    capacity: Number(row.capacity || 0),
    seats: Number(row.booked_seats || 0),
  })), [filteredRows])

  const isMainReport = ['trips', 'bookings', 'busUtil'].includes(tab)
  const activeTitle = TABS.find(item => item.id === tab)?.label || 'Reports'

  return (
    <>
      <PageTitle
        eyebrow="ANALYTICS & REPORTING"
        title="Analytics dashboards & reports"
        subtitle="Explore trip operations, booking summaries and fleet utilization with interactive filters and downloadable reports."
        action={
          <div className="d-flex flex-wrap gap-2">
            <button className="btn btn-light" disabled={!filteredRows.length} onClick={() => downloadCsv(`citytransit-${tab}-report.csv`, filteredRows)}>
              <i className="bi bi-filetype-csv me-2" />Export CSV
            </button>
            <button className="btn btn-outline-primary" onClick={() => window.print()}>
              <i className="bi bi-printer me-2" />Print Report
            </button>
            <button className="btn btn-outline-secondary" onClick={loadReport} disabled={loading}>
              <i className="bi bi-arrow-clockwise me-2" />Refresh
            </button>
          </div>
        }
      />

      <div className="d-flex flex-wrap gap-2 mb-3">
        {visibleTabs.map(item => (
          <button key={item.id} type="button" className={`btn btn-sm ${tab === item.id ? 'btn-primary' : 'btn-light'}`}
            onClick={() => { setTab(item.id); resetFilters() }}>
            {item.label}
          </button>
        ))}
      </div>

      <FilterBar onReset={resetFilters}>
        {['trips', 'busUtil', 'driverAssign'].includes(tab) && <>
          <div className="form-field">
            <label className="login-label">Date From</label>
            <input type="date" className="form-control form-control-sm" value={filters.date_from} onChange={event => setFilter('date_from', event.target.value)} />
          </div>
          <div className="form-field">
            <label className="login-label">Date To</label>
            <input type="date" className="form-control form-control-sm" value={filters.date_to} min={filters.date_from || undefined} onChange={event => setFilter('date_to', event.target.value)} />
          </div>
        </>}
        {['bookings', 'cancellations'].includes(tab) && <>
          <div className="form-field">
            <label className="login-label">Date From</label>
            <input type="date" className="form-control form-control-sm" value={filters.date_from} onChange={event => setFilter('date_from', event.target.value)} />
          </div>
          <div className="form-field">
            <label className="login-label">Date To</label>
            <input type="date" className="form-control form-control-sm" value={filters.date_to} min={filters.date_from || undefined} onChange={event => setFilter('date_to', event.target.value)} />
          </div>
        </>}
        {['trips', 'bookings', 'cancellations'].includes(tab) && <div className="form-field">
          <label className="login-label">Route</label>
          <select className="form-select form-select-sm" value={filters.route_id} onChange={event => setFilter('route_id', event.target.value)}>
            <option value="">All Routes</option>
            {lookups.routes.map(route => <option key={route.id} value={route.id}>{route.route_code} · {route.name}</option>)}
          </select>
        </div>}
        {['trips', 'busUtil'].includes(tab) && <div className="form-field">
          <label className="login-label">Bus</label>
          <select className="form-select form-select-sm" value={filters.bus_id} onChange={event => setFilter('bus_id', event.target.value)}>
            <option value="">All Buses</option>
            {lookups.buses.map(bus => <option key={bus.id} value={bus.id}>{bus.bus_no}</option>)}
          </select>
        </div>}
        {['trips', 'driverAssign'].includes(tab) && <div className="form-field">
          <label className="login-label">Driver</label>
          <select className="form-select form-select-sm" value={filters.driver_id} onChange={event => setFilter('driver_id', event.target.value)}>
            <option value="">All Drivers</option>
            {lookups.drivers.map(driver => <option key={driver.id} value={driver.id}>{driver.employee_code} · {driver.name}</option>)}
          </select>
        </div>}
        {tab === 'bookings' && <div className="form-field">
          <label className="login-label">Trip</label>
          <select className="form-select form-select-sm" value={filters.trip_id} onChange={event => setFilter('trip_id', event.target.value)}>
            <option value="">All Trips</option>
            {lookups.trips.map(trip => <option key={trip.id} value={trip.id}>{trip.trip_no} ({trip.service_date})</option>)}
          </select>
        </div>}
        {['trips', 'bookings', 'driverAssign'].includes(tab) && <div className="form-field">
          <label className="login-label">Status</label>
          <select className="form-select form-select-sm" value={filters.status} onChange={event => setFilter('status', event.target.value)}>
            <option value="">All Statuses</option>
            {(tab === 'trips' ? ['Scheduled', 'Assigned', 'Boarding', 'In Progress', 'Completed', 'Delayed', 'Cancelled']
              : tab === 'bookings' ? ['Confirmed', 'Completed', 'Cancelled', 'No-show']
                : ['Available', 'Assigned', 'On Leave', 'Inactive']).map(status => <option key={status} value={status}>{status}</option>)}
          </select>
        </div>}
        {tab === 'busUtil' && <div className="form-field">
          <label className="login-label">Utilization</label>
          <select className="form-select form-select-sm" value={filters.status} onChange={event => setFilter('status', event.target.value)}>
            <option value="">All utilization</option><option value="high">High (70%+)</option><option value="medium">Medium (40–69%)</option><option value="low">Low (below 40%)</option>
          </select>
        </div>}
      </FilterBar>

      {error && <div className="alert alert-danger py-2">{error}</div>}
      {loading && <div className="text-muted small mb-3">Loading {activeTitle.toLowerCase()}…</div>}

      {tab === 'busUtil' && filters.status && (
        <div className="d-none">{/* utilization range is applied below in the visible table/chart */}</div>
      )}

      {tab === 'trips' && <>
        <div className="stats-grid">
          <Metric label="Total Trips" value={tripStats.total} helper="Trips matching current filters" icon="bi-signpost-split" tone="blue" />
          <Metric label="Completed" value={tripStats.completed} helper="Successfully completed" icon="bi-check-circle" tone="green" />
          <Metric label="Delayed" value={tripStats.delayed} helper="Require operational attention" icon="bi-clock-history" tone="orange" />
          <Metric label="Cancelled" value={tripStats.cancelled} helper="Cancelled services" icon="bi-x-circle" tone="purple" />
        </div>
        <section className="content-card mb-3">
          <div className="section-heading"><div><h3>Trip operations overview</h3><p>Trip status distribution for the selected filters</p></div><span className="soft-label">TRIP ANALYTICS</span></div>
          <div className="chart-wrap" style={{ height: 280 }}>
            {tripChart.length ? <ResponsiveContainer width="100%" height="100%"><BarChart data={tripChart}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} /><XAxis dataKey="status" tick={{ fontSize: 11 }} /><YAxis allowDecimals={false} /><Tooltip /><Bar dataKey="trips" name="Trips" fill="#2563eb" radius={[5, 5, 0, 0]} />
            </BarChart></ResponsiveContainer> : <div className="empty-state">No trip records match these filters.</div>}
          </div>
        </section>
      </>}

      {tab === 'bookings' && <>
        <div className="stats-grid">
          <Metric label="Total Bookings" value={bookingStats.total} helper="Matching booking records" icon="bi-ticket-perforated" tone="blue" />
          <Metric label="Confirmed" value={bookingStats.confirmed} helper="Confirmed reservations" icon="bi-check-circle" tone="green" />
          <Metric label="Seats Booked" value={bookingStats.seats} helper="Total passenger seats" icon="bi-people" tone="orange" />
          <Metric label="Demo Revenue" value={`₹${bookingStats.revenue.toLocaleString('en-IN')}`} helper={`${bookingStats.cancelled} cancelled booking(s) excluded`} icon="bi-currency-rupee" tone="purple" />
        </div>
        <section className="content-card mb-3">
          <div className="section-heading"><div><h3>Booking summary by route</h3><p>Bookings and seats grouped by route</p></div><span className="soft-label">BOOKING ANALYTICS</span></div>
          <div className="chart-wrap" style={{ height: 280 }}>
            {bookingChart.length ? <ResponsiveContainer width="100%" height="100%"><BarChart data={bookingChart}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} /><XAxis dataKey="route" tick={{ fontSize: 11 }} /><YAxis allowDecimals={false} /><Tooltip /><Legend /><Bar dataKey="bookings" name="Bookings" fill="#2563eb" radius={[5, 5, 0, 0]} /><Bar dataKey="seats" name="Seats" fill="#16a34a" radius={[5, 5, 0, 0]} />
            </BarChart></ResponsiveContainer> : <div className="empty-state">No booking records match these filters.</div>}
          </div>
        </section>
      </>}

      {tab === 'busUtil' && <>
        <div className="stats-grid">
          <Metric label="Buses in Report" value={utilizationStats.buses} helper="Fleet records matching filters" icon="bi-bus-front" tone="blue" />
          <Metric label="Assigned Trips" value={utilizationStats.trips} helper="Total trips assigned" icon="bi-signpost" tone="green" />
          <Metric label="Seats Booked" value={utilizationStats.seats} helper={`Across ${utilizationStats.capacity} capacity units`} icon="bi-people" tone="orange" />
          <Metric label="Average Utilization" value={`${utilizationStats.average}%`} helper="Average fleet utilization" icon="bi-speedometer2" tone="purple" />
        </div>
        <section className="content-card mb-3">
          <div className="section-heading"><div><h3>Bus capacity vs booked seats</h3><p>Compare each bus's rated capacity with seats booked for its assigned trips</p></div><span className="soft-label">CAPACITY ANALYTICS</span></div>
          <div className="chart-wrap" style={{ height: 280 }}>
            {utilChart.length ? <ResponsiveContainer width="100%" height="100%"><BarChart data={utilChart}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} /><XAxis dataKey="bus" tick={{ fontSize: 11 }} /><YAxis allowDecimals={false} /><Tooltip /><Legend /><Bar dataKey="capacity" name="Capacity" fill="#94a3b8" radius={[5, 5, 0, 0]} /><Bar dataKey="seats" name="Booked seats" fill="#2563eb" radius={[5, 5, 0, 0]} />
            </BarChart></ResponsiveContainer> : <div className="empty-state">No bus utilization records match these filters.</div>}
          </div>
        </section>
        <section className="content-card mb-3">
          <div className="section-heading"><div><h3>Bus utilization percentage</h3><p>Booked seats divided by total available capacity across assigned trips</p></div><span className="soft-label">FLEET UTILIZATION</span></div>
          <div className="chart-wrap" style={{ height: 280 }}>
            {utilChart.length ? <ResponsiveContainer width="100%" height="100%"><BarChart data={utilChart}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} /><XAxis dataKey="bus" tick={{ fontSize: 11 }} /><YAxis domain={[0, 100]} unit="%" /><Tooltip formatter={value => `${value}%`} /><Bar dataKey="utilization" name="Utilization %" fill="#7c3aed" radius={[5, 5, 0, 0]} />
            </BarChart></ResponsiveContainer> : <div className="empty-state">No bus utilization records match these filters.</div>}
          </div>
        </section>
      </>}

      {!isMainReport && tab === 'bookings' && null}
      <section className="content-card">
        <div className="section-heading">
          <div><h3>{activeTitle} detail records</h3><p>{filteredRows.length} record(s) match the current filters</p></div>
          <span className="soft-label">REPORT DATA</span>
        </div>
        <DataTable
          columns={colsMap[tab] || []}
          rows={filteredRows}
          searchKeys={Object.keys(filteredRows[0] || {})}
          loading={loading}
          error={error}
        />
      </section>
    </>
  )
}
