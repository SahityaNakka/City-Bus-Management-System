import { useCallback, useEffect, useState } from 'react'
import api, { extractError } from '../api'
import DeleteAction from '../components/DeleteAction'
import ConfirmDialog from '../components/ConfirmDialog'
import DataTable from '../components/DataTable'
import FormField from '../components/FormField'
import Modal from '../components/Modal'
import PageTitle from '../components/PageTitle'
import StatusBadge from '../components/StatusBadge'

export default function UsersPage() {
  const [users, setUsers] = useState([])
  const [roles, setRoles] = useState([])
  const [loading, setLoading] = useState(true)
  const [modalUser, setModalUser] = useState(null)
  const [confirmToggle, setConfirmToggle] = useState(null)
  const [form, setForm] = useState({ name: '', email: '', password: '', role_id: '', active: true })
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')

  const loadData = useCallback(async () => {
    setLoading(true)
    try {
      const [uRes, rRes] = await Promise.all([api.get('/users', { params: { size: 100 } }), api.get('/users/roles')])
      setUsers(uRes.data.items.map(u => ({ ...u, roleName: u.role?.name || '', statusLabel: u.active ? 'Active' : 'Inactive' })))
      setRoles(rRes.data)
    } catch (err) {
      setError(extractError(err))
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    loadData()
  }, [loadData])

  const openModal = (usr = null) => {
    setError('')
    setModalUser(usr || {})
    setForm(
      usr
        ? { name: usr.name, email: usr.email, password: '', role_id: usr.role_id, active: usr.active }
        : { name: '', email: '', password: '', role_id: roles[0]?.id || '', active: true }
    )
  }

  const saveUser = async e => {
    e.preventDefault()
    setError('')
    try {
      if (modalUser?.id) {
        const payload = { name: form.name, email: form.email, role_id: Number(form.role_id), active: form.active }
        if (form.password) payload.password = form.password
        await api.patch(`/users/${modalUser.id}`, payload)
      } else {
        await api.post('/users', { name: form.name, email: form.email, password: form.password, role_id: Number(form.role_id) })
      }
      setModalUser(null)
      setNotice('User account saved.')
      loadData()
    } catch (err) {
      setError(extractError(err))
    }
  }

  const toggleActive = async () => {
    setError('')
    try {
      await api.patch(`/users/${confirmToggle.id}`, { active: !confirmToggle.active })
      setNotice(`Account ${confirmToggle.email} ${confirmToggle.active ? 'deactivated' : 'activated'}.`)
      setConfirmToggle(null)
      loadData()
    } catch (err) {
      setError(extractError(err))
      setConfirmToggle(null)
    }
  }

  const columns = [
    { key: 'name', label: 'NAME' },
    { key: 'email', label: 'EMAIL' },
    { key: 'roleName', label: 'ROLE' },
    { key: 'statusLabel', label: 'STATUS', render: v => <StatusBadge status={v} /> },
  ]

  return (
    <>
      <PageTitle
        title="User management"
        subtitle="Create, update, assign roles, or deactivate accounts across all 7 CityTransit roles."
        action={<button className="btn btn-primary" onClick={() => openModal()}><i className="bi bi-plus-lg me-2" />Add User</button>}
      />

      {notice && <div className="alert alert-success py-2">{notice}</div>}
      {error && !modalUser && <div className="alert alert-danger py-2">{error}</div>}

      <DataTable
        columns={columns}
        rows={users}
        searchKeys={['name', 'email', 'roleName']}
        statusKey="statusLabel"
        loading={loading}
        actions={row => (
          <>
            <button className="table-action" title="Edit User" onClick={() => openModal(row)}>
              <i className="bi bi-pencil" /> Edit
            </button>
            <button
              className={`table-action ${row.active ? 'danger' : ''}`}
              title={row.active ? 'Deactivate User' : 'Activate User'}
              onClick={() => setConfirmToggle(row)}
            >
              <i className={`bi ${row.active ? 'bi-person-slash' : 'bi-person-check'}`} /> {row.active ? 'Deactivate' : 'Activate'}
            </button>
            <DeleteAction endpoint={`/users/${row.id}`} itemLabel={`user ${row.email}`} onDeleted={loadData} onError={setError} onNotice={setNotice} />
          </>
        )}
      />

      {modalUser && (
        <Modal title={modalUser.id ? `Edit User — ${modalUser.email}` : 'Create User'} onClose={() => setModalUser(null)}>
          {error && <div className="alert alert-danger py-2">{error}</div>}
          <form onSubmit={saveUser}>
            <div className="form-grid">
              <FormField label="Full Name" required>
                <input className="form-control" required minLength={2} value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} />
              </FormField>
              <FormField label="Email" required>
                <input type="email" className="form-control" required value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} />
              </FormField>
              <FormField label={modalUser.id ? 'New Password (optional)' : 'Password'} required={!modalUser.id}>
                <input type="password" className="form-control" required={!modalUser.id} minLength={modalUser.id ? 0 : 6} value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} />
              </FormField>
              <FormField label="Role" required>
                <select className="form-select" value={form.role_id} onChange={e => setForm({ ...form, role_id: e.target.value })}>
                  {roles.map(r => <option key={r.id} value={r.id}>{r.name}</option>)}
                </select>
              </FormField>
              {modalUser.id && (
                <FormField label="Account Status" full>
                  <select className="form-select" value={String(form.active)} onChange={e => setForm({ ...form, active: e.target.value === 'true' })}>
                    <option value="true">Active</option>
                    <option value="false">Inactive</option>
                  </select>
                </FormField>
              )}
            </div>
            <div className="modal-footer-actions">
              <button type="button" className="btn btn-light" onClick={() => setModalUser(null)}>Cancel</button>
              <button type="submit" className="btn btn-primary">Save User</button>
            </div>
          </form>
        </Modal>
      )}

      {confirmToggle && (
        <ConfirmDialog
          title={confirmToggle.active ? 'Deactivate User Account' : 'Activate User Account'}
          message={`Are you sure you want to ${confirmToggle.active ? 'deactivate' : 'activate'} ${confirmToggle.name} (${confirmToggle.email})?`}
          confirmLabel={confirmToggle.active ? 'Deactivate' : 'Activate'}
          confirmTone={confirmToggle.active ? 'danger' : 'primary'}
          onConfirm={toggleActive}
          onClose={() => setConfirmToggle(null)}
        />
      )}
    </>
  )
}
