import { useCallback, useEffect, useState } from 'react'
import api, { extractError } from '../api'
import DeleteAction from '../components/DeleteAction'
import DataTable from '../components/DataTable'
import Modal from '../components/Modal'
import PageTitle from '../components/PageTitle'
import StatusBadge from '../components/StatusBadge'
import { ROLES, useAuth } from '../context/AuthContext'
import { localIsoDate } from '../utils/date'

export default function SchedulesPage() {
  const { hasRole } = useAuth()
  const canEdit = hasRole([ROLES.ADMIN, ROLES.MANAGER])

  const [schedules, setSchedules] = useState([])
  const [routes, setRoutes] = useState([])
  const [fareRules, setFareRules] = useState([])
  const [loading, setLoading] = useState(true)
  const [modalSch, setModalSch] = useState(null)
  const [form, setForm] = useState({ route_id: '', departure_time: '08:00', duration_min: 45, fare: 50, service_rule: 'Daily', published: false })
  const [genSch, setGenSch] = useState(null)
  const [genDates, setGenDates] = useState(() => localIsoDate(1))
  const [fareModal, setFareModal] = useState(false)
  const [fareForm, setFareForm] = useState({ route_id: '', fare_amount: 60, effective_date: localIsoDate(0) })
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')

  const loadData = useCallback(async () => {
    setLoading(true)
    try {
      const [sRes, rRes, fRes] = await Promise.all([
        api.get('/schedules', { params: { size: 100 } }),
        api.get('/routes', { params: { active: true, size: 100 } }),
        api.get('/fare-rules'),
      ])
      setSchedules(sRes.data.items.map(s => ({ ...s, routeName: `${s.route.route_code} · ${s.route.name}`, depShort: String(s.departure_time).slice(0, 5), pubLabel: s.published ? 'Published' : 'Draft' })))
      setRoutes(rRes.data.items)
      setFareRules(fRes.data)
    } catch (err) {
      setError(extractError(err, 'Could not load schedules.'))
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    loadData()
  }, [loadData])

  const openModal = (sch = null) => {
    setError('')
    setModalSch(sch || {})
    setForm(
      sch
        ? { route_id: sch.route_id, departure_time: String(sch.departure_time).slice(0, 5), duration_min: sch.duration_min, fare: sch.fare, service_rule: sch.service_rule, published: sch.published }
        : { route_id: routes[0]?.id || '', departure_time: '08:00', duration_min: 45, fare: 50, service_rule: 'Daily', published: false }
    )
  }

  const saveSchedule = async e => {
    e.preventDefault()
    setError('')
    try {
      const timeVal = form.departure_time.length === 5 ? `${form.departure_time}:00` : form.departure_time
      const payload = { ...form, route_id: Number(form.route_id), duration_min: Number(form.duration_min), fare: Number(form.fare), departure_time: timeVal }
      if (modalSch?.id) await api.patch(`/schedules/${modalSch.id}`, payload)
      else await api.post('/schedules', payload)
      setModalSch(null)
      setNotice('Schedule saved.')
      loadData()
    } catch (err) {
      setError(extractError(err))
    }
  }

  const generateTrips = async e => {
    e.preventDefault()
    setError('')
    try {
      const service_dates = genDates.split(',').map(s => s.trim()).filter(Boolean)
      const { data } = await api.post(`/schedules/${genSch.id}/generate-trips`, { service_dates })
      setGenSch(null)
      setNotice(`Generated ${data.created_count} trip(s).`)
    } catch (err) {
      setError(extractError(err))
    }
  }

  const saveFareRule = async e => {
    e.preventDefault()
    setError('')
    try {
      await api.post('/fare-rules', { route_id: Number(fareForm.route_id), fare_amount: Number(fareForm.fare_amount), effective_date: fareForm.effective_date, active: true })
      setFareModal(false)
      setNotice('Fare rule added.')
      loadData()
    } catch (err) {
      setError(extractError(err))
    }
  }

  const columns = [
    { key: 'routeName', label: 'ROUTE' },
    { key: 'depShort', label: 'DEPARTURE' },
    { key: 'duration_min', label: 'DURATION (MIN)' },
    { key: 'fare', label: 'FARE', render: v => `₹${v}` },
    { key: 'service_rule', label: 'SERVICE DAYS' },
    { key: 'pubLabel', label: 'STATUS', render: v => <StatusBadge status={v} /> },
  ]

  return (
    <>
      <PageTitle
        title="Schedule & fare management"
        subtitle="Publish validated schedules, manage fare overrides, and generate trips for service dates."
        action={
          canEdit && (
            <div style={{ display: 'flex', gap: 8 }}>
              <button className="btn btn-light" onClick={() => { setError(''); setFareForm({ route_id: routes[0]?.id || '', fare_amount: 60, effective_date: new Date().toISOString().slice(0, 10) }); setFareModal(true) }}>+ Fare Rule</button>
              <button className="btn btn-primary" onClick={() => openModal()}><i className="bi bi-plus-lg me-2" />Add Schedule</button>
            </div>
          )
        }
      />

      {notice && <div className="alert alert-success py-2">{notice}</div>}
      {error && !modalSch && !genSch && !fareModal && <div className="alert alert-danger py-2">{error}</div>}

      <DataTable
        columns={columns}
        rows={schedules}
        searchKeys={['routeName', 'service_rule']}
        statusKey="pubLabel"
        loading={loading}
        actions={canEdit ? row => (
          <>
            {row.published && <button className="table-action" title="Generate Trips" onClick={() => { setError(''); setGenSch(row) }}><i className="bi bi-calendar-plus" /></button>}
            <button className="table-action" title="Edit" onClick={() => openModal(row)}><i className="bi bi-pencil" /></button>
            <DeleteAction endpoint={`/schedules/${row.id}`} itemLabel={`schedule #${row.id}`} onDeleted={loadData} onError={setError} onNotice={setNotice} />
          </>
        ) : null}
      />

      <div className="content-card mt-3">
        <div className="section-heading"><div><h3>Fare rules</h3><p>Effective date fare overrides per route</p></div></div>
        <table className="table align-middle mb-0">
          <thead><tr><th>ID</th><th>ROUTE ID</th><th>AMOUNT</th><th>EFFECTIVE FROM</th><th>STATUS</th>{canEdit && <th />}</tr></thead>
          <tbody>
            {fareRules.map(fr => (
              <tr key={fr.id}>
                <td>#{fr.id}</td><td>{fr.route_id || '—'}</td><td>₹{fr.fare_amount}</td><td>{fr.effective_date}</td>
                <td><StatusBadge status={fr.active ? 'Active' : 'Inactive'} /></td>
                {canEdit && (
                  <td className="text-end">
                    <button className="btn btn-light btn-sm" onClick={async () => { await api.patch(`/fare-rules/${fr.id}`, null, { params: { active: !fr.active } }); loadData() }}>
                      {fr.active ? 'Deactivate' : 'Activate'}
                    </button>
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {modalSch && (
        <Modal title={modalSch.id ? `Edit Schedule #${modalSch.id}` : 'Create Schedule'} onClose={() => setModalSch(null)}>
          {error && <div className="alert alert-danger py-2">{error}</div>}
          <form onSubmit={saveSchedule}>
            <div className="form-grid">
              {!modalSch.id && (
                <div className="form-field full">
                  <label>Route <span>*</span></label>
                  <select className="form-select" value={form.route_id} onChange={e => setForm({ ...form, route_id: e.target.value })}>
                    {routes.map(r => <option key={r.id} value={r.id}>{r.route_code} · {r.name} ({r.stops_count} stops)</option>)}
                  </select>
                </div>
              )}
              <div className="form-field"><label>Departure Time <span>*</span></label><input type="time" className="form-control" required value={form.departure_time} onChange={e => setForm({ ...form, departure_time: e.target.value })} /></div>
              <div className="form-field"><label>Duration (min) <span>*</span></label><input type="number" min={1} className="form-control" required value={form.duration_min} onChange={e => setForm({ ...form, duration_min: e.target.value })} /></div>
              <div className="form-field"><label>Fare (₹) <span>*</span></label><input type="number" min={0} step="0.5" className="form-control" required value={form.fare} onChange={e => setForm({ ...form, fare: e.target.value })} /></div>
              <div className="form-field"><label>Service Pattern <span>*</span></label><input className="form-control" required value={form.service_rule} onChange={e => setForm({ ...form, service_rule: e.target.value })} /></div>
              <div className="form-field full">
                <label>Publication Status</label>
                <select className="form-select" value={String(form.published)} onChange={e => setForm({ ...form, published: e.target.value === 'true' })}>
                  <option value="false">Draft</option>
                  <option value="true">Published (requires &ge; 2 active stops)</option>
                </select>
              </div>
            </div>
            <div className="modal-footer-actions">
              <button type="button" className="btn btn-light" onClick={() => setModalSch(null)}>Cancel</button>
              <button type="submit" className="btn btn-primary">Save Schedule</button>
            </div>
          </form>
        </Modal>
      )}

      {genSch && (
        <Modal title={`Generate Trips — ${genSch.routeName}`} onClose={() => setGenSch(null)}>
          {error && <div className="alert alert-danger py-2">{error}</div>}
          <form onSubmit={generateTrips}>
            <div className="form-field"><label>Service Dates (comma-separated YYYY-MM-DD) <span>*</span></label><input className="form-control" required value={genDates} onChange={e => setGenDates(e.target.value)} /></div>
            <div className="modal-footer-actions">
              <button type="button" className="btn btn-light" onClick={() => setGenSch(null)}>Cancel</button>
              <button type="submit" className="btn btn-primary">Generate Trips</button>
            </div>
          </form>
        </Modal>
      )}

      {fareModal && (
        <Modal title="Add Route Fare Rule" onClose={() => setFareModal(false)}>
          {error && <div className="alert alert-danger py-2">{error}</div>}
          <form onSubmit={saveFareRule}>
            <div className="form-grid">
              <div className="form-field full">
                <label>Route <span>*</span></label>
                <select className="form-select" value={fareForm.route_id} onChange={e => setFareForm({ ...fareForm, route_id: e.target.value })}>
                  {routes.map(r => <option key={r.id} value={r.id}>{r.route_code} · {r.name}</option>)}
                </select>
              </div>
              <div className="form-field"><label>Fare Amount (₹) <span>*</span></label><input type="number" min={0} step="0.5" className="form-control" required value={fareForm.fare_amount} onChange={e => setFareForm({ ...fareForm, fare_amount: e.target.value })} /></div>
              <div className="form-field"><label>Effective Date <span>*</span></label><input type="date" className="form-control" required value={fareForm.effective_date} onChange={e => setFareForm({ ...fareForm, effective_date: e.target.value })} /></div>
            </div>
            <div className="modal-footer-actions">
              <button type="button" className="btn btn-light" onClick={() => setFareModal(false)}>Cancel</button>
              <button type="submit" className="btn btn-primary">Save Fare Rule</button>
            </div>
          </form>
        </Modal>
      )}
    </>
  )
}
