import { useCallback, useEffect, useState } from 'react'
import api, { extractError } from '../api'
import DeleteAction from '../components/DeleteAction'
import DataTable from '../components/DataTable'
import Modal from '../components/Modal'
import PageTitle from '../components/PageTitle'
import StatusBadge from '../components/StatusBadge'
import { ROLES, useAuth } from '../context/AuthContext'

const TRIP_STATUSES = ['Scheduled', 'Assigned', 'Boarding', 'In Progress', 'Completed', 'Delayed', 'Cancelled']
const DELAY_CATS = ['Traffic', 'Mechanical', 'Weather', 'Passenger', 'Operational', 'Other']

export default function TripsPage() {
  const { roleName, hasRole } = useAuth()
  const isDriver = roleName === ROLES.DRIVER
  const canDispatch = hasRole([ROLES.ADMIN, ROLES.MANAGER, ROLES.DISPATCHER])

  const [trips, setTrips] = useState([])
  const [loading, setLoading] = useState(true)
  const [buses, setBuses] = useState([])
  const [drivers, setDrivers] = useState([])
  const [assignTrip, setAssignTrip] = useState(null)
  const [assignForm, setAssignForm] = useState({ bus_id: '', driver_id: '', reason: 'Daily dispatch' })
  const [statusTrip, setStatusTrip] = useState(null)
  const [statusForm, setStatusForm] = useState({ status: 'Boarding', reason: 'Status update' })
  const [eventTrip, setEventTrip] = useState(null)
  const [eventForm, setEventForm] = useState({ event_type: 'departure', delay_category: 'Traffic', passenger_count: '', note: '' })
  const [detailTrip, setDetailTrip] = useState(null)
  const [detailData, setDetailData] = useState({ stops: [], events: [], bookings: [] })
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')

  const loadTrips = useCallback(async () => {
    setLoading(true)
    try {
      const tRes = await api.get('/trips', { params: { size: 100 } })
      setTrips(tRes.data.items.map(t => ({
        ...t,
        routeName: t.schedule?.route?.name || '',
        depTime: String(t.schedule?.departure_time || '').slice(0, 5),
        busLabel: t.bus ? `${t.bus.bus_no} (${t.available_seats}/${t.bus.capacity} free)` : 'Unassigned',
        driverLabel: t.driver ? t.driver.name : 'Unassigned',
      })))
      if (canDispatch) {
        const [bRes, dRes] = await Promise.all([api.get('/buses', { params: { size: 100 } }), api.get('/drivers', { params: { size: 100 } })])
        setBuses(bRes.data.items)
        setDrivers(dRes.data.items)
      }
    } catch (err) {
      setError(extractError(err, 'Could not load trips.'))
    } finally {
      setLoading(false)
    }
  }, [canDispatch])

  useEffect(() => {
    loadTrips()
  }, [loadTrips])

  const submitAssign = async e => {
    e.preventDefault()
    setError('')
    try {
      await api.patch(`/trips/${assignTrip.id}/assignment`, { bus_id: Number(assignForm.bus_id), driver_id: Number(assignForm.driver_id), reason: assignForm.reason })
      setAssignTrip(null)
      setNotice(`Assigned bus and driver to ${assignTrip.trip_no}.`)
      loadTrips()
    } catch (err) {
      setError(extractError(err))
    }
  }

  const submitStatus = async e => {
    e.preventDefault()
    setError('')
    try {
      await api.patch(`/trips/${statusTrip.id}/status`, statusForm)
      setStatusTrip(null)
      setNotice(`Updated status on ${statusTrip.trip_no}.`)
      loadTrips()
    } catch (err) {
      setError(extractError(err))
    }
  }

  const submitEvent = async e => {
    e.preventDefault()
    setError('')
    try {
      await api.post(`/trips/${eventTrip.id}/events`, {
        event_type: eventForm.event_type,
        delay_category: eventForm.event_type === 'delay' ? eventForm.delay_category : null,
        passenger_count: eventForm.passenger_count === '' ? null : Number(eventForm.passenger_count),
        note: eventForm.note || null,
      })
      setEventTrip(null)
      setNotice(`Recorded ${eventForm.event_type} on ${eventTrip.trip_no}.`)
      loadTrips()
    } catch (err) {
      setError(extractError(err))
    }
  }

  const openDetails = async trip => {
    setError('')
    setDetailTrip(trip)
    const [detailRes, evRes, bkRes] = await Promise.all([
      api.get(`/trips/${trip.id}`),
      api.get(`/trips/${trip.id}/events`),
      isDriver ? Promise.resolve({ data: [] }) : api.get(`/trips/${trip.id}/bookings`),
    ])
    setDetailData({ stops: detailRes.data.schedule?.route?.route_stops || [], events: evRes.data, bookings: bkRes.data })
  }

  const columns = [
    { key: 'trip_no', label: 'TRIP NO' },
    { key: 'routeName', label: 'ROUTE' },
    { key: 'service_date', label: 'DATE' },
    { key: 'depTime', label: 'DEPARTURE' },
    { key: 'busLabel', label: 'BUS / SEATS' },
    { key: 'driverLabel', label: 'DRIVER' },
    { key: 'passenger_count', label: 'PAX' },
    { key: 'status', label: 'STATUS', render: v => <StatusBadge status={v} /> },
  ]

  return (
    <>
      <PageTitle
        title={isDriver ? 'My assigned trips' : 'Trip operations & dispatch'}
        subtitle={isDriver ? 'Inspect route stops and record departure, arrival, passenger counts, or delays.' : 'Assign eligible buses and drivers with overlap validation, update status, and review follow-up bookings.'}
      />

      {notice && <div className="alert alert-success py-2">{notice}</div>}
      {error && !assignTrip && !statusTrip && !eventTrip && <div className="alert alert-danger py-2">{error}</div>}

      <DataTable
        columns={columns}
        rows={trips}
        searchKeys={['trip_no', 'routeName', 'busLabel', 'driverLabel', 'service_date']}
        statusKey="status"
        loading={loading}
        actions={row => (
          <>
            {canDispatch && !['Completed', 'Cancelled'].includes(row.status) && (
              <>
                <button className="table-action" title="Assign Bus & Driver" onClick={() => { setError(''); setAssignTrip(row); setAssignForm({ bus_id: row.bus_id || buses[0]?.id || '', driver_id: row.driver_id || drivers[0]?.id || '', reason: 'Daily dispatch' }) }}>
                  <i className="bi bi-person-check" /> Assign
                </button>
                <button className="table-action" title="Update Status" onClick={() => { setError(''); setStatusTrip(row); setStatusForm({ status: row.status, reason: 'Operational update' }) }}>
                  <i className="bi bi-arrow-repeat" /> Status
                </button>
              </>
            )}
            {(canDispatch || isDriver) && row.status !== 'Cancelled' && (
              <button className="table-action" title="Record Trip Event" onClick={() => { setError(''); setEventTrip(row); setEventForm({ event_type: 'departure', delay_category: 'Traffic', passenger_count: row.passenger_count ?? '', note: '' }) }}>
                <i className="bi bi-journal-plus" /> Log
              </button>
            )}
            <button className="table-action" title="Stops, Events & Follow-up" onClick={() => openDetails(row)}>
              <i className="bi bi-info-circle" /> Details
            </button>
            {canDispatch && <DeleteAction endpoint={`/trips/${row.id}`} itemLabel={`trip ${row.trip_no}`} onDeleted={loadTrips} onError={setError} onNotice={setNotice} />}
          </>
        )}
      />

      {assignTrip && (
        <Modal title={`Assign Bus & Driver — ${assignTrip.trip_no}`} onClose={() => setAssignTrip(null)}>
          {error && <div className="alert alert-danger py-2">{error}</div>}
          <form onSubmit={submitAssign}>
            <div className="form-grid">
              <div className="form-field"><label>Bus <span>*</span></label><select className="form-select" value={assignForm.bus_id} onChange={e => setAssignForm({ ...assignForm, bus_id: e.target.value })}>{buses.map(b => <option key={b.id} value={b.id}>{b.bus_no} (Cap {b.capacity}) [{b.status}]</option>)}</select></div>
              <div className="form-field"><label>Driver <span>*</span></label><select className="form-select" value={assignForm.driver_id} onChange={e => setAssignForm({ ...assignForm, driver_id: e.target.value })}>{drivers.map(d => <option key={d.id} value={d.id}>{d.employee_code} · {d.name} [{d.status}]</option>)}</select></div>
              <div className="form-field full"><label>Reason <span>*</span></label><input className="form-control" required value={assignForm.reason} onChange={e => setAssignForm({ ...assignForm, reason: e.target.value })} /></div>
            </div>
            <div className="modal-footer-actions"><button type="button" className="btn btn-light" onClick={() => setAssignTrip(null)}>Cancel</button><button type="submit" className="btn btn-primary">Save Assignment</button></div>
          </form>
        </Modal>
      )}

      {statusTrip && (
        <Modal title={`Update Status — ${statusTrip.trip_no}`} onClose={() => setStatusTrip(null)}>
          {error && <div className="alert alert-danger py-2">{error}</div>}
          <form onSubmit={submitStatus}>
            {statusForm.status === 'Cancelled' && (
              <div className="demo-note mt-0 mb-3">
                <i className="bi bi-exclamation-triangle" />
                <span>Cancelling this trip notifies booked passengers and blocks new bookings. Existing bookings remain in Details / Bookings for staff follow-up.</span>
              </div>
            )}
            <div className="form-grid">
              <div className="form-field"><label>New Status</label><select className="form-select" value={statusForm.status} onChange={e => setStatusForm({ ...statusForm, status: e.target.value })}>{TRIP_STATUSES.map(s => <option key={s} value={s}>{s}</option>)}</select></div>
              <div className="form-field"><label>Reason <span>*</span></label><input className="form-control" required minLength={2} value={statusForm.reason} onChange={e => setStatusForm({ ...statusForm, reason: e.target.value })} /></div>
            </div>
            <div className="modal-footer-actions"><button type="button" className="btn btn-light" onClick={() => setStatusTrip(null)}>Cancel</button><button type="submit" className={`btn ${statusForm.status === 'Cancelled' ? 'btn-danger' : 'btn-primary'}`}>Update Status</button></div>
          </form>
        </Modal>
      )}

      {eventTrip && (
        <Modal title={`Trip Update — ${eventTrip.trip_no}`} onClose={() => setEventTrip(null)}>
          {error && <div className="alert alert-danger py-2">{error}</div>}
          <form onSubmit={submitEvent}>
            <div className="form-grid">
              <div className="form-field"><label>Event Type</label><select className="form-select" value={eventForm.event_type} onChange={e => setEventForm({ ...eventForm, event_type: e.target.value })}><option value="departure">Departure (In Progress)</option><option value="arrival">Arrival (Completed)</option><option value="delay">Delay (Delayed)</option><option value="passenger_count">Passenger Count</option><option value="note">Trip Note</option></select></div>
              {eventForm.event_type === 'delay' && <div className="form-field"><label>Delay Category</label><select className="form-select" value={eventForm.delay_category} onChange={e => setEventForm({ ...eventForm, delay_category: e.target.value })}>{DELAY_CATS.map(c => <option key={c} value={c}>{c}</option>)}</select></div>}
              <div className="form-field"><label>Passenger Count {eventTrip.bus ? `(0–${eventTrip.bus.capacity})` : ''}</label><input type="number" min={0} max={eventTrip.bus?.capacity || 120} className="form-control" value={eventForm.passenger_count} onChange={e => setEventForm({ ...eventForm, passenger_count: e.target.value })} /></div>
              <div className="form-field full"><label>Notes</label><input className="form-control" value={eventForm.note} onChange={e => setEventForm({ ...eventForm, note: e.target.value })} placeholder="Optional trip note" /></div>
            </div>
            <div className="modal-footer-actions"><button type="button" className="btn btn-light" onClick={() => setEventTrip(null)}>Cancel</button><button type="submit" className="btn btn-primary">Record Event</button></div>
          </form>
        </Modal>
      )}

      {detailTrip && (
        <Modal title={`Trip Details — ${detailTrip.trip_no}`} wide onClose={() => setDetailTrip(null)}>
          {detailData.stops.length > 0 && <div className="demo-note mt-0 mb-3"><i className="bi bi-geo-alt" /><span><strong>Route Stops:</strong> {detailData.stops.map(rs => `${rs.sequence}. ${rs.stop.name} (+${rs.estimated_offset_min}m)`).join(' → ')}</span></div>}
          {!isDriver && (
            <>
              <h6 className="fw-bold mb-2">Bookings ({detailData.bookings.length})</h6>
              <table className="table align-middle mb-3"><thead><tr><th>REF</th><th>PASSENGER</th><th>CONTACT</th><th>SEATS</th><th>STATUS</th></tr></thead><tbody>{detailData.bookings.length ? detailData.bookings.map(b => <tr key={b.id}><td>{b.booking_ref}</td><td>{b.passenger_name}</td><td>{b.contact_demo}</td><td>{b.quantity}</td><td><StatusBadge status={b.status} /></td></tr>) : <tr><td colSpan={5} className="empty-cell">No bookings.</td></tr>}</tbody></table>
            </>
          )}
          <h6 className="fw-bold mb-2">Operational Events</h6>
          <table className="table align-middle mb-0"><thead><tr><th>EVENT</th><th>DELAY</th><th>PAX</th><th>BY</th><th>NOTE</th></tr></thead><tbody>{detailData.events.length ? detailData.events.map(ev => <tr key={ev.id}><td>{ev.event_type}</td><td>{ev.delay_category || '—'}</td><td>{ev.passenger_count ?? '—'}</td><td>{ev.actor_name}</td><td>{ev.note || '—'}</td></tr>) : <tr><td colSpan={5} className="empty-cell">No events logged yet.</td></tr>}</tbody></table>
        </Modal>
      )}
    </>
  )
}
