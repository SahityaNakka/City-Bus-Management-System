import { useCallback, useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import api, { extractError } from '../api'
import DeleteAction from '../components/DeleteAction'
import ConfirmDialog from '../components/ConfirmDialog'
import DataTable from '../components/DataTable'
import FormField from '../components/FormField'
import Modal from '../components/Modal'
import PageTitle from '../components/PageTitle'
import StatusBadge from '../components/StatusBadge'
import { ROLES, useAuth } from '../context/AuthContext'
import { formatUtcTime } from '../utils/date'

export default function BookingsPage() {
  const { roleName, hasRole } = useAuth()
  const isPassenger = roleName === ROLES.PASSENGER
  const canManageStatus = hasRole([ROLES.ADMIN, ROLES.MANAGER, ROLES.CLERK, ROLES.DISPATCHER])

  const [bookings, setBookings] = useState([])
  const [loading, setLoading] = useState(true)
  const [ticketTarget, setTicketTarget] = useState(null)
  const [cancelTarget, setCancelTarget] = useState(null)
  const [confirmNoShow, setConfirmNoShow] = useState(null)
  const [reason, setReason] = useState('Passenger requested cancellation')
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')

  const loadBookings = useCallback(async () => {
    setLoading(true)
    try {
      const endpoint = isPassenger ? '/bookings/me' : '/bookings'
      const { data } = await api.get(endpoint, { params: { size: 100 } })
      setBookings(
        data.items.map(b => ({
          ...b,
          routeName: b.trip?.route_name || '—',
          tripNo: b.trip?.trip_no || '',
          tripStatus: b.trip?.status || '',
          travelDate: b.trip?.service_date || '',
        }))
      )
    } catch (err) {
      setError(extractError(err))
    } finally {
      setLoading(false)
    }
  }, [isPassenger])

  useEffect(() => {
    loadBookings()
  }, [loadBookings])

  const confirmCancel = async e => {
    e.preventDefault()
    if (reason.trim().length < 3) {
      setError('Cancellation reason must be at least 3 characters.')
      return
    }
    setError('')
    try {
      await api.patch(`/bookings/${cancelTarget.id}/cancel`, { reason })
      setCancelTarget(null)
      setNotice(`Cancelled booking ${cancelTarget.booking_ref}.`)
      loadBookings()
    } catch (err) {
      setError(extractError(err))
    }
  }

  const markStatus = async (bk, status) => {
    setError('')
    try {
      await api.patch(`/bookings/${bk.id}/status`, { status, reason: `Marked ${status} by staff` })
      setConfirmNoShow(null)
      setNotice(`Marked ${bk.booking_ref} as ${status}.`)
      loadBookings()
    } catch (err) {
      setError(extractError(err))
    }
  }

  const columns = [
    { key: 'booking_ref', label: 'BOOKING REF' },
    { key: 'passenger_name', label: 'PASSENGER' },
    { key: 'contact_demo', label: 'CONTACT' },
    { key: 'routeName', label: 'ROUTE' },
    { key: 'tripNo', label: 'TRIP' },
    { key: 'tripStatus', label: 'TRIP STATE', render: v => <StatusBadge status={v} /> },
    { key: 'travelDate', label: 'DATE' },
    { key: 'quantity', label: 'SEATS' },
    { key: 'total_fare', label: 'AMOUNT', render: v => `₹${v}` },
    { key: 'payment_status_demo', label: 'DEMO PAYMENT', render: v => <StatusBadge status={v} /> },
    { key: 'status', label: 'BOOKING', render: v => <StatusBadge status={v} /> },
  ]

  return (
    <>
      <PageTitle
        eyebrow="TICKETS & RESERVATIONS"
        title={isPassenger ? 'My demo bookings & tickets' : 'Passenger bookings'}
        subtitle="View printable demo mTickets, manage boarding statuses, and process 30-minute cutoff cancellations."
        action={<Link to="/search-trips" className="btn btn-primary"><i className="bi bi-plus-lg me-2" />Book Bus Seat</Link>}
      />

      {notice && <div className="alert alert-success py-2">{notice}</div>}
      {error && !cancelTarget && <div className="alert alert-danger py-2">{error}</div>}

      <DataTable
        columns={columns}
        rows={bookings}
        searchKeys={['booking_ref', 'passenger_name', 'contact_demo', 'routeName', 'tripNo']}
        statusKey="status"
        loading={loading}
        tableClassName="bookings-wide-table"
        actions={row => (
          <>
            <button className="table-action" title="View E-Ticket" onClick={() => setTicketTarget(row)}>
              <i className="bi bi-ticket-perforated" /> Ticket
            </button>
            {row.status === 'Confirmed' && (
              <>
                <button className="table-action danger" title="Cancel Booking" onClick={() => { setError(''); setCancelTarget(row) }}>
                  <i className="bi bi-x-circle" /> Cancel
                </button>
                {canManageStatus && (
                  <>
                    <button className="table-action" title="Mark Completed" onClick={() => markStatus(row, 'Completed')}>
                      <i className="bi bi-check-lg" /> Done
                    </button>
                    <button className="table-action" title="Mark No-show" onClick={() => setConfirmNoShow(row)}>
                      <i className="bi bi-person-dash" /> No-show
                    </button>
                  </>
                )}
              </>
            )}
            {canManageStatus && <DeleteAction endpoint={`/bookings/${row.id}`} itemLabel={`booking ${row.booking_ref}`} onDeleted={loadBookings} onError={setError} onNotice={setNotice} />}
          </>
        )}
      />

      {ticketTarget && (
        <Modal title="CityTransit Demo E-Ticket" eyebrow="M-TICKET / BOARDING PASS" onClose={() => setTicketTarget(null)}>
          <div className="eticket-box">
            <div className="eticket-head">
              <div>
                <div style={{ fontSize: 11, opacity: 0.85 }}>BOOKING REFERENCE</div>
                <strong style={{ fontSize: 19 }}>{ticketTarget.booking_ref}</strong>
              </div>
              <StatusBadge status={ticketTarget.status} />
            </div>
            <div className="eticket-body">
              <div><small>Passenger</small><strong>{ticketTarget.passenger_name}</strong></div>
              <div><small>Contact (Demo)</small><strong>{ticketTarget.contact_demo}</strong></div>
              <div><small>Route</small><strong>{ticketTarget.trip?.origin} &rarr; {ticketTarget.trip?.destination}</strong></div>
              <div><small>Service / Trip</small><strong>{ticketTarget.trip?.trip_no} ({ticketTarget.trip?.bus_no || 'Pending'})</strong></div>
              <div><small>Travel Date &amp; Time</small><strong>{ticketTarget.travelDate} &bull; {formatUtcTime(ticketTarget.trip?.departure_at)}</strong></div>
              <div><small>Seats &amp; Fare</small><strong>{ticketTarget.quantity} Seat(s) &bull; ₹{ticketTarget.total_fare}</strong></div>
              <div><small>Demo Payment</small><StatusBadge status={ticketTarget.payment_status_demo} /></div>
              <div><small>Trip Status</small><StatusBadge status={ticketTarget.tripStatus} /></div>
            </div>
          </div>
          <div className="demo-note"><i className="bi bi-info-circle" /> Demo mTicket only — cancellations allowed up to 30 minutes prior to departure.</div>
          <div className="modal-footer-actions">
            <button type="button" className="btn btn-light" onClick={() => setTicketTarget(null)}>Close</button>
            <button type="button" className="btn btn-primary" onClick={() => window.print()}>
              <i className="bi bi-printer me-2" />Print Ticket
            </button>
          </div>
        </Modal>
      )}

      {cancelTarget && (
        <Modal title={`Cancel Booking ${cancelTarget.booking_ref}`} onClose={() => setCancelTarget(null)}>
          {error && <div className="alert alert-danger py-2">{error}</div>}
          <form onSubmit={confirmCancel}>
            <div className="demo-note mt-0 mb-3"><i className="bi bi-clock" /><span>Cancellations close 30 minutes before scheduled departure (unless the trip was cancelled).</span></div>
            <FormField label="Reason" required>
              <input className="form-control" required minLength={3} value={reason} onChange={e => setReason(e.target.value)} />
            </FormField>
            <div className="modal-footer-actions">
              <button type="button" className="btn btn-light" onClick={() => setCancelTarget(null)}>Keep</button>
              <button type="submit" className="btn btn-danger">Confirm Cancellation</button>
            </div>
          </form>
        </Modal>
      )}

      {confirmNoShow && (
        <ConfirmDialog
          title={`Mark No-show — ${confirmNoShow.booking_ref}`}
          message={`Mark passenger "${confirmNoShow.passenger_name}" (${confirmNoShow.quantity} seat(s)) as No-show on trip ${confirmNoShow.tripNo}?`}
          confirmLabel="Mark No-show"
          confirmTone="warning"
          onConfirm={() => markStatus(confirmNoShow, 'No-show')}
          onClose={() => setConfirmNoShow(null)}
        />
      )}
    </>
  )
}
