import { useState } from 'react'
import { Navigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

const DEMO_ROLES = [
  { label: 'Administrator', desc: 'Full system & user control', email: 'admin@citytransit.demo', icon: 'bi-shield-lock-fill' },
  { label: 'Transport Manager', desc: 'Fleet, routes & schedules', email: 'manager@citytransit.demo', icon: 'bi-diagram-3-fill' },
  { label: 'Dispatcher', desc: 'Assign buses & track trips', email: 'dispatcher@citytransit.demo', icon: 'bi-broadcast-pin' },
  { label: 'Driver', desc: 'My trips & arrival logs', email: 'driver1@citytransit.demo', icon: 'bi-person-badge-fill' },
  { label: 'Booking Clerk', desc: 'Counter bookings & boarding', email: 'clerk@citytransit.demo', icon: 'bi-ticket-detailed-fill' },
  { label: 'Passenger', desc: 'Search buses & book seats', email: 'passenger@citytransit.demo', icon: 'bi-person-check-fill' },
  { label: 'Auditor / Viewer', desc: 'Read-only reports & audit', email: 'auditor@citytransit.demo', icon: 'bi-clipboard2-data-fill' },
]

export default function Login() {
  const { user, homePath, login, registerPassenger } = useAuth()
  const [mode, setMode] = useState('login')
  const [name, setName] = useState('')
  const [email, setEmail] = useState('admin@citytransit.demo')
  const [password, setPassword] = useState('demo123')
  const [contactDemo, setContactDemo] = useState('')
  const [showPass, setShowPass] = useState(false)
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const [quickBusyEmail, setQuickBusyEmail] = useState('')

  if (user) return <Navigate to={homePath} replace />

  const handleSubmit = async e => {
    e.preventDefault()
    setError('')
    setBusy(true)
    const res =
      mode === 'login'
        ? await login(email, password)
        : await registerPassenger({ name, email, password, contact_demo: contactDemo })
    setBusy(false)
    if (!res.ok) setError(res.error)
  }

  const handleQuickLogin = async role => {
    setMode('login')
    setEmail(role.email)
    setPassword('demo123')
    setError('')
    setQuickBusyEmail(role.email)
    const res = await login(role.email, 'demo123')
    setQuickBusyEmail('')
    if (!res.ok) setError(res.error)
  }

  return (
    <div className="login-page">
      <div className="login-left">
        <div className="login-brand">
          <div className="brand-mark"><i className="bi bi-bus-front-fill" /></div>
          <span>CityTransit</span>
        </div>

        <div className="login-hero">
          <span className="hero-tag">CITYTRANSIT • PROJECT 22 (DEMO)</span>
          <h1>Book &amp; manage city buses,<br /><em>the smart way.</em></h1>
          <p>
            RedBus &amp; AbhiBus-inspired passenger booking with visual seat selection, paired with a
            complete FastAPI operations portal for routes, fleet, dispatch, and live reports.
          </p>

          <div className="portal-highlights">
            <div className="portal-highlight">
              <i className="bi bi-grid-3x2-gap-fill" />
              <span><strong>Interactive Seat Selection</strong> — Visual bus seat map, boarding stops &amp; instant e-tickets</span>
            </div>
            <div className="portal-highlight">
              <i className="bi bi-speedometer2" />
              <span><strong>Operations &amp; Dispatch</strong> — Overlap conflict checks, fleet status &amp; driver console</span>
            </div>
            <div className="portal-highlight">
              <i className="bi bi-shield-check" />
              <span><strong>Clear Frontend + Backend Split</strong> — React UI synced cleanly with FastAPI + SQL</span>
            </div>
          </div>
        </div>

        <div className="login-left-foot">
          <span>FRONTEND: React + Vite &bull; BACKEND: FastAPI + SQL</span>
          <a
            href="/docs"
            target="_blank"
            rel="noreferrer"
            style={{ color: '#fecdd3', fontWeight: 600 }}
          >
            Backend Swagger API <i className="bi bi-box-arrow-up-right ms-1" />
          </a>
        </div>
      </div>

      <div className="login-right">
        <div className="login-card">
          <div className="auth-tabs">
            <button
              type="button"
              className={`auth-tab ${mode === 'login' ? 'active' : ''}`}
              onClick={() => { setMode('login'); setError('') }}
            >
              <i className="bi bi-box-arrow-in-right me-2" />Sign In
            </button>
            <button
              type="button"
              className={`auth-tab ${mode === 'register' ? 'active' : ''}`}
              onClick={() => { setMode('register'); setError('') }}
            >
              <i className="bi bi-person-plus me-2" />Passenger Sign Up
            </button>
          </div>

          <h2>{mode === 'login' ? 'Sign in to CityTransit' : 'Create passenger account'}</h2>
          <p className="muted">
            {mode === 'login'
              ? 'Enter your credentials below or click any Demo Role card to enter directly.'
              : 'Register a demo passenger account to search schedules and reserve bus seats.'}
          </p>

          {error && <div className="alert alert-danger py-2">{error}</div>}

          <form onSubmit={handleSubmit}>
            {mode === 'register' && (
              <div className="mb-3">
                <label className="login-label">Full name</label>
                <div className="login-input">
                  <i className="bi bi-person" />
                  <input value={name} onChange={e => setName(e.target.value)} required placeholder="e.g. Aarav Mehta" />
                </div>
              </div>
            )}

            <div className="mb-3">
              <label className="login-label">Email address</label>
              <div className="login-input">
                <i className="bi bi-envelope" />
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="name@citytransit.demo"
                  required
                />
              </div>
            </div>

            <div className="mb-3">
              <label className="login-label">Password</label>
              <div className="login-input">
                <i className="bi bi-lock" />
                <input
                  type={showPass ? 'text' : 'password'}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  required
                />
                <button
                  type="button"
                  className="pass-toggle"
                  onClick={() => setShowPass(s => !s)}
                  title={showPass ? 'Hide password' : 'Show password'}
                >
                  <i className={`bi ${showPass ? 'bi-eye-slash' : 'bi-eye'}`} />
                </button>
              </div>
            </div>

            {mode === 'register' && (
              <div className="mb-3">
                <label className="login-label">Demo contact number</label>
                <div className="login-input">
                  <i className="bi bi-telephone" />
                  <input value={contactDemo} onChange={e => setContactDemo(e.target.value)} required placeholder="e.g. 9000000188" />
                </div>
              </div>
            )}

            <button className="btn btn-primary w-100 login-submit mt-1" disabled={busy || !!quickBusyEmail}>
              {busy ? 'Signing in...' : mode === 'login' ? 'Sign In to Portal' : 'Create Passenger Account'}
              <i className="bi bi-arrow-right ms-2" />
            </button>
          </form>

          <div className="demo-credentials">
            <div className="demo-credentials-head">
              <strong><i className="bi bi-lightning-charge-fill text-warning me-1" />1-Click Demo Portal Logins</strong>
              <span className="soft-label">Password: <code>demo123</code></span>
            </div>

            <div className="role-quick-grid">
              {DEMO_ROLES.map(r => {
                const isLoading = quickBusyEmail === r.email
                return (
                  <button
                    key={r.email}
                    type="button"
                    className="role-quick-btn"
                    disabled={busy || !!quickBusyEmail}
                    onClick={() => handleQuickLogin(r)}
                  >
                    <i className={`bi ${isLoading ? 'bi-hourglass-split' : r.icon}`} />
                    <div>
                      <strong>{isLoading ? 'Signing in...' : r.label}</strong>
                      <small>{r.desc}</small>
                    </div>
                  </button>
                )
              })}
            </div>
          </div>

          <div className="login-security">
            <i className="bi bi-shield-check text-success" />
            Demo environment only — fictional schedules, payments & GPS tracking.
          </div>
        </div>
      </div>
    </div>
  )
}
