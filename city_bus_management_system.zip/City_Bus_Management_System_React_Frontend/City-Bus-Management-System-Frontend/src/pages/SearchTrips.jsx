import { Fragment, useCallback, useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import api, { extractError } from '../api'
import FilterBar from '../components/FilterBar'
import FormField from '../components/FormField'
import Modal from '../components/Modal'
import PageTitle from '../components/PageTitle'
import StatusBadge from '../components/StatusBadge'
import { ROLES, useAuth } from '../context/AuthContext'
import { formatDuration, formatUtcTime, localIsoDate } from '../utils/date'

const POPULAR_CORRIDORS = [
  { label: 'Miyapur → Airport', origin: 'Miyapur', destination: 'Airport' },
  { label: 'Secunderabad → Mehdipatnam', origin: 'Secunderabad', destination: 'Mehdipatnam' },
  { label: 'Kukatpally → Gachibowli', origin: 'Kukatpally', destination: 'Gachibowli' },
]

function buildSeatLabels(capacity) {
  const cols = ['A', 'B', 'C', 'D']
  return Array.from({ length: capacity }, (_, i) => `${Math.floor(i / 4) + 1}${cols[i % 4]}`)
}

export default function SearchTrips() {
  const { user, hasRole } = useAuth()
  const canBook = hasRole([ROLES.PASSENGER, ROLES.CLERK, ROLES.ADMIN, ROLES.MANAGER])
  const todayIso = localIsoDate(0)
  const tomorrowIso = localIsoDate(1)

  const [origin, setOrigin] = useState('')
  const [destination, setDestination] = useState('')
  const [date, setDate] = useState('')
  const [busTypeFilter, setBusTypeFilter] = useState('')
  const [onlyAvailable, setOnlyAvailable] = useState(false)
  const [sortBy, setSortBy] = useState('departure')
  const [expandedTripId, setExpandedTripId] = useState(null)

  const [trips, setTrips] = useState([])
  const [loading, setLoading] = useState(true)
  const [listError, setListError] = useState('')

  const [bookTrip, setBookTrip] = useState(null)
  const [selectedSeats, setSelectedSeats] = useState([])
  const [form, setForm] = useState({ passenger_name: '', contact_demo: '', quantity: 1 })
  const [idemKey, setIdemKey] = useState('')
  const [message, setMessage] = useState('')
  const [error, setError] = useState('')
  const [submitting, setSubmitting] = useState(false)

  const search = useCallback(async () => {
    setLoading(true)
    setListError('')
    try {
      const { data } = await api.get('/public/trips/search', {
        params: {
          origin: origin || undefined,
          destination: destination || undefined,
          service_date: date || undefined,
        },
      })
      setTrips(data)
    } catch (err) {
      setListError(extractError(err, 'Could not search published trips.'))
    } finally {
      setLoading(false)
    }
  }, [origin, destination, date])

  useEffect(() => {
    search()
  }, [search])

  const filteredTrips = useMemo(() => {
    const list = trips.filter(t => {
      if (busTypeFilter && t.bus?.bus_type !== busTypeFilter) return false
      if (onlyAvailable && (!t.bus || (t.available_seats ?? 0) <= 0 || t.status === 'Cancelled')) return false
      return true
    })
    return [...list].sort((a, b) => {
      if (sortBy === 'fare_asc') return Number(a.fare_snapshot) - Number(b.fare_snapshot)
      if (sortBy === 'fare_desc') return Number(b.fare_snapshot) - Number(a.fare_snapshot)
      if (sortBy === 'seats_desc') return (b.available_seats ?? 0) - (a.available_seats ?? 0)
      return new Date(a.departure_at) - new Date(b.departure_at)
    })
  }, [trips, busTypeFilter, onlyAvailable, sortBy])

  const swapCities = () => {
    setOrigin(destination)
    setDestination(origin)
  }

  const openBook = trip => {
    setError('')
    setBookTrip(trip)
    const cap = trip.bus?.capacity || 40
    const avail = trip.available_seats ?? 0
    const occupied = Math.max(0, cap - avail)
    const labels = buildSeatLabels(cap)
    const firstOpen = avail > 0 ? [labels[occupied]] : []
    setSelectedSeats(firstOpen)
    setForm({ passenger_name: user?.name || '', contact_demo: user?.contact_demo || '', quantity: firstOpen.length || 1 })
    setIdemKey(`ct-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`)
  }

  const toggleSeat = label => {
    setError('')
    const maxSeats = Math.min(10, bookTrip?.available_seats || 10)
    setSelectedSeats(prev => {
      let next
      if (prev.includes(label)) {
        next = prev.filter(s => s !== label)
      } else {
        if (prev.length >= maxSeats) {
          setError(`Maximum ${maxSeats} seat(s) can be selected in one booking.`)
          return prev
        }
        next = [...prev, label]
      }
      setForm(f => ({ ...f, quantity: Math.max(1, next.length) }))
      return next
    })
  }

  const submitBook = async e => {
    e.preventDefault()
    if (form.passenger_name.trim().length < 2) {
      setError('Passenger name must be at least 2 characters.')
      return
    }
    if (form.contact_demo.trim().length < 5) {
      setError('Demo contact must be at least 5 characters.')
      return
    }
    const qty = selectedSeats.length > 0 ? selectedSeats.length : Number(form.quantity)
    if (qty < 1) {
      setError('Please select at least 1 seat.')
      return
    }
    setError('')
    setSubmitting(true)
    try {
      const { data } = await api.post(
        '/bookings',
        {
          trip_id: bookTrip.id,
          passenger_name: form.passenger_name,
          contact_demo: form.contact_demo,
          quantity: qty,
        },
        { headers: { 'Idempotency-Key': idemKey } }
      )
      const seatsText = selectedSeats.length ? ` [Seats: ${selectedSeats.join(', ')}]` : ''
      setBookTrip(null)
      setMessage(`Demo booking confirmed! Ref: ${data.booking_ref}${seatsText} (${data.quantity} seat(s), ₹${data.total_fare} — ${data.payment_status_demo})`)
      search()
    } catch (err) {
      setError(extractError(err))
    } finally {
      setSubmitting(false)
    }
  }

  const seatDeckInfo = useMemo(() => {
    if (!bookTrip?.bus) return null
    const cap = bookTrip.bus.capacity
    const avail = bookTrip.available_seats ?? 0
    const occupiedCount = Math.max(0, cap - avail)
    const labels = buildSeatLabels(cap)
    return labels.map((label, idx) => ({
      label,
      isBooked: idx < occupiedCount,
      colIndex: idx % 4,
    }))
  }, [bookTrip])

  return (
    <>
      <PageTitle
        eyebrow="PASSENGER BOOKING PORTAL"
        title="Search & book city buses"
        subtitle="Compare routes, boarding stops, bus types, live seat availability, and select seats."
      />

      {/* RedBus / AbhiBus Hero Search Bar */}
      <div className="rb-hero-search">
        <div className="rb-search-top">
          <h2><i className="bi bi-bus-front-fill me-2" />Where are you travelling today?</h2>
          <div className="d-flex gap-2">
            <button type="button" className={`rb-chip ${date === todayIso ? 'active' : ''}`} onClick={() => setDate(todayIso)}>Today</button>
            <button type="button" className={`rb-chip ${date === tomorrowIso ? 'active' : ''}`} onClick={() => setDate(tomorrowIso)}>Tomorrow</button>
            <button type="button" className={`rb-chip ${date === '' ? 'active' : ''}`} onClick={() => setDate('')}>All Dates</button>
          </div>
        </div>

        <div className="rb-search-bar">
          <div className="rb-input-box">
            <label><i className="bi bi-geo-alt me-1" />From (Origin)</label>
            <input placeholder="e.g. Miyapur, Secunderabad" value={origin} onChange={e => setOrigin(e.target.value)} />
          </div>

          <button type="button" className="rb-swap-btn" onClick={swapCities} title="Swap Origin & Destination" aria-label="Swap">
            <i className="bi bi-arrow-left-right" />
          </button>

          <div className="rb-input-box">
            <label><i className="bi bi-pin-map me-1" />To (Destination)</label>
            <input placeholder="e.g. Airport, Gachibowli" value={destination} onChange={e => setDestination(e.target.value)} />
          </div>

          <div className="rb-input-box">
            <label><i className="bi bi-calendar-event me-1" />Journey Date</label>
            <input type="date" value={date} onChange={e => setDate(e.target.value)} />
          </div>

          <button type="button" className="btn btn-primary rb-search-cta" onClick={search}>
            <i className="bi bi-search me-2" />Search Buses
          </button>
        </div>

        <div className="rb-popular-row">
          <span style={{ opacity: 0.9 }}>Popular Routes:</span>
          {POPULAR_CORRIDORS.map(c => (
            <button
              key={c.label}
              type="button"
              className="rb-chip"
              onClick={() => { setOrigin(c.origin); setDestination(c.destination) }}
            >
              {c.label}
            </button>
          ))}
          {(origin || destination || date) && (
            <button
              type="button"
              className="rb-chip"
              onClick={() => { setOrigin(''); setDestination(''); setDate('') }}
            >
              Clear All
            </button>
          )}
        </div>
      </div>

      {/* Filter & Sort Strip */}
      <FilterBar onReset={() => { setBusTypeFilter(''); setOnlyAvailable(false); setSortBy('departure') }}>
        <div>
          <label className="login-label">Bus Type</label>
          <select className="form-select form-select-sm" value={busTypeFilter} onChange={e => setBusTypeFilter(e.target.value)}>
            <option value="">All Bus Types</option>
            {['AC Seater', 'Non-AC', 'Electric', 'Mini Bus'].map(bt => (
              <option key={bt} value={bt}>{bt}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="login-label">Sort By</label>
          <select className="form-select form-select-sm" value={sortBy} onChange={e => setSortBy(e.target.value)}>
            <option value="departure">Earliest Departure</option>
            <option value="fare_asc">Lowest Fare first</option>
            <option value="fare_desc">Highest Fare first</option>
            <option value="seats_desc">Most Seats Available</option>
          </select>
        </div>

        <div className="form-check mb-1">
          <input
            id="availOnly"
            type="checkbox"
            className="form-check-input"
            checked={onlyAvailable}
            onChange={e => setOnlyAvailable(e.target.checked)}
          />
          <label htmlFor="availOnly" className="form-check-label" style={{ fontSize: 13, fontWeight: 600 }}>
            Bookable Seats Only
          </label>
        </div>
      </FilterBar>

      {message && (
        <div className="alert alert-success d-flex justify-content-between align-items-center flex-wrap gap-2">
          <span><i className="bi bi-check-circle-fill me-2" />{message}</span>
          <Link to="/bookings" className="btn btn-sm btn-success fw-semibold">View E-Ticket &rarr;</Link>
        </div>
      )}
      {listError && <div className="alert alert-danger">{listError}</div>}

      <div className="section-heading">
        <div>
          <h3>{filteredTrips.length} Bus Service(s) Found</h3>
          <p>{date ? `Filtered for ${date}` : 'Showing all upcoming published schedules'}</p>
        </div>
      </div>

      <div className="trip-results">
        {loading ? (
          <div className="content-card empty-state"><div className="spinner-border text-primary mb-2" /><strong>Finding available buses...</strong></div>
        ) : filteredTrips.length ? filteredTrips.map(t => {
          const route = t.schedule?.route
          const stops = route?.route_stops || []
          const avail = t.available_seats ?? 0
          const bookable = t.bus && avail > 0 && t.status !== 'Cancelled'
          const depShort = String(t.schedule?.departure_time || '').slice(0, 5)
          const estArr = formatUtcTime(t.estimated_arrival_at)
          const isExpanded = expandedTripId === t.id

          return (
            <div className="rb-trip-card" key={t.id}>
              <div className="rb-card-main">
                <div>
                  <div className="rb-operator-title">
                    <strong>{route?.name}</strong>
                    <span className="rb-rating-pill"><i className="bi bi-star-fill me-1" />4.6</span>
                    <StatusBadge status={t.status} />
                  </div>
                  <div style={{ fontSize: 13, color: 'var(--text-muted)' }}>
                    <span className="fw-semibold text-dark">{route?.route_code}</span> &bull;{' '}
                    {t.bus ? `${t.bus.bus_type} (${t.bus.bus_no})` : 'Bus Pending Assignment'} &bull; {t.trip_no}
                    {route?.distance_note ? ` • ${route.distance_note}` : ''}
                  </div>
                </div>

                <div className="rb-timeline">
                  <div className="rb-time-col">
                    <strong>{depShort}</strong>
                    <span>{route?.origin}</span>
                  </div>
                  <div className="rb-duration-line">
                    <small>{formatDuration(t.schedule?.duration_min)} &bull; {stops.length} Stops</small>
                    <div className="rb-track-bar" />
                    <small className="mt-1 mb-0">{t.service_date}</small>
                  </div>
                  <div className="rb-time-col text-end">
                    <strong>{estArr}</strong>
                    <span>{route?.destination}</span>
                  </div>
                </div>

                <div className="rb-price-col">
                  <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>Starts from</div>
                  <div className="rb-fare">₹{t.fare_snapshot}</div>
                  <div className="rb-seats-left">
                    {t.bus ? `${avail} of ${t.bus.capacity} seats available` : 'Awaiting Bus Assignment'}
                  </div>
                  <div>
                    {canBook && (
                      <button
                        className="btn btn-primary btn-sm px-3 fw-semibold"
                        onClick={() => openBook(t)}
                        disabled={!bookable}
                      >
                        <i className="bi bi-grid-3x2-gap me-1" />
                        {bookable ? 'Select Seats' : 'Unavailable'}
                      </button>
                    )}
                  </div>
                </div>
              </div>

              <div className="rb-card-footer">
                <div className="d-flex flex-wrap gap-3 align-items-center">
                  <button
                    type="button"
                    className="btn btn-link btn-sm p-0 fw-semibold"
                    onClick={() => setExpandedTripId(isExpanded ? null : t.id)}
                  >
                    <i className={`bi ${isExpanded ? 'bi-chevron-up' : 'bi-chevron-down'} me-1`} />
                    Boarding &amp; Dropping Stops ({stops.length})
                  </button>
                  <span className="text-muted"><i className="bi bi-shield-check text-success me-1" />Free demo cancellation &ge; 30m prior</span>
                </div>
                <span className="soft-label">DEMO BOOKING</span>
              </div>

              {isExpanded && (
                <div className="rb-stops-drawer">
                  {stops.length ? stops.map(rs => (
                    <div className="rb-stop-pill" key={rs.id || rs.sequence}>
                      <span className="rb-stop-num">{rs.sequence}</span>
                      <div>
                        <strong>{rs.stop?.name}</strong> <span className="text-muted">({rs.stop?.area})</span>
                        <div className="text-muted" style={{ fontSize: 11 }}>+{rs.estimated_offset_min} min from start</div>
                      </div>
                    </div>
                  )) : <span className="text-muted">No stops recorded.</span>}
                </div>
              )}
            </div>
          )
        }) : (
          <div className="content-card empty-state">
            <i className="bi bi-bus-front" />
            <strong>No matching buses found</strong>
            <span>Try clicking &quot;All Dates&quot; or clearing your origin/destination filters.</span>
          </div>
        )}
      </div>

      <div className="demo-note">
        <i className="bi bi-exclamation-circle" />
        Demo booking &amp; mock payment system only — NOT live transit. Cancellations close 30 minutes before departure.
      </div>

      {/* Interactive Seat Map & Reservation Modal */}
      {bookTrip && (
        <Modal title={`Select Seats — ${bookTrip.trip_no}`} eyebrow={`${bookTrip.schedule?.route?.origin} → ${bookTrip.schedule?.route?.destination}`} wide onClose={() => setBookTrip(null)}>
          {error && <div className="alert alert-danger py-2">{error}</div>}
          <form onSubmit={submitBook}>
            <div className="seat-layout-wrap">
              <div className="seat-deck">
                <div className="seat-deck-head">
                  <span>LOWER DECK ({bookTrip.bus?.bus_type})</span>
                  <span><i className="bi bi-record-circle me-1" />Driver Front</span>
                </div>
                <div className="seat-grid">
                  {(seatDeckInfo || []).map(seat => {
                    const isSelected = selectedSeats.includes(seat.label)
                    return (
                      <Fragment key={seat.label}>
                        {seat.colIndex === 2 && <div className="seat-aisle" />}
                        <button
                          type="button"
                          disabled={seat.isBooked}
                          className={`seat-btn ${seat.isBooked ? 'booked' : isSelected ? 'selected' : ''}`}
                          onClick={() => toggleSeat(seat.label)}
                          title={seat.isBooked ? 'Already Booked' : `Seat ${seat.label}`}
                        >
                          {seat.label}
                        </button>
                      </Fragment>
                    )
                  })}
                </div>
                <div className="seat-legend">
                  <span><i className="seat-dot" style={{ border: '1.5px solid #16a34a', background: '#fff' }} /> Available</span>
                  <span><i className="seat-dot" style={{ background: 'var(--primary)' }} /> Selected</span>
                  <span><i className="seat-dot" style={{ background: '#e2e8f0' }} /> Booked</span>
                </div>
              </div>

              <div>
                <div className="mb-3 p-2 rounded border bg-light" style={{ fontSize: 12.5 }}>
                  <div><strong>Boarding:</strong> {bookTrip.schedule?.route?.route_stops?.[0]?.stop?.name || bookTrip.schedule?.route?.origin} ({String(bookTrip.schedule?.departure_time || '').slice(0, 5)})</div>
                  <div><strong>Dropping:</strong> {bookTrip.schedule?.route?.route_stops?.slice(-1)?.[0]?.stop?.name || bookTrip.schedule?.route?.destination} ({formatUtcTime(bookTrip.estimated_arrival_at)})</div>
                  <div className="mt-1"><strong>Selected Seats:</strong> {selectedSeats.length ? selectedSeats.join(', ') : 'None selected'}</div>
                </div>

                <div className="form-grid">
                  <FormField label="Passenger Name" required full>
                    <input className="form-control" required minLength={2} value={form.passenger_name} onChange={e => setForm({ ...form, passenger_name: e.target.value })} />
                  </FormField>
                  <FormField label="Demo Contact" required hint="Fictional contact for demo" full>
                    <input className="form-control" required minLength={5} value={form.contact_demo} onChange={e => setForm({ ...form, contact_demo: e.target.value })} />
                  </FormField>
                  <FormField label="Seat Count">
                    <input className="form-control" disabled value={selectedSeats.length || form.quantity} />
                  </FormField>
                  <FormField label="Total Demo Fare">
                    <input className="form-control fw-bold" disabled value={`₹${(Number(bookTrip.fare_snapshot) * (selectedSeats.length || Number(form.quantity || 1))).toFixed(2)}`} />
                  </FormField>
                </div>
              </div>
            </div>

            <div className="modal-footer-actions">
              <button type="button" className="btn btn-light" onClick={() => setBookTrip(null)}>Cancel</button>
              <button type="submit" className="btn btn-primary" disabled={submitting || selectedSeats.length === 0}>
                {submitting ? 'Confirming...' : `Confirm Booking (${selectedSeats.length} Seat${selectedSeats.length === 1 ? '' : 's'})`}
              </button>
            </div>
          </form>
        </Modal>
      )}
    </>
  )
}
