import { useCallback, useEffect, useState } from 'react'
import api, { extractError } from '../api'
import DeleteAction from '../components/DeleteAction'
import DataTable from '../components/DataTable'
import Modal from '../components/Modal'
import PageTitle from '../components/PageTitle'
import StatusBadge from '../components/StatusBadge'
import { ROLES, useAuth } from '../context/AuthContext'

const EMPTY_FORM = { route_code: '', name: '', origin: '', destination: '', distance_note: '', active: true }

export default function RoutesPage() {
  const { hasRole } = useAuth()
  const canEdit = hasRole([ROLES.ADMIN, ROLES.MANAGER])

  const [routes, setRoutes] = useState([])
  const [allStops, setAllStops] = useState([])
  const [loading, setLoading] = useState(true)
  const [modalRoute, setModalRoute] = useState(null)
  const [form, setForm] = useState(EMPTY_FORM)
  const [stopsModalRoute, setStopsModalRoute] = useState(null)
  const [routeStops, setRouteStops] = useState([])
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')

  const loadRoutes = useCallback(async () => {
    setLoading(true)
    try {
      const [rRes, sRes] = await Promise.all([
        api.get('/routes', { params: { size: 100 } }),
        api.get('/stops', { params: { active: true, size: 200 } }),
      ])
      setRoutes(rRes.data.items.map(r => ({ ...r, statusLabel: r.active ? 'Active' : 'Inactive' })))
      setAllStops(sRes.data.items)
    } catch (err) {
      setError(extractError(err, 'Could not load routes.'))
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    loadRoutes()
  }, [loadRoutes])

  const openRouteModal = (rt = null) => {
    setError('')
    setModalRoute(rt || {})
    setForm(
      rt
        ? { route_code: rt.route_code, name: rt.name, origin: rt.origin, destination: rt.destination, distance_note: rt.distance_note || '', active: rt.active }
        : EMPTY_FORM
    )
  }

  const saveRoute = async e => {
    e.preventDefault()
    setError('')
    try {
      if (modalRoute?.id) {
        await api.patch(`/routes/${modalRoute.id}`, {
          name: form.name, origin: form.origin, destination: form.destination,
          distance_note: form.distance_note || null, active: form.active,
        })
      } else {
        await api.post('/routes', form)
      }
      setModalRoute(null)
      setNotice('Route saved successfully.')
      loadRoutes()
    } catch (err) {
      setError(extractError(err))
    }
  }

  const openStopsModal = async rt => {
    setError('')
    setStopsModalRoute(rt)
    const { data } = await api.get(`/routes/${rt.id}/stops`)
    setRouteStops(data.map(rs => ({ stop_id: rs.stop_id, sequence: rs.sequence, estimated_offset_min: rs.estimated_offset_min })))
  }

  const saveStops = async () => {
    setError('')
    try {
      await api.put(`/routes/${stopsModalRoute.id}/stops`, routeStops)
      setStopsModalRoute(null)
      setNotice(`Updated ordered stops for ${stopsModalRoute.route_code}.`)
      loadRoutes()
    } catch (err) {
      setError(extractError(err))
    }
  }

  const columns = [
    { key: 'route_code', label: 'ROUTE CODE' },
    { key: 'name', label: 'ROUTE NAME' },
    { key: 'origin', label: 'ORIGIN' },
    { key: 'destination', label: 'DESTINATION' },
    { key: 'stops_count', label: 'STOPS' },
    { key: 'statusLabel', label: 'STATUS', render: v => <StatusBadge status={v} /> },
  ]

  return (
    <>
      <PageTitle
        title="Route management"
        subtitle="Configure routes and ordered stop sequences (>= 2 distinct active stops required before publishing)."
        action={canEdit && <button className="btn btn-primary" onClick={() => openRouteModal()}><i className="bi bi-plus-lg me-2" />Add Route</button>}
      />

      {notice && <div className="alert alert-success py-2">{notice}</div>}
      {error && !modalRoute && !stopsModalRoute && <div className="alert alert-danger py-2">{error}</div>}

      <DataTable
        columns={columns}
        rows={routes}
        searchKeys={['route_code', 'name', 'origin', 'destination']}
        statusKey="statusLabel"
        loading={loading}
        actions={row => (
          <>
            <button className="table-action" title="Ordered Stops" onClick={() => openStopsModal(row)}><i className="bi bi-list-ol" /></button>
            {canEdit && <button className="table-action" title="Edit" onClick={() => openRouteModal(row)}><i className="bi bi-pencil" /></button>}
            {canEdit && <DeleteAction endpoint={`/routes/${row.id}`} itemLabel={`route ${row.route_code}`} onDeleted={loadRoutes} onError={setError} onNotice={setNotice} />}
          </>
        )}
      />

      {modalRoute && (
        <Modal title={modalRoute.id ? `Edit Route ${modalRoute.route_code}` : 'Create Route'} onClose={() => setModalRoute(null)}>
          {error && <div className="alert alert-danger py-2">{error}</div>}
          <form onSubmit={saveRoute}>
            <div className="form-grid">
              {!modalRoute.id && (
                <div className="form-field">
                  <label>Route Code <span>*</span></label>
                  <input className="form-control" required value={form.route_code} onChange={e => setForm({ ...form, route_code: e.target.value })} placeholder="R-04" />
                </div>
              )}
              <div className="form-field">
                <label>Route Name <span>*</span></label>
                <input className="form-control" required value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} />
              </div>
              <div className="form-field">
                <label>Origin <span>*</span></label>
                <input className="form-control" required value={form.origin} onChange={e => setForm({ ...form, origin: e.target.value })} />
              </div>
              <div className="form-field">
                <label>Destination <span>*</span></label>
                <input className="form-control" required value={form.destination} onChange={e => setForm({ ...form, destination: e.target.value })} />
              </div>
              <div className="form-field">
                <label>Distance Note</label>
                <input className="form-control" value={form.distance_note} onChange={e => setForm({ ...form, distance_note: e.target.value })} placeholder="15 km" />
              </div>
              <div className="form-field">
                <label>Status</label>
                <select className="form-select" value={String(form.active)} onChange={e => setForm({ ...form, active: e.target.value === 'true' })}>
                  <option value="true">Active</option>
                  <option value="false">Inactive</option>
                </select>
              </div>
            </div>
            <div className="modal-footer-actions">
              <button type="button" className="btn btn-light" onClick={() => setModalRoute(null)}>Cancel</button>
              <button type="submit" className="btn btn-primary">Save Route</button>
            </div>
          </form>
        </Modal>
      )}

      {stopsModalRoute && (
        <Modal title={`Ordered Stops — ${stopsModalRoute.route_code}`} wide onClose={() => setStopsModalRoute(null)}>
          {error && <div className="alert alert-danger py-2">{error}</div>}
          <table className="table align-middle mb-0">
            <thead><tr><th>SEQ</th><th>STOP</th><th>OFFSET (MIN)</th>{canEdit && <th />}</tr></thead>
            <tbody>
              {routeStops.map((rs, idx) => (
                <tr key={idx}>
                  <td><input type="number" min={1} className="form-control" style={{ width: 70 }} disabled={!canEdit} value={rs.sequence} onChange={e => { const next = [...routeStops]; next[idx].sequence = Number(e.target.value); setRouteStops(next) }} /></td>
                  <td>
                    <select className="form-select" disabled={!canEdit} value={rs.stop_id} onChange={e => { const next = [...routeStops]; next[idx].stop_id = Number(e.target.value); setRouteStops(next) }}>
                      {allStops.map(s => <option key={s.id} value={s.id}>{s.stop_code} — {s.name}</option>)}
                    </select>
                  </td>
                  <td><input type="number" min={0} className="form-control" style={{ width: 90 }} disabled={!canEdit} value={rs.estimated_offset_min} onChange={e => { const next = [...routeStops]; next[idx].estimated_offset_min = Number(e.target.value); setRouteStops(next) }} /></td>
                  {canEdit && <td><button type="button" className="table-action danger" onClick={() => setRouteStops(routeStops.filter((_, i) => i !== idx))}><i className="bi bi-trash3" /></button></td>}
                </tr>
              ))}
            </tbody>
          </table>
          {canEdit && (
            <div className="modal-footer-actions" style={{ justifyContent: 'space-between' }}>
              <button
                type="button"
                className="btn btn-light"
                onClick={() => allStops.length && setRouteStops([...routeStops, { stop_id: allStops[0].id, sequence: routeStops.length + 1, estimated_offset_min: routeStops.length * 15 }])}
              >
                + Add Stop
              </button>
              <div style={{ display: 'flex', gap: 8 }}>
                <button type="button" className="btn btn-light" onClick={() => setStopsModalRoute(null)}>Cancel</button>
                <button type="button" className="btn btn-primary" disabled={!routeStops.length} onClick={saveStops}>Save Ordered Stops</button>
              </div>
            </div>
          )}
        </Modal>
      )}
    </>
  )
}
