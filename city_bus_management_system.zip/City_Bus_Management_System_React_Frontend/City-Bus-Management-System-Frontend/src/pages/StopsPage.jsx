import { useCallback, useEffect, useState } from 'react'
import api, { extractError } from '../api'
import DeleteAction from '../components/DeleteAction'
import DataTable from '../components/DataTable'
import Modal from '../components/Modal'
import PageTitle from '../components/PageTitle'
import StatusBadge from '../components/StatusBadge'
import { ROLES, useAuth } from '../context/AuthContext'

const EMPTY_FORM = { stop_code: '', name: '', area: '', active: true }

export default function StopsPage() {
  const { hasRole } = useAuth()
  const canEdit = hasRole([ROLES.ADMIN, ROLES.MANAGER])

  const [stops, setStops] = useState([])
  const [loading, setLoading] = useState(true)
  const [modalStop, setModalStop] = useState(null)
  const [form, setForm] = useState(EMPTY_FORM)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')

  const loadStops = useCallback(async () => {
    setLoading(true)
    try {
      const { data } = await api.get('/stops', { params: { size: 200 } })
      setStops(data.items.map(s => ({ ...s, statusLabel: s.active ? 'Active' : 'Inactive' })))
    } catch (err) {
      setError(extractError(err, 'Could not load stops.'))
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    loadStops()
  }, [loadStops])

  const openModal = (stop = null) => {
    setError('')
    setModalStop(stop || {})
    setForm(stop ? { stop_code: stop.stop_code, name: stop.name, area: stop.area, active: stop.active } : EMPTY_FORM)
  }

  const saveStop = async e => {
    e.preventDefault()
    setError('')
    try {
      if (modalStop?.id) await api.patch(`/stops/${modalStop.id}`, { name: form.name, area: form.area, active: form.active })
      else await api.post('/stops', form)
      setModalStop(null)
      setNotice('Stop saved successfully.')
      loadStops()
    } catch (err) {
      setError(extractError(err))
    }
  }

  const columns = [
    { key: 'stop_code', label: 'STOP CODE' },
    { key: 'name', label: 'STOP NAME' },
    { key: 'area', label: 'AREA' },
    { key: 'statusLabel', label: 'STATUS', render: v => <StatusBadge status={v} /> },
  ]

  return (
    <>
      <PageTitle
        title="Bus stop management"
        subtitle="Maintain city stop codes, areas, and active availability."
        action={canEdit && <button className="btn btn-primary" onClick={() => openModal()}><i className="bi bi-plus-lg me-2" />Add Stop</button>}
      />

      {notice && <div className="alert alert-success py-2">{notice}</div>}
      {error && !modalStop && <div className="alert alert-danger py-2">{error}</div>}

      <DataTable
        columns={columns}
        rows={stops}
        searchKeys={['stop_code', 'name', 'area']}
        statusKey="statusLabel"
        loading={loading}
        actions={canEdit ? row => (
          <>
            <button className="table-action" title="Edit" onClick={() => openModal(row)}><i className="bi bi-pencil" /></button>
            <DeleteAction endpoint={`/stops/${row.id}`} itemLabel={`stop ${row.stop_code}`} onDeleted={loadStops} onError={setError} onNotice={setNotice} />
          </>
        ) : null}
      />

      {modalStop && (
        <Modal title={modalStop.id ? `Edit Stop ${modalStop.stop_code}` : 'Add Bus Stop'} onClose={() => setModalStop(null)}>
          {error && <div className="alert alert-danger py-2">{error}</div>}
          <form onSubmit={saveStop}>
            <div className="form-grid">
              {!modalStop.id && (
                <div className="form-field">
                  <label>Stop Code <span>*</span></label>
                  <input className="form-control" required value={form.stop_code} onChange={e => setForm({ ...form, stop_code: e.target.value })} placeholder="ST-007" />
                </div>
              )}
              <div className="form-field">
                <label>Stop Name <span>*</span></label>
                <input className="form-control" required value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} />
              </div>
              <div className="form-field">
                <label>Area / Locality <span>*</span></label>
                <input className="form-control" required value={form.area} onChange={e => setForm({ ...form, area: e.target.value })} />
              </div>
              <div className="form-field">
                <label>Status</label>
                <select className="form-select" value={String(form.active)} onChange={e => setForm({ ...form, active: e.target.value === 'true' })}>
                  <option value="true">Active</option>
                  <option value="false">Inactive</option>
                </select>
              </div>
            </div>
            <div className="modal-footer-actions">
              <button type="button" className="btn btn-light" onClick={() => setModalStop(null)}>Cancel</button>
              <button type="submit" className="btn btn-primary">Save Stop</button>
            </div>
          </form>
        </Modal>
      )}
    </>
  )
}
