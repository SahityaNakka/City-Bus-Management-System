import { useCallback, useEffect, useState } from 'react'
import api, { extractError } from '../api'
import DeleteAction from '../components/DeleteAction'
import DataTable from '../components/DataTable'
import Modal from '../components/Modal'
import PageTitle from '../components/PageTitle'
import StatusBadge from '../components/StatusBadge'
import { ROLES, useAuth } from '../context/AuthContext'

const EMPTY_FORM = { bus_no: '', registration_demo: '', bus_type: 'AC Seater', capacity: 40, status: 'Available' }

export default function BusesPage() {
  const { hasRole } = useAuth()
  const canEdit = hasRole([ROLES.ADMIN, ROLES.MANAGER])

  const [buses, setBuses] = useState([])
  const [loading, setLoading] = useState(true)
  const [modalBus, setModalBus] = useState(null)
  const [form, setForm] = useState(EMPTY_FORM)
  const [historyBus, setHistoryBus] = useState(null)
  const [history, setHistory] = useState([])
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')

  const loadBuses = useCallback(async () => {
    setLoading(true)
    try {
      const { data } = await api.get('/buses', { params: { size: 100 } })
      setBuses(data.items)
    } catch (err) {
      setError(extractError(err, 'Could not load buses.'))
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    loadBuses()
  }, [loadBuses])

  const openModal = (bus = null) => {
    setError('')
    setModalBus(bus || {})
    setForm(bus ? { bus_no: bus.bus_no, registration_demo: bus.registration_demo, bus_type: bus.bus_type, capacity: bus.capacity, status: bus.status } : EMPTY_FORM)
  }

  const saveBus = async e => {
    e.preventDefault()
    setError('')
    try {
      const payload = { ...form, capacity: Number(form.capacity), active: form.status !== 'Inactive' }
      if (modalBus?.id) await api.patch(`/buses/${modalBus.id}`, payload)
      else await api.post('/buses', payload)
      setModalBus(null)
      setNotice('Bus saved successfully.')
      loadBuses()
    } catch (err) {
      setError(extractError(err))
    }
  }

  const openHistory = async bus => {
    setHistoryBus(bus)
    const { data } = await api.get(`/buses/${bus.id}/assignments`)
    setHistory(data)
  }

  const columns = [
    { key: 'bus_no', label: 'BUS NUMBER' },
    { key: 'registration_demo', label: 'REGISTRATION (DEMO)' },
    { key: 'bus_type', label: 'BUS TYPE' },
    { key: 'capacity', label: 'CAPACITY' },
    { key: 'status', label: 'STATUS', render: v => <StatusBadge status={v} /> },
  ]

  return (
    <>
      <PageTitle
        title="Bus management"
        subtitle="Manage fleet vehicles, seating capacity, and assignment history."
        action={canEdit && <button className="btn btn-primary" onClick={() => openModal()}><i className="bi bi-plus-lg me-2" />Add Bus</button>}
      />

      {notice && <div className="alert alert-success py-2">{notice}</div>}
      {error && !modalBus && <div className="alert alert-danger py-2">{error}</div>}

      <DataTable
        columns={columns}
        rows={buses}
        searchKeys={['bus_no', 'registration_demo', 'bus_type']}
        statusKey="status"
        loading={loading}
        actions={row => (
          <>
            <button className="table-action" title="Assignment History" onClick={() => openHistory(row)}><i className="bi bi-clock-history" /></button>
            {canEdit && <button className="table-action" title="Edit" onClick={() => openModal(row)}><i className="bi bi-pencil" /></button>}
            {canEdit && <DeleteAction endpoint={`/buses/${row.id}`} itemLabel={`bus ${row.bus_no}`} onDeleted={loadBuses} onError={setError} onNotice={setNotice} />}
          </>
        )}
      />

      {modalBus && (
        <Modal title={modalBus.id ? `Edit Bus ${modalBus.bus_no}` : 'Add Bus'} onClose={() => setModalBus(null)}>
          {error && <div className="alert alert-danger py-2">{error}</div>}
          <form onSubmit={saveBus}>
            <div className="form-grid">
              <div className="form-field">
                <label>Bus Number <span>*</span></label>
                <input className="form-control" required value={form.bus_no} onChange={e => setForm({ ...form, bus_no: e.target.value })} />
              </div>
              <div className="form-field">
                <label>Registration (Demo) <span>*</span></label>
                <input className="form-control" required value={form.registration_demo} onChange={e => setForm({ ...form, registration_demo: e.target.value })} />
              </div>
              <div className="form-field">
                <label>Bus Type <span>*</span></label>
                <select className="form-select" value={form.bus_type} onChange={e => setForm({ ...form, bus_type: e.target.value })}>
                  {['AC Seater', 'Non-AC', 'Electric', 'Mini Bus'].map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
              <div className="form-field">
                <label>Capacity <span>*</span></label>
                <input type="number" min={1} max={120} className="form-control" required value={form.capacity} onChange={e => setForm({ ...form, capacity: e.target.value })} />
              </div>
              <div className="form-field full">
                <label>Operational Status <span>*</span></label>
                <select className="form-select" value={form.status} onChange={e => setForm({ ...form, status: e.target.value })}>
                  {['Available', 'Assigned', 'Maintenance', 'Inactive'].map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
            </div>
            <div className="modal-footer-actions">
              <button type="button" className="btn btn-light" onClick={() => setModalBus(null)}>Cancel</button>
              <button type="submit" className="btn btn-primary">Save Bus</button>
            </div>
          </form>
        </Modal>
      )}

      {historyBus && (
        <Modal title={`Assignment History — ${historyBus.bus_no}`} wide onClose={() => setHistoryBus(null)}>
          <table className="table align-middle mb-0">
            <thead><tr><th>TRIP ID</th><th>DRIVER</th><th>CHANGED BY</th><th>REASON</th><th>DATE</th></tr></thead>
            <tbody>
              {history.length ? history.map(h => (
                <tr key={h.id}>
                  <td>#{h.trip_id}</td><td>{h.driver_name || '—'}</td><td>{h.changed_by_name}</td><td>{h.reason}</td><td>{new Date(h.created_at).toLocaleString()}</td>
                </tr>
              )) : <tr><td colSpan={5} className="empty-cell">No assignment history found.</td></tr>}
            </tbody>
          </table>
        </Modal>
      )}
    </>
  )
}
