import { useCallback, useEffect, useState } from 'react'
import api, { extractError } from '../api'
import DeleteAction from '../components/DeleteAction'
import DataTable from '../components/DataTable'
import Modal from '../components/Modal'
import PageTitle from '../components/PageTitle'
import StatusBadge from '../components/StatusBadge'
import { ROLES, useAuth } from '../context/AuthContext'

const EMPTY_FORM = { employee_code: '', name: '', license_demo: '', contact_demo: '', status: 'Available' }

export default function DriversPage() {
  const { hasRole } = useAuth()
  const canEdit = hasRole([ROLES.ADMIN, ROLES.MANAGER])

  const [drivers, setDrivers] = useState([])
  const [loading, setLoading] = useState(true)
  const [modalDriver, setModalDriver] = useState(null)
  const [form, setForm] = useState(EMPTY_FORM)
  const [historyDriver, setHistoryDriver] = useState(null)
  const [history, setHistory] = useState([])
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')

  const loadDrivers = useCallback(async () => {
    setLoading(true)
    try {
      const { data } = await api.get('/drivers', { params: { size: 100 } })
      setDrivers(data.items)
    } catch (err) {
      setError(extractError(err, 'Could not load drivers.'))
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    loadDrivers()
  }, [loadDrivers])

  const openModal = (drv = null) => {
    setError('')
    setModalDriver(drv || {})
    setForm(drv ? { employee_code: drv.employee_code, name: drv.name, license_demo: drv.license_demo, contact_demo: drv.contact_demo, status: drv.status } : EMPTY_FORM)
  }

  const saveDriver = async e => {
    e.preventDefault()
    setError('')
    try {
      const payload = { ...form, active: form.status !== 'Inactive' }
      if (modalDriver?.id) await api.patch(`/drivers/${modalDriver.id}`, payload)
      else await api.post('/drivers', payload)
      setModalDriver(null)
      setNotice('Driver saved successfully.')
      loadDrivers()
    } catch (err) {
      setError(extractError(err))
    }
  }

  const openHistory = async drv => {
    setHistoryDriver(drv)
    const { data } = await api.get(`/drivers/${drv.id}/assignments`)
    setHistory(data)
  }

  const columns = [
    { key: 'employee_code', label: 'EMPLOYEE CODE' },
    { key: 'name', label: 'DRIVER NAME' },
    { key: 'contact_demo', label: 'CONTACT (DEMO)' },
    { key: 'license_demo', label: 'LICENSE REF.' },
    { key: 'status', label: 'STATUS', render: v => <StatusBadge status={v} /> },
  ]

  return (
    <>
      <PageTitle
        title="Driver management"
        subtitle="Maintain driver profiles, fictional license references, availability, and history."
        action={canEdit && <button className="btn btn-primary" onClick={() => openModal()}><i className="bi bi-plus-lg me-2" />Add Driver</button>}
      />

      {notice && <div className="alert alert-success py-2">{notice}</div>}
      {error && !modalDriver && <div className="alert alert-danger py-2">{error}</div>}

      <DataTable
        columns={columns}
        rows={drivers}
        searchKeys={['employee_code', 'name', 'contact_demo']}
        statusKey="status"
        loading={loading}
        actions={row => (
          <>
            <button className="table-action" title="Assignment History" onClick={() => openHistory(row)}><i className="bi bi-clock-history" /></button>
            {canEdit && <button className="table-action" title="Edit" onClick={() => openModal(row)}><i className="bi bi-pencil" /></button>}
            {canEdit && <DeleteAction endpoint={`/drivers/${row.id}`} itemLabel={`driver ${row.employee_code}`} confirmMessage={`Delete ${row.employee_code} (${row.name})? Any trips assigned to this driver will remain in the system, but this driver's assignment will be cleared. Trips will not be deleted.`} onDeleted={loadDrivers} onError={setError} onNotice={setNotice} />}
          </>
        )}
      />

      {modalDriver && (
        <Modal title={modalDriver.id ? `Edit Driver ${modalDriver.employee_code}` : 'Add Driver'} onClose={() => setModalDriver(null)}>
          {error && <div className="alert alert-danger py-2">{error}</div>}
          <form onSubmit={saveDriver}>
            <div className="form-grid">
              {!modalDriver.id && (
                <div className="form-field">
                  <label>Employee Code <span>*</span></label>
                  <input className="form-control" required value={form.employee_code} onChange={e => setForm({ ...form, employee_code: e.target.value })} placeholder="DRV-004" />
                </div>
              )}
              <div className="form-field">
                <label>Full Name <span>*</span></label>
                <input className="form-control" required value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} />
              </div>
              <div className="form-field">
                <label>License Ref (Fictional) <span>*</span></label>
                <input className="form-control" required value={form.license_demo} onChange={e => setForm({ ...form, license_demo: e.target.value })} />
              </div>
              <div className="form-field">
                <label>Contact (Demo) <span>*</span></label>
                <input className="form-control" required value={form.contact_demo} onChange={e => setForm({ ...form, contact_demo: e.target.value })} />
              </div>
              <div className="form-field full">
                <label>Status <span>*</span></label>
                <select className="form-select" value={form.status} onChange={e => setForm({ ...form, status: e.target.value })}>
                  {['Available', 'Assigned', 'On Leave', 'Inactive'].map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
            </div>
            <div className="modal-footer-actions">
              <button type="button" className="btn btn-light" onClick={() => setModalDriver(null)}>Cancel</button>
              <button type="submit" className="btn btn-primary">Save Driver</button>
            </div>
          </form>
        </Modal>
      )}

      {historyDriver && (
        <Modal title={`Assignment History — ${historyDriver.name}`} wide onClose={() => setHistoryDriver(null)}>
          <table className="table align-middle mb-0">
            <thead><tr><th>TRIP ID</th><th>BUS</th><th>CHANGED BY</th><th>REASON</th><th>DATE</th></tr></thead>
            <tbody>
              {history.length ? history.map(h => (
                <tr key={h.id}>
                  <td>#{h.trip_id}</td><td>{h.bus_no || '—'}</td><td>{h.changed_by_name}</td><td>{h.reason}</td><td>{new Date(h.created_at).toLocaleString()}</td>
                </tr>
              )) : <tr><td colSpan={5} className="empty-cell">No assignment history found.</td></tr>}
            </tbody>
          </table>
        </Modal>
      )}
    </>
  )
}
