import { useCallback, useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import api, { extractError } from '../api'
import PageTitle from '../components/PageTitle'
import StatCard from '../components/StatCard'
import StatusBadge from '../components/StatusBadge'
import { ROLES, useAuth } from '../context/AuthContext'
import { localIsoDate } from '../utils/date'

export default function Dashboard() {
  const { user, roleName, hasRole, demoMode } = useAuth()
  const todayIso = localIsoDate(0)
  const tomorrowIso = localIsoDate(1)

  const [date, setDate] = useState(todayIso)
  const [summary, setSummary] = useState(null)
  const [trips, setTrips] = useState([])
  const [buses, setBuses] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  const loadDashboard = useCallback(async () => {
    setError('')
    setLoading(true)
    if (demoMode) {
      const demoSummary = {
        scheduled_trips: 24, completed_trips: 9, delayed_trips: 2, cancelled_trips: 1,
        available_buses: 18, total_buses: 24, maintenance_buses: 3,
        available_drivers: 16, total_drivers: 20, unassigned_trips: 2,
        total_bookings: 186, total_passengers_booked: 312, revenue_demo: 46800,
        bookings_by_route: [
          { route_code: 'CT-01', booking_count: 42, seats_booked: 68 },
          { route_code: 'CT-02', booking_count: 35, seats_booked: 57 },
          { route_code: 'CT-03', booking_count: 29, seats_booked: 48 },
          { route_code: 'CT-04', booking_count: 46, seats_booked: 79 },
          { route_code: 'CT-05', booking_count: 34, seats_booked: 60 },
        ],
        recent_events: [
          { id: 1, trip_no: 'TRP-2401', event_type: 'Departed', actor_name: 'R. Kumar', note: 'Left Central Station on time' },
          { id: 2, trip_no: 'TRP-2402', event_type: 'Delayed', actor_name: 'S. Reddy', note: 'Traffic near City Market' },
          { id: 3, trip_no: 'TRP-2403', event_type: 'Assigned', actor_name: 'Dispatch Desk', note: 'Bus TS 09 AB 4512 assigned' },
          { id: 4, trip_no: 'TRP-2404', event_type: 'Boarding', actor_name: 'M. Das', note: 'Passenger boarding started' },
          { id: 5, trip_no: 'TRP-2405', event_type: 'Completed', actor_name: 'P. Rao', note: 'Trip completed successfully' },
        ],
      }
      const demoTrips = [
        { id: 1, trip_no: 'TRP-2401', schedule: { route: { name: 'Central Station – Airport' } }, bus: { bus_no: 'TS 09 AB 4512' }, driver: { name: 'R. Kumar' }, status: 'In Progress' },
        { id: 2, trip_no: 'TRP-2402', schedule: { route: { name: 'City Market – Tech Park' } }, bus: { bus_no: 'TS 08 CD 2088' }, driver: { name: 'S. Reddy' }, status: 'Delayed' },
        { id: 3, trip_no: 'TRP-2403', schedule: { route: { name: 'North Terminal – Railway Station' } }, bus: { bus_no: 'TS 10 EF 7731' }, driver: { name: 'M. Das' }, status: 'Scheduled' },
        { id: 4, trip_no: 'TRP-2404', schedule: { route: { name: 'Old Town – University' } }, bus: { bus_no: 'TS 09 GH 6120' }, driver: { name: 'P. Rao' }, status: 'Boarding' },
        { id: 5, trip_no: 'TRP-2405', schedule: { route: { name: 'Lake View – Central Station' } }, bus: { bus_no: 'TS 07 JK 9914' }, driver: { name: 'A. Shah' }, status: 'Completed' },
      ]
      const demoBuses = [
        ...Array.from({ length: 18 }, (_, i) => ({ id: i + 1, bus_no: `TS 09 AB ${4500 + i}`, status: 'Available' })),
        ...Array.from({ length: 3 }, (_, i) => ({ id: i + 19, bus_no: `TS 08 CD ${2080 + i}`, status: 'Assigned' })),
        ...Array.from({ length: 3 }, (_, i) => ({ id: i + 22, bus_no: `TS 07 EF ${7700 + i}`, status: 'Maintenance' })),
      ]
      setSummary(demoSummary)
      setTrips(demoTrips)
      setBuses(demoBuses)
      setLoading(false)
      return
    }
    try {
      const canSeeBuses = [ROLES.ADMIN, ROLES.MANAGER, ROLES.DISPATCHER, ROLES.AUDITOR].includes(roleName)
      const [sumRes, tripRes, busRes] = await Promise.all([
        api.get('/dashboard/summary', { params: { target_date: date } }),
        api.get('/trips', { params: { size: 6 } }),
        canSeeBuses ? api.get('/buses', { params: { size: 50 } }) : Promise.resolve({ data: { items: [] } }),
      ])
      setSummary(sumRes.data)
      setTrips(tripRes.data.items)
      setBuses(busRes.data.items)
    } catch (err) {
      setError(extractError(err, 'Could not load dashboard summary'))
    } finally {
      setLoading(false)
    }
  }, [date, roleName, demoMode])

  useEffect(() => {
    loadDashboard()
  }, [loadDashboard])

  const chartData = summary?.bookings_by_route || []
  const totalFleet = Math.max(1, buses.length)

  return (
    <>
      <PageTitle
        eyebrow="OPERATIONS OVERVIEW"
        title="Operations dashboard"
        subtitle="Monitor scheduled trips, fleet readiness, route bookings, and driver updates."
        action={
          <div className="d-flex flex-wrap gap-2 align-items-center">
            <div className="btn-group btn-group-sm">
              <button
                type="button"
                className={`btn ${date === todayIso ? 'btn-primary' : 'btn-outline-secondary'}`}
                onClick={() => setDate(todayIso)}
              >
                Today
              </button>
              <button
                type="button"
                className={`btn ${date === tomorrowIso ? 'btn-primary' : 'btn-outline-secondary'}`}
                onClick={() => setDate(tomorrowIso)}
              >
                Tomorrow
              </button>
            </div>
            <input
              type="date"
              className="form-control form-control-sm"
              style={{ width: 'auto' }}
              value={date}
              onChange={e => setDate(e.target.value)}
            />
            <button type="button" className="btn btn-light btn-sm" onClick={loadDashboard} disabled={loading}>
              <i className="bi bi-arrow-clockwise me-1" />Refresh
            </button>
            <button type="button" className="btn btn-outline-primary btn-sm" onClick={() => window.print()}>
              <i className="bi bi-printer me-1" />Print
            </button>
          </div>
        }
      />

      <div className="welcome-strip">
        <div>
          <h2>Welcome back, {user?.name}</h2>
          <div className="welcome-meta">
            <span className="role-pill-hero"><i className="bi bi-person-badge" /> {roleName}</span>
            <span>Summary Date: <strong>{date}</strong></span>
            <span>Unassigned Trips: <strong>{summary?.unassigned_trips ?? 0}</strong></span>
          </div>
        </div>
        <div className="quick-actions-row">
          {hasRole([ROLES.ADMIN, ROLES.MANAGER, ROLES.DISPATCHER, ROLES.DRIVER]) && (
            <Link to="/trips" className="quick-btn"><i className="bi bi-map" /> Trip Operations</Link>
          )}
          {hasRole([ROLES.PASSENGER, ROLES.CLERK, ROLES.ADMIN, ROLES.MANAGER]) && (
            <Link to="/search-trips" className="quick-btn"><i className="bi bi-ticket-perforated" /> Book Seat</Link>
          )}
          {hasRole([ROLES.ADMIN, ROLES.MANAGER]) && (
            <Link to="/buses" className="quick-btn"><i className="bi bi-bus-front" /> Manage Fleet</Link>
          )}
          {hasRole([ROLES.ADMIN, ROLES.MANAGER, ROLES.DISPATCHER, ROLES.CLERK, ROLES.AUDITOR]) && (
            <Link to="/reports" className="quick-btn"><i className="bi bi-bar-chart" /> Reports</Link>
          )}
        </div>
      </div>

      <section className="travel-promo-banner" aria-label="CityTransit travel promotion">
        <div className="travel-promo-copy">
          <span className="travel-promo-kicker"><i className="bi bi-stars" /> YOUR CITY. YOUR JOURNEY.</span>
          <h2>Every journey starts<br /><em>with a better ride.</em></h2>
          <p>Discover routes, check schedules and make every trip a little easier with CityTransit.</p>
          <Link to="/search-trips" className="travel-promo-cta">Explore trips <i className="bi bi-arrow-up-right" /></Link>
        </div>
        <div className="travel-promo-note">
          <span className="promo-note-icon"><i className="bi bi-ticket-perforated-fill" /></span>
          <div><strong>Travel made simple</strong><small>Search · Select · Go</small></div>
        </div>
      </section>

      <div className="offers-ribbon">
        <div className="offers-ribbon-icon"><i className="bi bi-gift-fill" /></div>
        <div className="offers-ribbon-copy"><strong>CityTransit special offers</strong><span>Look out for seasonal deals and exclusive passenger promotions.</span></div>
        <span className="offers-ribbon-tag">TRAVEL MORE</span>
      </div>

      {demoMode && <div className="alert alert-info py-2 d-flex align-items-center gap-2"><i className="bi bi-info-circle-fill" /><span><strong>Frontend preview mode:</strong> Dashboard is displaying sample data. Backend connection is not required for this preview.</span></div>}
      {error && <div className="alert alert-danger py-2">{error}</div>}

      <div className="stats-grid">
        <StatCard
          label={`Trips (${date})`}
          value={summary?.scheduled_trips ?? 0}
          change={`${summary?.completed_trips ?? 0} completed • ${summary?.delayed_trips ?? 0} delayed • ${summary?.cancelled_trips ?? 0} cancelled`}
          icon="bi-signpost-split"
          tone="blue"
        />
        <StatCard
          label="Fleet buses ready"
          value={`${summary?.available_buses ?? 0} / ${summary?.total_buses ?? 0}`}
          change={`${summary?.maintenance_buses ?? 0} currently in maintenance`}
          icon="bi-truck-front"
          tone="green"
        />
        <StatCard
          label="Drivers available"
          value={`${summary?.available_drivers ?? 0} / ${summary?.total_drivers ?? 0}`}
          change={`${summary?.unassigned_trips ?? 0} trip(s) need assignment`}
          icon="bi-person-badge"
          tone="orange"
        />
        <StatCard
          label={`Demo bookings (${date})`}
          value={summary?.total_bookings ?? 0}
          change={`${summary?.total_passengers_booked ?? 0} seats • ₹${Number(summary?.revenue_demo || 0).toFixed(0)} demo fare`}
          icon="bi-ticket-perforated"
          tone="purple"
        />
      </div>

      {(summary?.unassigned_trips > 0 || summary?.maintenance_buses > 0) && (
        <div className="alert alert-warning d-flex justify-content-between align-items-center flex-wrap gap-2 mb-4">
          <span>
            <i className="bi bi-exclamation-triangle-fill me-2" />
            <strong>Dispatch Attention:</strong> {summary.unassigned_trips} unassigned trip(s) on {date} and {summary.maintenance_buses} bus(es) under maintenance.
          </span>
          <Link to="/trips" className="btn btn-sm btn-warning fw-semibold">
            Review & Dispatch &rarr;
          </Link>
        </div>
      )}

      <div className="dashboard-grid">
        <section className="content-card">
          <div className="section-heading">
            <div>
              <h3>Bookings by route ({date})</h3>
              <p>Confirmed demo bookings & reserved seats per route</p>
            </div>
            <span className="soft-label">DAILY ANALYTICS</span>
          </div>
          {chartData.length > 0 ? (
            <div className="chart-wrap">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} barGap={8}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#edf1f6" />
                  <XAxis dataKey="route_code" axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} />
                  <Tooltip cursor={{ fill: '#f5f8fc' }} />
                  <Bar dataKey="booking_count" name="Bookings" fill="#d84e55" radius={[6, 6, 0, 0]} />
                  <Bar dataKey="seats_booked" name="Seats Reserved" fill="#1e293b" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <div className="empty-state" style={{ padding: '56px 20px' }}>
              <i className="bi bi-bar-chart" />
              <strong>No route bookings on {date}</strong>
              <span className="d-block mb-3">Demo seed bookings are scheduled for tomorrow ({tomorrowIso}).</span>
              {date !== tomorrowIso && (
                <button type="button" className="btn btn-sm btn-outline-primary" onClick={() => setDate(tomorrowIso)}>
                  View Tomorrow ({tomorrowIso})
                </button>
              )}
            </div>
          )}
        </section>

        <section className="content-card">
          <div className="section-heading">
            <div>
              <h3>Fleet readiness</h3>
              <p>Live distribution across all vehicles</p>
            </div>
            {hasRole([ROLES.ADMIN, ROLES.MANAGER, ROLES.DISPATCHER, ROLES.AUDITOR]) && (
              <Link to="/buses">View fleet <i className="bi bi-arrow-right" /></Link>
            )}
          </div>
          <div className="fleet-total">
            <strong>{buses.length || summary?.total_buses || 0}</strong>
            <span>Total active buses</span>
          </div>
          {[
            { status: 'Available', color: '#15803d', dot: 'fleet-0', fallback: summary?.available_buses ?? 0 },
            { status: 'Assigned', color: '#2563eb', dot: 'fleet-1', fallback: Math.max(0, (summary?.total_buses ?? 0) - (summary?.available_buses ?? 0) - (summary?.maintenance_buses ?? 0)) },
            { status: 'Maintenance', color: '#d97706', dot: 'fleet-2', fallback: summary?.maintenance_buses ?? 0 },
          ].map(row => {
            const count = buses.length ? buses.filter(b => b.status === row.status).length : row.fallback
            const denom = buses.length ? totalFleet : Math.max(1, summary?.total_buses ?? 1)
            const pct = Math.round((count / denom) * 100)
            return (
              <div className="fleet-row" key={row.status}>
                <div className="fleet-row-top">
                  <span><span className={`fleet-dot ${row.dot}`} />{row.status}</span>
                  <strong>{count} ({pct}%)</strong>
                </div>
                <div className="fleet-progress">
                  <div style={{ width: `${pct}%`, background: row.color }} />
                </div>
              </div>
            )
          })}
        </section>
      </div>

      <div className="dashboard-grid-equal">
        <section className="content-card">
          <div className="section-heading">
            <div><h3>Upcoming & recent trips</h3><p>Latest scheduled, assigned, and active runs</p></div>
            <Link to="/trips">View all <i className="bi bi-arrow-right" /></Link>
          </div>
          <div className="table-responsive">
            <table className="table align-middle mb-0">
              <thead><tr><th>TRIP</th><th>ROUTE</th><th>BUS</th><th>DRIVER</th><th>STATUS</th></tr></thead>
              <tbody>
                {trips.length ? trips.map(t => (
                  <tr key={t.id}>
                    <td className="fw-semibold text-primary">{t.trip_no}</td>
                    <td>{t.schedule?.route?.name}</td>
                    <td>{t.bus?.bus_no || <span className="text-muted">Unassigned</span>}</td>
                    <td>{t.driver?.name || <span className="text-muted">Unassigned</span>}</td>
                    <td><StatusBadge status={t.status} /></td>
                  </tr>
                )) : (
                  <tr><td colSpan={5} className="empty-cell"><i className="bi bi-bus-front" /><span>No trips found</span></td></tr>
                )}
              </tbody>
            </table>
          </div>
        </section>

        <section className="content-card">
          <div className="section-heading">
            <div><h3>Recent operational events</h3><p>Dispatch assignments, departures & delays</p></div>
            {hasRole([ROLES.ADMIN, ROLES.MANAGER, ROLES.DISPATCHER, ROLES.CLERK, ROLES.AUDITOR]) && (
              <Link to="/reports">Full Reports <i className="bi bi-arrow-right" /></Link>
            )}
          </div>
          <div className="table-responsive">
            <table className="table align-middle mb-0">
              <thead><tr><th>TRIP</th><th>EVENT</th><th>ACTOR</th><th>NOTE</th></tr></thead>
              <tbody>
                {(summary?.recent_events || []).length ? (summary?.recent_events || []).slice(0, 6).map(ev => (
                  <tr key={ev.id}>
                    <td className="fw-semibold">{ev.trip_no}</td>
                    <td><span className="soft-label">{ev.event_type}</span></td>
                    <td>{ev.actor_name}</td>
                    <td>{ev.note || '—'}</td>
                  </tr>
                )) : (
                  <tr><td colSpan={4} className="empty-cell"><i className="bi bi-journal-text" /><span>No events logged yet</span></td></tr>
                )}
              </tbody>
            </table>
          </div>
        </section>
      </div>
    </>
  )
}
