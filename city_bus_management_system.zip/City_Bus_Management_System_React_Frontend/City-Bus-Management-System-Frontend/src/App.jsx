import { useState } from 'react'
import { Navigate, Route, Routes, useLocation } from 'react-router-dom'
import Header from './components/Header'
import Sidebar from './components/Sidebar'
import { AuthProvider, ROLES, useAuth } from './context/AuthContext'
import BookingsPage from './pages/BookingsPage'
import BusesPage from './pages/BusesPage'
import Dashboard from './pages/Dashboard'
import DriversPage from './pages/DriversPage'
import Login from './pages/Login'
import Reports from './pages/Reports'
import RoutesPage from './pages/RoutesPage'
import SchedulesPage from './pages/SchedulesPage'
import SearchTrips from './pages/SearchTrips'
import StopsPage from './pages/StopsPage'
import TripsPage from './pages/TripsPage'
import UsersPage from './pages/UsersPage'

const STAFF = [ROLES.ADMIN, ROLES.MANAGER, ROLES.DISPATCHER, ROLES.DRIVER, ROLES.CLERK, ROLES.AUDITOR]

function RoleGuard({ roles, children }) {
  const { hasRole } = useAuth()
  if (!hasRole(roles)) {
    return (
      <div className="content-card">
        <div className="alert alert-danger mb-0">
          <strong>403 — Access Denied:</strong> Your role does not have permission to open this page.
        </div>
      </div>
    )
  }
  return children
}

function ProtectedLayout() {
  const { user, loading, hasRole, homePath } = useAuth()
  const [menuOpen, setMenuOpen] = useState(false)
  const location = useLocation()

  if (loading) return <div className="p-5 text-center text-muted">Loading session...</div>
  if (!user) return <Navigate to="/login" replace state={{ from: location }} />

  return (
    <div className="app-shell">
      <Sidebar open={menuOpen} onNavigate={() => setMenuOpen(false)} />
      {menuOpen && <div className="sidebar-scrim" onClick={() => setMenuOpen(false)} />}
      <div className="main-area">
        <Header onMenu={() => setMenuOpen(!menuOpen)} />
        <main className="page-content">
          <Routes>
            <Route path="/" element={hasRole(STAFF) ? <Dashboard /> : <Navigate to={homePath} replace />} />
            <Route path="/buses" element={<RoleGuard roles={[ROLES.ADMIN, ROLES.MANAGER, ROLES.DISPATCHER, ROLES.AUDITOR]}><BusesPage /></RoleGuard>} />
            <Route path="/drivers" element={<RoleGuard roles={[ROLES.ADMIN, ROLES.MANAGER, ROLES.DISPATCHER, ROLES.AUDITOR]}><DriversPage /></RoleGuard>} />
            <Route path="/routes" element={<RoleGuard roles={[ROLES.ADMIN, ROLES.MANAGER, ROLES.DISPATCHER, ROLES.AUDITOR]}><RoutesPage /></RoleGuard>} />
            <Route path="/stops" element={<RoleGuard roles={[ROLES.ADMIN, ROLES.MANAGER, ROLES.DISPATCHER]}><StopsPage /></RoleGuard>} />
            <Route path="/schedules" element={<RoleGuard roles={[ROLES.ADMIN, ROLES.MANAGER, ROLES.DISPATCHER, ROLES.AUDITOR]}><SchedulesPage /></RoleGuard>} />
            <Route path="/trips" element={<RoleGuard roles={[ROLES.ADMIN, ROLES.MANAGER, ROLES.DISPATCHER, ROLES.DRIVER, ROLES.AUDITOR]}><TripsPage /></RoleGuard>} />
            <Route path="/bookings" element={<RoleGuard roles={[ROLES.PASSENGER, ROLES.CLERK, ROLES.ADMIN, ROLES.MANAGER, ROLES.DISPATCHER]}><BookingsPage /></RoleGuard>} />
            <Route path="/users" element={<RoleGuard roles={[ROLES.ADMIN]}><UsersPage /></RoleGuard>} />
            <Route path="/search-trips" element={<SearchTrips />} />
            <Route path="/reports" element={<RoleGuard roles={[ROLES.ADMIN, ROLES.MANAGER, ROLES.DISPATCHER, ROLES.CLERK, ROLES.AUDITOR]}><Reports /></RoleGuard>} />
            <Route path="*" element={<Navigate to={homePath} replace />} />
          </Routes>
          <footer className="app-footer">
            <span>© 2026 CityTransit Management Portal</span>
            <span>DEMO APPLICATION <b>•</b> NOT FOR LIVE TRANSIT</span>
          </footer>
        </main>
      </div>
    </div>
  )
}

export default function App() {
  return (
    <AuthProvider>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/*" element={<ProtectedLayout />} />
      </Routes>
    </AuthProvider>
  )
}
