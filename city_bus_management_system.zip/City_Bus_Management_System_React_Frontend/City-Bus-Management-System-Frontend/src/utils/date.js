// Local timezone-safe date & duration helpers (prevents UTC midnight date shifts)

export function localIsoDate(daysOffset = 0) {
  const d = new Date()
  d.setDate(d.getDate() + daysOffset)
  const local = new Date(d.getTime() - d.getTimezoneOffset() * 60000)
  return local.toISOString().slice(0, 10)
}

export function formatUtcTime(isoString) {
  if (!isoString) return '—'
  const d = new Date(isoString)
  if (Number.isNaN(d.getTime())) return '—'
  return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false, timeZone: 'UTC' })
}

export function formatDuration(minutes) {
  const m = Number(minutes || 0)
  if (m <= 0) return '—'
  const hrs = Math.floor(m / 60)
  const rem = m % 60
  if (hrs > 0 && rem > 0) return `${hrs}h ${rem}m`
  if (hrs > 0) return `${hrs}h`
  return `${rem}m`
}
