import { createContext, useCallback, useContext, useEffect, useState } from 'react'
import api, { extractError } from '../api'

export const ROLES = {
  ADMIN: 'Administrator',
  MANAGER: 'Transport Manager',
  DISPATCHER: 'Dispatcher',
  DRIVER: 'Driver',
  CLERK: 'Booking Clerk',
  PASSENGER: 'Passenger',
  AUDITOR: 'Auditor/Viewer',
}

const AuthContext = createContext(null)
const TOKEN_KEY = 'citytransit-access-token'
const DEMO_SESSION_KEY = 'citytransit-frontend-demo-user'
const DEMO_MODE = import.meta.env.VITE_DEMO_MODE !== 'false'

const DEMO_ROLE_BY_EMAIL = {
  'admin@citytransit.demo': ROLES.ADMIN,
  'manager@citytransit.demo': ROLES.MANAGER,
  'dispatcher@citytransit.demo': ROLES.DISPATCHER,
  'driver1@citytransit.demo': ROLES.DRIVER,
  'clerk@citytransit.demo': ROLES.CLERK,
  'passenger@citytransit.demo': ROLES.PASSENGER,
  'auditor@citytransit.demo': ROLES.AUDITOR,
}

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)

  const loadUser = useCallback(async () => {
    if (DEMO_MODE) {
      try { setUser(JSON.parse(localStorage.getItem(DEMO_SESSION_KEY) || 'null')) }
      catch { setUser(null) }
      setLoading(false)
      return
    }
    if (!localStorage.getItem(TOKEN_KEY)) {
      setUser(null)
      setLoading(false)
      return
    }
    try {
      const { data } = await api.get('/auth/me')
      setUser(data)
    } catch {
      localStorage.removeItem(TOKEN_KEY)
      setUser(null)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    loadUser()
  }, [loadUser])

  const login = async (email, password) => {
    if (DEMO_MODE) {
      const normalizedEmail = email.trim().toLowerCase()
      const role = DEMO_ROLE_BY_EMAIL[normalizedEmail]
      if (password !== 'demo123' || !role) return { ok: false, error: 'Use a demo role email and password demo123.' }
      const demoUser = { id: `demo-${role.toLowerCase().replace(/[^a-z]+/g, '-')}`, name: role === ROLES.ADMIN ? 'Alex Morgan' : role, email: normalizedEmail, role: { name: role }, demo: true }
      localStorage.setItem(DEMO_SESSION_KEY, JSON.stringify(demoUser))
      setUser(demoUser)
      return { ok: true, user: demoUser }
    }
    try {
      const { data } = await api.post('/auth/login', { email, password })
      localStorage.setItem(TOKEN_KEY, data.access_token)
      setUser(data.user)
      return { ok: true, user: data.user }
    } catch (err) {
      return { ok: false, error: extractError(err, 'Invalid credentials') }
    }
  }

  const registerPassenger = async payload => {
    if (DEMO_MODE) {
      const demoUser = { id: 'demo-passenger-new', name: payload.name || 'Demo Passenger', email: payload.email, role: { name: ROLES.PASSENGER }, demo: true }
      localStorage.setItem(DEMO_SESSION_KEY, JSON.stringify(demoUser))
      setUser(demoUser)
      return { ok: true, user: demoUser }
    }
    try {
      const { data } = await api.post('/auth/register', payload)
      localStorage.setItem(TOKEN_KEY, data.access_token)
      setUser(data.user)
      return { ok: true, user: data.user }
    } catch (err) {
      return { ok: false, error: extractError(err, 'Registration failed') }
    }
  }

  const logout = () => {
    localStorage.removeItem(DEMO_SESSION_KEY)
    localStorage.removeItem(TOKEN_KEY)
    setUser(null)
  }

  const roleName = user?.role?.name || ''
  const hasRole = allowed => !allowed?.length || allowed.includes(roleName)
  const homePath =
    roleName === ROLES.PASSENGER ? '/search-trips' : roleName === ROLES.DRIVER ? '/trips' : '/'

  return (
    <AuthContext.Provider value={{ user, roleName, loading, login, registerPassenger, logout, hasRole, homePath, demoMode: DEMO_MODE }}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => useContext(AuthContext)
