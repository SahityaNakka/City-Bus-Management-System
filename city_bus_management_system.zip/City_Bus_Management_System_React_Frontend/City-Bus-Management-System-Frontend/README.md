# CityTransit — City Bus Management System (Frontend)

A professional React + Vite frontend starter for the City Bus Management System brief.
It uses fictional demo records and browser localStorage so the UI can be explored before
the FastAPI backend is available.

## Requirements
- Node.js 20 or newer (Node.js 22 LTS recommended)
- npm
- Git

## Run locally
```bash
npm install
npm run dev
```
Open the local URL printed by Vite (usually http://localhost:5173).

## Demo login
- Email: `admin@citytransit.demo`
- Password: `demo123`

This is a frontend demonstration login only. It is not secure authentication.
The backend must implement password hashing, token validation, and role authorization.

## Build
```bash
npm run build
npm run preview
```

## GitHub
Create a repository, then:
```bash
git init
git add .
git commit -m "Initial CityTransit React frontend"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

## Backend integration
Set `VITE_API_BASE_URL` in a `.env` file when the FastAPI API is ready.
The `src/services/api.js` file contains an Axios client. Replace local demo operations
with API calls as endpoints become available.

## Important
- All routes, people, buses, bookings, and amounts are fictional demo data.
- No real ticket, payment, GPS, or transit service is provided.
- Client-side route guards improve navigation only. Enforce all permissions on FastAPI.
