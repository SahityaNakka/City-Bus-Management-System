import os
from datetime import date, datetime, timedelta, timezone

TEST_DB_PATH = "./test_city_bus.db"
os.environ["DATABASE_URL"] = f"sqlite:///{TEST_DB_PATH}"

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, event
from sqlalchemy.orm import sessionmaker

from app.database import Base, get_db
from app.main import app
from app.models import Trip
from app.seed import DEMO_PASSWORD, seed_database

test_engine = create_engine(f"sqlite:///{TEST_DB_PATH}", connect_args={"check_same_thread": False})


@event.listens_for(test_engine, "connect")
def _fk(conn, _):
    c = conn.cursor()
    c.execute("PRAGMA foreign_keys=ON")
    c.close()


TestingSession = sessionmaker(autocommit=False, autoflush=False, bind=test_engine)


@pytest.fixture
def db_session():
    Base.metadata.drop_all(bind=test_engine)
    Base.metadata.create_all(bind=test_engine)
    db = TestingSession()
    seed_database(db)
    try:
        yield db
    finally:
        db.close()
        Base.metadata.drop_all(bind=test_engine)
        test_engine.dispose()
        if os.path.exists(TEST_DB_PATH):
            try:
                os.remove(TEST_DB_PATH)
            except OSError:
                pass


@pytest.fixture
def client(db_session):
    app.dependency_overrides[get_db] = lambda: db_session
    with TestClient(app) as tc:
        yield tc
    app.dependency_overrides.clear()


def login_as(client: TestClient, email: str) -> dict[str, str]:
    r = client.post("/api/auth/login", json={"email": email, "password": DEMO_PASSWORD})
    assert r.status_code == 200, r.text
    return {"Authorization": f"Bearer {r.json()['access_token']}"}


def test_rbac_and_users(client: TestClient):
    assert client.get("/api/users").status_code == 401
    pax = login_as(client, "passenger@citytransit.demo")
    assert client.get("/api/users", headers=pax).status_code == 403
    admin = login_as(client, "admin@citytransit.demo")
    assert client.get("/api/users", headers=admin).status_code == 200


def test_route_stops_and_publish_validation(client: TestClient):
    mgr = login_as(client, "manager@citytransit.demo")
    route_resp = client.post(
        "/api/routes",
        headers=mgr,
        json={"route_code": "R-09", "name": "Test Loop", "origin": "Stop Alpha", "destination": "Stop Beta"},
    )
    assert route_resp.status_code == 201, route_resp.text
    route = route_resp.json()
    assert client.post(
        "/api/schedules",
        headers=mgr,
        json={"route_id": route["id"], "departure_time": "10:00:00", "duration_min": 30, "fare": 50, "published": True},
    ).status_code == 400

    stops = client.get("/api/stops", headers=mgr).json()["items"]
    assert client.put(
        f"/api/routes/{route['id']}/stops",
        headers=mgr,
        json=[
            {"stop_id": stops[0]["id"], "sequence": 1, "estimated_offset_min": 0},
            {"stop_id": stops[1]["id"], "sequence": 1, "estimated_offset_min": 10},
        ],
    ).status_code == 409

    assert client.put(
        f"/api/routes/{route['id']}/stops",
        headers=mgr,
        json=[
            {"stop_id": stops[0]["id"], "sequence": 1, "estimated_offset_min": 0},
            {"stop_id": stops[1]["id"], "sequence": 2, "estimated_offset_min": 15},
        ],
    ).status_code == 200

    assert client.post(
        "/api/schedules",
        headers=mgr,
        json={"route_id": route["id"], "departure_time": "10:00:00", "duration_min": 30, "fare": 50, "published": True},
    ).status_code == 201


def test_assignment_conflicts_and_maintenance(client: TestClient):
    mgr = login_as(client, "manager@citytransit.demo")
    disp = login_as(client, "dispatcher@citytransit.demo")
    future = (date.today() + timedelta(days=5)).isoformat()
    schs = client.get("/api/schedules", headers=mgr).json()["items"]

    client.post(f"/api/schedules/{schs[0]['id']}/generate-trips", headers=mgr, json={"service_dates": [future]})
    ov_sch = client.post(
        "/api/schedules",
        headers=mgr,
        json={"route_id": schs[1]["route_id"], "departure_time": "06:45:00", "duration_min": 40, "fare": 45, "published": True},
    ).json()
    client.post(f"/api/schedules/{ov_sch['id']}/generate-trips", headers=mgr, json={"service_dates": [future]})

    trips = client.get(f"/api/trips?service_date={future}", headers=disp).json()["items"]
    buses = client.get("/api/buses", headers=disp).json()["items"]
    drivers = client.get("/api/drivers", headers=disp).json()["items"]

    ok_bus = next(b for b in buses if b["bus_no"] == "CT-101")
    maint_bus = next(b for b in buses if b["status"] == "Maintenance")
    d1 = next(d for d in drivers if d["employee_code"] == "DRV-001")
    d2 = next(d for d in drivers if d["employee_code"] == "DRV-002")
    leave_d = next(d for d in drivers if d["status"] == "On Leave")

    assert client.patch(f"/api/trips/{trips[0]['id']}/assignment", headers=disp, json={"bus_id": maint_bus["id"], "driver_id": d1["id"], "reason": "Test"}).status_code == 400
    assert client.patch(f"/api/trips/{trips[0]['id']}/assignment", headers=disp, json={"bus_id": ok_bus["id"], "driver_id": leave_d["id"], "reason": "Test"}).status_code == 400
    assert client.patch(f"/api/trips/{trips[0]['id']}/assignment", headers=disp, json={"bus_id": ok_bus["id"], "driver_id": d1["id"], "reason": "Morning"}).status_code == 200
    assert client.patch(f"/api/trips/{trips[1]['id']}/assignment", headers=disp, json={"bus_id": ok_bus["id"], "driver_id": d2["id"], "reason": "Overlap"}).status_code == 409


def test_booking_capacity_idempotency_and_cutoff(client: TestClient, db_session):
    pax = login_as(client, "passenger@citytransit.demo")
    tomorrow = (date.today() + timedelta(days=1)).isoformat()
    trips = client.get(f"/api/public/trips/search?service_date={tomorrow}").json()
    trip = next(t for t in trips if t["bus"] and t["bus"]["bus_no"] == "CT-102")

    headers = {**pax, "Idempotency-Key": "idem-key-01"}
    b1 = client.post("/api/bookings", headers=headers, json={"trip_id": trip["id"], "passenger_name": "Priya", "contact_demo": "9000000199", "quantity": 10})
    b1_dup = client.post("/api/bookings", headers=headers, json={"trip_id": trip["id"], "passenger_name": "Priya", "contact_demo": "9000000199", "quantity": 10})
    assert b1.status_code == 201 and b1_dup.json()["booking_ref"] == b1.json()["booking_ref"]

    for _ in range(4):
        assert client.post("/api/bookings", headers=pax, json={"trip_id": trip["id"], "passenger_name": "Priya", "contact_demo": "9000000199", "quantity": 10}).status_code == 201
    assert client.post("/api/bookings", headers=pax, json={"trip_id": trip["id"], "passenger_name": "Priya", "contact_demo": "9000000199", "quantity": 1}).status_code == 409
    assert client.patch(f"/api/bookings/{b1.json()['id']}/cancel", headers=pax, json={"reason": "Plans changed"}).status_code == 200

    # Cutoff enforcement
    b_late = client.post("/api/bookings", headers=pax, json={"trip_id": trip["id"], "passenger_name": "Priya", "contact_demo": "9000000199", "quantity": 1}).json()
    db_trip = db_session.query(Trip).filter(Trip.id == trip["id"]).first()
    db_trip.departure_at = datetime.now(timezone.utc) + timedelta(minutes=10)
    db_session.commit()
    assert client.patch(f"/api/bookings/{b_late['id']}/cancel", headers=pax, json={"reason": "Too late"}).status_code == 400


def test_driver_events_and_reports(client: TestClient):
    d1 = login_as(client, "driver1@citytransit.demo")
    d2 = login_as(client, "driver2@citytransit.demo")
    aud = login_as(client, "auditor@citytransit.demo")

    trip = client.get("/api/trips", headers=d1).json()["items"][0]
    assert client.post(f"/api/trips/{trip['id']}/events", headers=d2, json={"event_type": "departure", "passenger_count": 5}).status_code == 403
    assert client.post(f"/api/trips/{trip['id']}/events", headers=d1, json={"event_type": "departure", "passenger_count": 999}).status_code == 400
    assert client.post(f"/api/trips/{trip['id']}/events", headers=d1, json={"event_type": "departure", "passenger_count": 28}).status_code == 201
    assert client.post(f"/api/trips/{trip['id']}/events", headers=d1, json={"event_type": "arrival", "passenger_count": 28}).status_code == 201

    for url in [
        "/api/dashboard/summary", "/api/reports/trips", "/api/reports/route-schedules",
        "/api/reports/bookings", "/api/reports/bus-utilization", "/api/reports/driver-assignments",
        "/api/reports/cancellations", "/api/audit-logs",
    ]:
        assert client.get(url, headers=aud).status_code == 200
