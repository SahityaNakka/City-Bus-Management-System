import os
import time
import unittest
from datetime import date, datetime, timedelta, timezone

PROD_TEST_DB_PATH = "./test_city_bus_prod.db"
os.environ.setdefault("DATABASE_URL", f"sqlite:///{PROD_TEST_DB_PATH}")

from fastapi.testclient import TestClient
from sqlalchemy import create_engine, event
from sqlalchemy.orm import sessionmaker

from app.database import Base, engine, get_db
from app.main import app
from app.models import Trip
from app.seed import DEMO_PASSWORD, seed_database

prod_engine = create_engine(
    f"sqlite:///{PROD_TEST_DB_PATH}",
    connect_args={"check_same_thread": False},
)


@event.listens_for(prod_engine, "connect")
def _enable_sqlite_fk(conn, _):
    cursor = conn.cursor()
    cursor.execute("PRAGMA foreign_keys=ON")
    cursor.close()


ProdTestingSession = sessionmaker(autocommit=False, autoflush=False, bind=prod_engine)


class TestProductionReadiness(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        Base.metadata.drop_all(bind=prod_engine)
        Base.metadata.create_all(bind=prod_engine)
        db = ProdTestingSession()
        try:
            seed_database(db)
        finally:
            db.close()

        def override_get_db():
            session = ProdTestingSession()
            try:
                yield session
            finally:
                session.close()

        app.dependency_overrides[get_db] = override_get_db
        cls.client = TestClient(app)
        cls.client.__enter__()

    @classmethod
    def tearDownClass(cls):
        cls.client.__exit__(None, None, None)
        app.dependency_overrides.clear()
        Base.metadata.drop_all(bind=prod_engine)
        prod_engine.dispose()
        if "test_city_bus" in str(engine.url):
            engine.dispose()
        for leftover in (PROD_TEST_DB_PATH, "./test_city_bus.db"):
            if os.path.exists(leftover):
                try:
                    os.remove(leftover)
                except OSError:
                    pass

    def auth_headers(self, email: str, password: str = DEMO_PASSWORD) -> dict[str, str]:
        res = self.client.post("/api/auth/login", json={"email": email, "password": password})
        self.assertEqual(res.status_code, 200, f"Login failed for {email}: {res.text}")
        return {"Authorization": f"Bearer {res.json()['access_token']}"}

    # ==========================================================================
    # 1. END-TO-END TRANSIT LIFECYCLE (REGISTRATION -> DISPATCH -> BOOKING -> ARRIVAL)
    # ==========================================================================
    def test_01_complete_transit_lifecycle(self):
        print("\n" + "=" * 72)
        print("STAGE 1: FULL TRANSIT LIFECYCLE - REGISTRATION TO TRIP ARRIVAL")
        print("=" * 72)

        # [1.1] Passenger Self-Registration + Welcome Notification
        uid = f"e2e_{str(time.time_ns())[-6:]}"
        email = f"{uid}@citytransit.demo"
        reg_res = self.client.post(
            "/api/auth/register",
            json={
                "name": "Aarav Mehta",
                "email": email,
                "password": "Password@123",
                "contact_demo": "9811223344",
            },
        )
        self.assertEqual(reg_res.status_code, 201, reg_res.text)
        pax_headers = {"Authorization": f"Bearer {reg_res.json()['access_token']}"}
        notifs = self.client.get("/api/notifications", headers=pax_headers).json()
        self.assertTrue(any("Welcome" in n["message"] for n in notifs))
        print(f"  [1.1] Passenger Registered & Notified: Aarav Mehta ({email})")

        # [1.2] Manager creates Route, attaches Stops, publishes Schedule & generates Trip
        mgr = self.auth_headers("manager@citytransit.demo")
        stops = self.client.get("/api/stops", headers=mgr).json()["items"]
        self.assertGreaterEqual(len(stops), 2)

        rt_res = self.client.post(
            "/api/routes",
            headers=mgr,
            json={
                "route_code": f"R-{uid[-3:].upper()}",
                "name": "Outer Ring Express",
                "origin": "Miyapur",
                "destination": "Gachibowli",
                "distance_note": "21 km",
            },
        )
        self.assertEqual(rt_res.status_code, 201, rt_res.text)
        route = rt_res.json()

        st_res = self.client.put(
            f"/api/routes/{route['id']}/stops",
            headers=mgr,
            json=[
                {"stop_id": stops[0]["id"], "sequence": 1, "estimated_offset_min": 0},
                {"stop_id": stops[1]["id"], "sequence": 2, "estimated_offset_min": 25},
            ],
        )
        self.assertEqual(st_res.status_code, 200, st_res.text)

        sch_res = self.client.post(
            "/api/schedules",
            headers=mgr,
            json={
                "route_id": route["id"],
                "departure_time": "11:00:00",
                "duration_min": 45,
                "fare": "120.00",
                "service_rule": "Daily",
                "published": True,
            },
        )
        self.assertEqual(sch_res.status_code, 201, sch_res.text)
        schedule = sch_res.json()

        svc_date = (date.today() + timedelta(days=5)).isoformat()
        gen_res = self.client.post(
            f"/api/schedules/{schedule['id']}/generate-trips",
            headers=mgr,
            json={"service_dates": [svc_date]},
        )
        self.assertEqual(gen_res.status_code, 200, gen_res.text)
        self.assertEqual(gen_res.json()["created_count"], 1)
        trip_no = gen_res.json()["trip_numbers"][0]
        print(f"  [1.2] Route '{route['route_code']}', Schedule & Trip {trip_no} generated for {svc_date}")

        # [1.3] Dispatcher assigns Bus CT-104 & Driver DRV-002 + Notification check
        disp = self.auth_headers("dispatcher@citytransit.demo")
        trips = self.client.get(f"/api/trips?search={trip_no}", headers=disp).json()["items"]
        trip_id = trips[0]["id"]
        buses = self.client.get("/api/buses", headers=disp).json()["items"]
        drivers = self.client.get("/api/drivers", headers=disp).json()["items"]
        bus_104 = next(b for b in buses if b["bus_no"] == "CT-104")
        drv_002 = next(d for d in drivers if d["employee_code"] == "DRV-002")

        assign_res = self.client.patch(
            f"/api/trips/{trip_id}/assignment",
            headers=disp,
            json={"bus_id": bus_104["id"], "driver_id": drv_002["id"], "reason": "E2E Dispatch"},
        )
        self.assertEqual(assign_res.status_code, 200, assign_res.text)
        self.assertEqual(assign_res.json()["status"], "Assigned")

        d2 = self.auth_headers("driver2@citytransit.demo")
        d2_notifs = self.client.get("/api/notifications", headers=d2).json()
        self.assertTrue(any(trip_no in n["message"] for n in d2_notifs))
        print(f"  [1.3] Dispatched {trip_no} -> Bus CT-104 + Driver {drv_002['name']} (Notified)")

        # [1.4] Public Search, Idempotent Booking & Notification
        search_res = self.client.get(f"/api/public/trips/search?service_date={svc_date}")
        self.assertEqual(search_res.status_code, 200)
        pub_trip = next(t for t in search_res.json() if t["id"] == trip_id)
        self.assertEqual(pub_trip["available_seats"], bus_104["capacity"])

        idem_key = f"idem-{uid}"
        book_payload = {
            "trip_id": trip_id,
            "passenger_name": "Aarav Mehta",
            "contact_demo": "9811223344",
            "quantity": 3,
        }
        bk1 = self.client.post(
            "/api/bookings", headers={**pax_headers, "Idempotency-Key": idem_key}, json=book_payload
        )
        bk2 = self.client.post(
            "/api/bookings", headers={**pax_headers, "Idempotency-Key": idem_key}, json=book_payload
        )
        self.assertEqual(bk1.status_code, 201, bk1.text)
        self.assertEqual(bk2.json()["booking_ref"], bk1.json()["booking_ref"])
        booking_id = bk1.json()["id"]
        booking_ref = bk1.json()["booking_ref"]
        print(f"  [1.4] Booking Confirmed: {booking_ref} (3 seats, Total Fare: {bk1.json()['total_fare']})")

        # [1.5] Driver logs Departure -> Arrival & Bus release
        dep_res = self.client.post(
            f"/api/trips/{trip_id}/events",
            headers=d2,
            json={"event_type": "departure", "passenger_count": 3, "note": "Departed on time"},
        )
        self.assertEqual(dep_res.status_code, 201, dep_res.text)

        arr_res = self.client.post(
            f"/api/trips/{trip_id}/events",
            headers=d2,
            json={"event_type": "arrival", "passenger_count": 3, "note": "Arrived at terminal"},
        )
        self.assertEqual(arr_res.status_code, 201, arr_res.text)

        done_trip = self.client.get(f"/api/trips/{trip_id}", headers=disp).json()
        self.assertEqual(done_trip["status"], "Completed")
        buses_after = self.client.get("/api/buses", headers=disp).json()["items"]
        bus_104_after = next(b for b in buses_after if b["id"] == bus_104["id"])
        self.assertEqual(bus_104_after["status"], "Available")
        print(f"  [1.5] Driver Completed {trip_no}; Bus {bus_104['bus_no']} returned to Available")

        # [1.6] Clerk completes Booking Attendance & Passenger marks Notifications Read
        clerk = self.auth_headers("clerk@citytransit.demo")
        bk_upd = self.client.patch(
            f"/api/bookings/{booking_id}/status",
            headers=clerk,
            json={"status": "Completed", "reason": "Passenger boarded and completed trip"},
        )
        self.assertEqual(bk_upd.status_code, 200, bk_upd.text)

        mark_res = self.client.put("/api/notifications", headers=pax_headers)
        self.assertEqual(mark_res.status_code, 200)
        unread_left = [
            n for n in self.client.get("/api/notifications", headers=pax_headers).json() if not n["is_read"]
        ]
        self.assertEqual(len(unread_left), 0)
        print("  [1.6] Booking Marked Completed & Notifications Cleared")
        print("  -> ALL STAGE 1 TRANSIT LIFECYCLE CHECKS PASSED!")

    # ==========================================================================
    # 2. RBAC SECURITY & UNAUTHORIZED ACCESS ENFORCEMENT
    # ==========================================================================
    def test_02_rbac_security_and_access_controls(self):
        print("\n" + "=" * 72)
        print("STAGE 2: ROLE-BASED ACCESS CONTROL (RBAC) & SECURITY DEFENSE")
        print("=" * 72)

        # [2.1] Unauthenticated Access Blocked
        self.assertEqual(self.client.get("/api/users").status_code, 401)
        self.assertEqual(self.client.get("/api/dashboard/summary").status_code, 401)
        print("  [2.1] Unauthenticated access to protected endpoints blocked (401)")

        # [2.2] Passenger Blocked from Staff/Admin Endpoints
        pax = self.auth_headers("passenger@citytransit.demo")
        self.assertEqual(self.client.get("/api/users", headers=pax).status_code, 403)
        self.assertEqual(self.client.get("/api/dashboard/summary", headers=pax).status_code, 403)
        print("  [2.2] Passenger access to Admin/Operations endpoints blocked (403)")

        # [2.3] Booking Clerk Blocked from Fleet Creation & Dispatch Assignment
        clerk = self.auth_headers("clerk@citytransit.demo")
        self.assertEqual(
            self.client.post(
                "/api/buses",
                headers=clerk,
                json={"bus_no": "HACK-1", "registration_demo": "XX", "capacity": 20, "bus_type": "AC"},
            ).status_code,
            403,
        )
        self.assertEqual(
            self.client.patch(
                "/api/trips/1/assignment",
                headers=clerk,
                json={"bus_id": 1, "driver_id": 1, "reason": "Unauthorized"},
            ).status_code,
            403,
        )
        print("  [2.3] Booking Clerk blocked from Bus Creation & Trip Dispatch (403)")

        # [2.4] Dispatcher Blocked from User Account Creation
        disp = self.auth_headers("dispatcher@citytransit.demo")
        self.assertEqual(
            self.client.post(
                "/api/users",
                headers=disp,
                json={
                    "name": "Hacker",
                    "email": "hacker@citytransit.demo",
                    "password": "Password@123",
                    "role_id": 1,
                },
            ).status_code,
            403,
        )
        print("  [2.4] Dispatcher blocked from Admin User Provisioning (403)")

        # [2.5] Driver Cross-Trip Tampering & Auditor Read-Only Enforcement
        d1 = self.auth_headers("driver1@citytransit.demo")
        trips_all = self.client.get("/api/trips", headers=disp).json()["items"]
        d2_trip = next(t for t in trips_all if t["trip_no"] == "TR-2602")
        self.assertEqual(
            self.client.post(
                f"/api/trips/{d2_trip['id']}/events",
                headers=d1,
                json={"event_type": "note", "note": "Cross-driver tamper"},
            ).status_code,
            403,
        )
        aud = self.auth_headers("auditor@citytransit.demo")
        self.assertEqual(
            self.client.post(
                "/api/routes",
                headers=aud,
                json={"route_code": "R-999", "name": "No Write", "origin": "AA", "destination": "BB"},
            ).status_code,
            403,
        )
        print("  [2.5] Driver cross-trip mutation & Auditor write attempt blocked (403)")
        print("  -> ALL RBAC SECURITY ENFORCEMENT CHECKS PASSED!")

    # ==========================================================================
    # 3. CONCURRENCY, RESOURCE CONFLICTS & NEGATIVE VALIDATIONS
    # ==========================================================================
    def test_03_concurrency_and_negative_validations(self):
        print("\n" + "=" * 72)
        print("STAGE 3: RESOURCE CONFLICTS, CAPACITY LOCKING & NEGATIVE VALIDATIONS")
        print("=" * 72)

        mgr = self.auth_headers("manager@citytransit.demo")
        disp = self.auth_headers("dispatcher@citytransit.demo")
        pax = self.auth_headers("passenger@citytransit.demo")

        future = (date.today() + timedelta(days=7)).isoformat()
        schs = self.client.get("/api/schedules", headers=mgr).json()["items"]
        self.client.post(f"/api/schedules/{schs[0]['id']}/generate-trips", headers=mgr, json={"service_dates": [future]})

        # Create overlapping schedule on route 2 around same morning window (06:45 + 40 min)
        ov_sch = self.client.post(
            "/api/schedules",
            headers=mgr,
            json={
                "route_id": schs[1]["route_id"],
                "departure_time": "06:45:00",
                "duration_min": 40,
                "fare": "45.00",
                "published": True,
            },
        ).json()
        self.client.post(f"/api/schedules/{ov_sch['id']}/generate-trips", headers=mgr, json={"service_dates": [future]})

        trips = self.client.get(f"/api/trips?service_date={future}", headers=disp).json()["items"]
        buses = self.client.get("/api/buses", headers=disp).json()["items"]
        drivers = self.client.get("/api/drivers", headers=disp).json()["items"]
        bus_ok = next(b for b in buses if b["bus_no"] == "CT-104")
        bus_maint = next(b for b in buses if b["status"] == "Maintenance")
        drv_ok = next(d for d in drivers if d["employee_code"] == "DRV-001")
        drv_alt = next(d for d in drivers if d["employee_code"] == "DRV-002")
        drv_leave = next(d for d in drivers if d["status"] == "On Leave")

        # [3.1] Ineligible Maintenance Bus & On-Leave Driver Blocked
        self.assertEqual(
            self.client.patch(
                f"/api/trips/{trips[0]['id']}/assignment",
                headers=disp,
                json={"bus_id": bus_maint["id"], "driver_id": drv_ok["id"], "reason": "Maint test"},
            ).status_code,
            400,
        )
        self.assertEqual(
            self.client.patch(
                f"/api/trips/{trips[0]['id']}/assignment",
                headers=disp,
                json={"bus_id": bus_ok["id"], "driver_id": drv_leave["id"], "reason": "Leave test"},
            ).status_code,
            400,
        )
        print("  [3.1] Assigning Maintenance bus & On-Leave driver blocked (400)")

        # [3.2] Time-Window Overlap Conflict Prevention
        self.assertEqual(
            self.client.patch(
                f"/api/trips/{trips[0]['id']}/assignment",
                headers=disp,
                json={"bus_id": bus_ok["id"], "driver_id": drv_ok["id"], "reason": "Valid primary"},
            ).status_code,
            200,
        )
        self.assertEqual(
            self.client.patch(
                f"/api/trips/{trips[1]['id']}/assignment",
                headers=disp,
                json={"bus_id": bus_ok["id"], "driver_id": drv_alt["id"], "reason": "Overlap check"},
            ).status_code,
            409,
        )
        print("  [3.2] Overlapping Bus assignment blocked with 409 Conflict")

        # [3.3] Invalid Trip Status Jump Blocked
        self.assertEqual(
            self.client.patch(
                f"/api/trips/{trips[1]['id']}/status",
                headers=disp,
                json={"status": "Completed", "reason": "Skip workflow"},
            ).status_code,
            409,
        )
        print("  [3.3] Invalid Trip Status jump (Scheduled -> Completed) blocked (409)")

        # [3.4] Seat Capacity Limit Enforcement
        t_id = trips[0]["id"]
        for _ in range(4):
            res = self.client.post(
                "/api/bookings",
                headers=pax,
                json={"trip_id": t_id, "passenger_name": "Priya", "contact_demo": "9000000199", "quantity": 10},
            )
            self.assertEqual(res.status_code, 201)
        over_res = self.client.post(
            "/api/bookings",
            headers=pax,
            json={"trip_id": t_id, "passenger_name": "Priya", "contact_demo": "9000000199", "quantity": 1},
        )
        self.assertEqual(over_res.status_code, 409)
        print("  [3.4] Seat Capacity Exceeded overbooking blocked with 409 Conflict")

        # [3.5] Cancellation Cutoff Window & Cancelled Trip Passenger Notification
        recent_bk = self.client.get("/api/bookings/me", headers=pax).json()["items"][0]
        target_trip_id = recent_bk["trip_id"]
        db = ProdTestingSession()
        try:
            tr = db.query(Trip).filter(Trip.id == target_trip_id).first()
            tr.departure_at = datetime.now(timezone.utc) + timedelta(minutes=10)
            db.commit()
        finally:
            db.close()

        late_cancel = self.client.patch(
            f"/api/bookings/{recent_bk['id']}/cancel",
            headers=pax,
            json={"reason": "Last minute change"},
        )
        self.assertEqual(late_cancel.status_code, 400)
        print("  [3.5] Late booking cancellation inside 30-min cutoff blocked (400)")
        print("  -> ALL TRANSACTIONAL INTEGRITY & NEGATIVE VALIDATION CHECKS PASSED!")

    # ==========================================================================
    # 4. CROSS-MODULE AUDIT TRAILS & DASHBOARD KPI SYNCHRONIZATION
    # ==========================================================================
    def test_04_audit_trails_and_stats(self):
        print("\n" + "=" * 72)
        print("STAGE 4: AUDIT TRAILS, REPORTS & DASHBOARD METRICS SYNCHRONIZATION")
        print("=" * 72)

        aud = self.auth_headers("auditor@citytransit.demo")

        # [4.1] Verify Audit Trail Completeness
        logs_res = self.client.get("/api/audit-logs", headers=aud)
        self.assertEqual(logs_res.status_code, 200, logs_res.text)
        logs_data = logs_res.json()
        actions = {row["action"] for row in logs_data["items"]}
        for expected in ("LOGIN", "CREATE_BOOKING", "ASSIGN_TRIP", "RECORD_TRIP_EVENT"):
            self.assertIn(expected, actions, f"Expected audit action '{expected}' not found")
        print(f"  [4.1] Audit Trail Verified ({logs_data['total']} entries). Key actions: {sorted(actions)}")

        # [4.2] Verify Live Dashboard KPIs & Operational Reports
        dash_res = self.client.get("/api/dashboard/summary", headers=aud)
        self.assertEqual(dash_res.status_code, 200, dash_res.text)
        dash = dash_res.json()

        required_kpis = [
            "today", "scheduled_trips", "completed_trips", "delayed_trips", "cancelled_trips",
            "total_bookings", "total_passengers_booked", "total_buses", "available_buses",
            "maintenance_buses", "total_drivers", "available_drivers", "unassigned_trips",
            "revenue_demo", "bookings_by_route", "recent_events",
        ]
        for key in required_kpis:
            self.assertIn(key, dash, f"Missing dashboard KPI: {key}")
            self.assertIsNotNone(dash[key], f"Dashboard KPI '{key}' should not be null")

        for report_url in (
            "/api/reports/trips?status=Completed",
            "/api/reports/route-schedules?active=true",
            f"/api/reports/bookings?date_from={date.today().isoformat()}&date_to={(date.today() + timedelta(days=10)).isoformat()}",
            "/api/reports/bus-utilization",
            "/api/reports/driver-assignments",
            "/api/reports/cancellations",
            "/api/audit-logs?action=BOOKING",
        ):
            r = self.client.get(report_url, headers=aud)
            self.assertEqual(r.status_code, 200, f"Report endpoint failed: {report_url}")

        util_rows = self.client.get("/api/reports/bus-utilization", headers=aud).json()
        self.assertTrue(len(util_rows) > 0 and "capacity" in util_rows[0])

        print(f"  [4.2] Dashboard & 6 Reporting Endpoints Verified ({len(required_kpis)} KPIs synced)")
        print(f"        Fleet: {dash['total_buses']} buses ({dash['available_buses']} available) | Drivers: {dash['total_drivers']}")
        print(f"        Today Trips: {dash['scheduled_trips']} | Bookings: {dash['total_bookings']} | Revenue (DEMO): Rs. {dash['revenue_demo']}")
        print("  -> ALL AUDIT TRAILS AND DASHBOARD METRICS SYNCHRONIZED SUCCESSFULLY!")


if __name__ == "__main__":
    unittest.main(verbosity=2)
