"""Standalone database schema migration and demo seeding script.

Run from the `backend/` folder:
    python migrate_db.py
"""
from pathlib import Path

from alembic import command
from alembic.config import Config
from sqlalchemy import inspect

from app.database import Base, SessionLocal, engine
from app.seed import seed_database


def run_migration() -> None:
    backend_dir = Path(__file__).resolve().parent
    alembic_cfg = Config(str(backend_dir / "alembic.ini"))
    alembic_cfg.set_main_option("script_location", str(backend_dir / "app" / "migrations"))

    tables = set(inspect(engine).get_table_names())
    if "users" in tables and "alembic_version" not in tables:
        Base.metadata.create_all(bind=engine)
        command.stamp(alembic_cfg, "head")
    else:
        command.upgrade(alembic_cfg, "head")

    db = SessionLocal()
    try:
        seed_database(db)
    finally:
        db.close()
    print("Database migration and seed check completed successfully.")


if __name__ == "__main__":
    run_migration()
