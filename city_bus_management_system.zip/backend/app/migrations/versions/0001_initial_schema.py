"""Initial CityTransit SQL Schema

Revision ID: 0001_initial_schema
Revises:
Create Date: 2026-11-10
"""
from typing import Sequence, Union
from alembic import op
import sqlalchemy as sa

revision: str = "0001_initial_schema"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "roles",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("name", sa.String(64), nullable=False, unique=True),
        sa.Column("description", sa.String(255)),
    )
    op.create_table(
        "users",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("name", sa.String(120), nullable=False),
        sa.Column("email", sa.String(180), nullable=False, unique=True),
        sa.Column("password_hash", sa.String(255), nullable=False),
        sa.Column("role_id", sa.Integer(), sa.ForeignKey("roles.id"), nullable=False),
        sa.Column("contact_demo", sa.String(120)),
        sa.Column("active", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_table(
        "buses",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("bus_no", sa.String(40), nullable=False, unique=True),
        sa.Column("registration_demo", sa.String(60), nullable=False),
        sa.Column("capacity", sa.Integer(), nullable=False),
        sa.Column("bus_type", sa.String(60), nullable=False),
        sa.Column("status", sa.String(32), nullable=False),
        sa.Column("active", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.CheckConstraint("capacity > 0", name="ck_bus_capacity_positive"),
    )
    op.create_table(
        "drivers",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("user_id", sa.Integer(), sa.ForeignKey("users.id"), unique=True),
        sa.Column("employee_code", sa.String(40), nullable=False, unique=True),
        sa.Column("name", sa.String(120), nullable=False),
        sa.Column("license_demo", sa.String(60), nullable=False),
        sa.Column("contact_demo", sa.String(80), nullable=False),
        sa.Column("status", sa.String(32), nullable=False),
        sa.Column("active", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_table(
        "routes",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("route_code", sa.String(40), nullable=False, unique=True),
        sa.Column("name", sa.String(150), nullable=False),
        sa.Column("origin", sa.String(120), nullable=False),
        sa.Column("destination", sa.String(120), nullable=False),
        sa.Column("distance_note", sa.String(120)),
        sa.Column("active", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_table(
        "stops",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("stop_code", sa.String(40), nullable=False, unique=True),
        sa.Column("name", sa.String(120), nullable=False),
        sa.Column("area", sa.String(120), nullable=False),
        sa.Column("active", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_table(
        "route_stops",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("route_id", sa.Integer(), sa.ForeignKey("routes.id", ondelete="CASCADE"), nullable=False),
        sa.Column("stop_id", sa.Integer(), sa.ForeignKey("stops.id"), nullable=False),
        sa.Column("sequence", sa.Integer(), nullable=False),
        sa.Column("estimated_offset_min", sa.Integer(), nullable=False),
        sa.UniqueConstraint("route_id", "sequence", name="uq_route_stop_sequence"),
        sa.CheckConstraint("sequence >= 1", name="ck_route_stop_seq_positive"),
        sa.CheckConstraint("estimated_offset_min >= 0", name="ck_route_stop_offset_nonneg"),
    )
    op.create_table(
        "schedules",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("route_id", sa.Integer(), sa.ForeignKey("routes.id"), nullable=False),
        sa.Column("departure_time", sa.Time(), nullable=False),
        sa.Column("duration_min", sa.Integer(), nullable=False),
        sa.Column("fare", sa.Numeric(10, 2), nullable=False),
        sa.Column("service_rule", sa.String(120), nullable=False),
        sa.Column("published", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("active", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.CheckConstraint("duration_min > 0", name="ck_schedule_duration_positive"),
        sa.CheckConstraint("fare >= 0", name="ck_schedule_fare_nonneg"),
    )
    op.create_table(
        "fare_rules",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("route_id", sa.Integer(), sa.ForeignKey("routes.id")),
        sa.Column("schedule_id", sa.Integer(), sa.ForeignKey("schedules.id")),
        sa.Column("fare_amount", sa.Numeric(10, 2), nullable=False),
        sa.Column("effective_date", sa.Date(), nullable=False),
        sa.Column("active", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.CheckConstraint("fare_amount >= 0", name="ck_fare_rule_nonneg"),
    )
    op.create_table(
        "trips",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("trip_no", sa.String(48), nullable=False, unique=True),
        sa.Column("schedule_id", sa.Integer(), sa.ForeignKey("schedules.id"), nullable=False),
        sa.Column("service_date", sa.Date(), nullable=False),
        sa.Column("departure_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("estimated_arrival_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("actual_departure_at", sa.DateTime(timezone=True)),
        sa.Column("actual_arrival_at", sa.DateTime(timezone=True)),
        sa.Column("bus_id", sa.Integer(), sa.ForeignKey("buses.id")),
        sa.Column("driver_id", sa.Integer(), sa.ForeignKey("drivers.id")),
        sa.Column("status", sa.String(32), nullable=False),
        sa.Column("passenger_count", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("fare_snapshot", sa.Numeric(10, 2), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("schedule_id", "service_date", name="uq_trip_schedule_date"),
        sa.CheckConstraint("passenger_count >= 0", name="ck_trip_passenger_nonneg"),
    )
    op.create_table(
        "assignment_history",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("trip_id", sa.Integer(), sa.ForeignKey("trips.id", ondelete="CASCADE"), nullable=False),
        sa.Column("bus_id", sa.Integer(), sa.ForeignKey("buses.id")),
        sa.Column("driver_id", sa.Integer(), sa.ForeignKey("drivers.id")),
        sa.Column("changed_by", sa.Integer(), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("reason", sa.String(255), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_table(
        "trip_events",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("trip_id", sa.Integer(), sa.ForeignKey("trips.id", ondelete="CASCADE"), nullable=False),
        sa.Column("event_type", sa.String(40), nullable=False),
        sa.Column("delay_category", sa.String(60)),
        sa.Column("passenger_count", sa.Integer()),
        sa.Column("note", sa.Text()),
        sa.Column("actor_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("timestamp", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_table(
        "bookings",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("booking_ref", sa.String(40), nullable=False, unique=True),
        sa.Column("trip_id", sa.Integer(), sa.ForeignKey("trips.id"), nullable=False),
        sa.Column("passenger_user_id", sa.Integer(), sa.ForeignKey("users.id")),
        sa.Column("passenger_name", sa.String(120), nullable=False),
        sa.Column("contact_demo", sa.String(120), nullable=False),
        sa.Column("quantity", sa.Integer(), nullable=False),
        sa.Column("total_fare", sa.Numeric(10, 2), nullable=False),
        sa.Column("status", sa.String(32), nullable=False),
        sa.Column("payment_status_demo", sa.String(32), nullable=False),
        sa.Column("idempotency_key", sa.String(120), unique=True),
        sa.Column("cancellation_reason", sa.String(255)),
        sa.Column("cancelled_by", sa.Integer(), sa.ForeignKey("users.id")),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("cancelled_at", sa.DateTime(timezone=True)),
        sa.CheckConstraint("quantity > 0", name="ck_booking_qty_positive"),
    )
    op.create_table(
        "audit_logs",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("actor_id", sa.Integer(), sa.ForeignKey("users.id")),
        sa.Column("action", sa.String(64), nullable=False),
        sa.Column("entity", sa.String(64), nullable=False),
        sa.Column("entity_id", sa.String(64), nullable=False),
        sa.Column("reason", sa.String(255)),
        sa.Column("details", sa.Text()),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )


def downgrade() -> None:
    for tbl in [
        "audit_logs", "bookings", "trip_events", "assignment_history",
        "trips", "fare_rules", "schedules", "route_stops",
        "stops", "routes", "drivers", "buses", "users", "roles",
    ]:
        op.drop_table(tbl)
