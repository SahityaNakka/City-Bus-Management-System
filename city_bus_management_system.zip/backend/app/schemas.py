from datetime import date, datetime, time
from decimal import Decimal
from typing import Generic, Literal, TypeVar

from pydantic import BaseModel, ConfigDict, EmailStr, Field

T = TypeVar("T")


class PaginatedResponse(BaseModel, Generic[T]):
    items: list[T]
    total: int
    page: int
    size: int
    total_pages: int


# --- Auth & Users ---

class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class PassengerRegisterRequest(BaseModel):
    name: str = Field(..., min_length=2, max_length=120)
    email: EmailStr
    password: str = Field(..., min_length=6, max_length=128)
    contact_demo: str = Field(..., min_length=5, max_length=120)


class RoleOut(BaseModel):
    id: int
    name: str
    description: str | None = None
    model_config = ConfigDict(from_attributes=True)


class DriverBrief(BaseModel):
    id: int
    employee_code: str
    name: str
    model_config = ConfigDict(from_attributes=True)


class UserOut(BaseModel):
    id: int
    name: str
    email: str
    role_id: int
    role: RoleOut
    contact_demo: str | None = None
    driver_profile: DriverBrief | None = None
    active: bool
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut


class UserCreate(BaseModel):
    name: str = Field(..., min_length=2, max_length=120)
    email: EmailStr
    password: str = Field(..., min_length=6, max_length=128)
    role_id: int
    contact_demo: str | None = None


class UserUpdate(BaseModel):
    name: str | None = Field(None, min_length=2, max_length=120)
    email: EmailStr | None = None
    role_id: int | None = None
    contact_demo: str | None = None
    active: bool | None = None
    password: str | None = Field(None, min_length=6, max_length=128)


# --- Fleet & Crew ---

class BusCreate(BaseModel):
    bus_no: str = Field(..., min_length=2, max_length=40)
    registration_demo: str = Field(..., min_length=2, max_length=60)
    capacity: int = Field(..., gt=0, le=120)
    bus_type: str = Field(..., min_length=2, max_length=60)
    status: Literal["Available", "Assigned", "Maintenance", "Inactive"] = "Available"
    active: bool = True


class BusUpdate(BaseModel):
    bus_no: str | None = None
    registration_demo: str | None = None
    capacity: int | None = Field(None, gt=0, le=120)
    bus_type: str | None = None
    status: Literal["Available", "Assigned", "Maintenance", "Inactive"] | None = None
    active: bool | None = None


class BusOut(BaseModel):
    id: int
    bus_no: str
    registration_demo: str
    capacity: int
    bus_type: str
    status: str
    active: bool
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)


class DriverCreate(BaseModel):
    employee_code: str = Field(..., min_length=2, max_length=40)
    name: str = Field(..., min_length=2, max_length=120)
    license_demo: str = Field(..., min_length=2, max_length=60)
    contact_demo: str = Field(..., min_length=5, max_length=80)
    user_id: int | None = None
    status: Literal["Available", "Assigned", "On Leave", "Inactive"] = "Available"
    active: bool = True


class DriverUpdate(BaseModel):
    name: str | None = None
    license_demo: str | None = None
    contact_demo: str | None = None
    user_id: int | None = None
    status: Literal["Available", "Assigned", "On Leave", "Inactive"] | None = None
    active: bool | None = None


class DriverOut(BaseModel):
    id: int
    employee_code: str
    name: str
    license_demo: str
    contact_demo: str
    user_id: int | None = None
    status: str
    active: bool
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)


# --- Routes & Stops ---

class StopCreate(BaseModel):
    stop_code: str = Field(..., min_length=2, max_length=40)
    name: str = Field(..., min_length=2, max_length=120)
    area: str = Field(..., min_length=2, max_length=120)
    active: bool = True


class StopUpdate(BaseModel):
    name: str | None = None
    area: str | None = None
    active: bool | None = None


class StopOut(BaseModel):
    id: int
    stop_code: str
    name: str
    area: str
    active: bool
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)


class RouteStopIn(BaseModel):
    stop_id: int
    sequence: int = Field(..., ge=1)
    estimated_offset_min: int = Field(0, ge=0)


class RouteStopOut(BaseModel):
    id: int
    stop_id: int
    sequence: int
    estimated_offset_min: int
    stop: StopOut
    model_config = ConfigDict(from_attributes=True)


class RouteCreate(BaseModel):
    route_code: str = Field(..., min_length=2, max_length=40)
    name: str = Field(..., min_length=2, max_length=150)
    origin: str = Field(..., min_length=2, max_length=120)
    destination: str = Field(..., min_length=2, max_length=120)
    distance_note: str | None = None
    active: bool = True
    stops: list[RouteStopIn] | None = None


class RouteUpdate(BaseModel):
    name: str | None = None
    origin: str | None = None
    destination: str | None = None
    distance_note: str | None = None
    active: bool | None = None


class RouteOut(BaseModel):
    id: int
    route_code: str
    name: str
    origin: str
    destination: str
    distance_note: str | None = None
    active: bool
    stops_count: int = 0
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)


class RouteDetailOut(RouteOut):
    route_stops: list[RouteStopOut] = []


# --- Schedules, Fare Rules & Trips ---

class ScheduleCreate(BaseModel):
    route_id: int
    departure_time: time
    duration_min: int = Field(..., gt=0, le=720)
    fare: Decimal = Field(..., ge=0)
    service_rule: str = Field("Daily", max_length=120)
    published: bool = False
    active: bool = True


class ScheduleUpdate(BaseModel):
    departure_time: time | None = None
    duration_min: int | None = Field(None, gt=0, le=720)
    fare: Decimal | None = Field(None, ge=0)
    service_rule: str | None = None
    published: bool | None = None
    active: bool | None = None


class ScheduleOut(BaseModel):
    id: int
    route_id: int
    departure_time: time
    duration_min: int
    fare: Decimal
    service_rule: str
    published: bool
    active: bool
    created_at: datetime
    route: RouteOut
    model_config = ConfigDict(from_attributes=True)


class ScheduleDetailOut(ScheduleOut):
    route: RouteDetailOut


class GenerateTripsRequest(BaseModel):
    service_dates: list[date] = Field(..., min_length=1, max_length=31)


class FareRuleCreate(BaseModel):
    route_id: int | None = None
    schedule_id: int | None = None
    fare_amount: Decimal = Field(..., ge=0)
    effective_date: date
    active: bool = True


class FareRuleOut(BaseModel):
    id: int
    route_id: int | None = None
    schedule_id: int | None = None
    fare_amount: Decimal
    effective_date: date
    active: bool
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)


class TripOut(BaseModel):
    id: int
    trip_no: str
    schedule_id: int
    service_date: date
    departure_at: datetime
    estimated_arrival_at: datetime
    actual_departure_at: datetime | None = None
    actual_arrival_at: datetime | None = None
    bus_id: int | None = None
    driver_id: int | None = None
    status: str
    passenger_count: int
    fare_snapshot: Decimal
    created_at: datetime
    schedule: ScheduleOut
    bus: BusOut | None = None
    driver: DriverOut | None = None
    available_seats: int | None = None
    model_config = ConfigDict(from_attributes=True)


class TripDetailOut(TripOut):
    schedule: ScheduleDetailOut


class TripAssignRequest(BaseModel):
    bus_id: int
    driver_id: int
    reason: str = Field("Operational assignment", min_length=2, max_length=255)


class TripStatusRequest(BaseModel):
    status: Literal[
        "Scheduled", "Assigned", "Boarding", "In Progress", "Completed", "Delayed", "Cancelled"
    ]
    reason: str = Field("Status update", min_length=2, max_length=255)


class TripEventCreate(BaseModel):
    event_type: Literal["departure", "arrival", "delay", "passenger_count", "note"]
    delay_category: (
        Literal["Traffic", "Mechanical", "Weather", "Passenger", "Operational", "Other"] | None
    ) = None
    passenger_count: int | None = Field(None, ge=0)
    note: str | None = Field(None, max_length=500)


class TripEventOut(BaseModel):
    id: int
    trip_id: int
    event_type: str
    delay_category: str | None = None
    passenger_count: int | None = None
    note: str | None = None
    actor_id: int
    actor_name: str | None = None
    timestamp: datetime


class AssignmentHistoryOut(BaseModel):
    id: int
    trip_id: int
    bus_id: int | None = None
    bus_no: str | None = None
    driver_id: int | None = None
    driver_name: str | None = None
    changed_by_name: str
    reason: str
    created_at: datetime


# --- Bookings ---

class BookingCreate(BaseModel):
    trip_id: int
    passenger_name: str = Field(..., min_length=2, max_length=120)
    contact_demo: str = Field(..., min_length=5, max_length=120)
    quantity: int = Field(..., ge=1, le=10)
    idempotency_key: str | None = Field(None, max_length=120)


class BookingCancelRequest(BaseModel):
    reason: str = Field("Passenger requested cancellation", min_length=3, max_length=255)


class BookingStatusRequest(BaseModel):
    status: Literal["Completed", "No-show"]
    reason: str = Field("Staff status check", min_length=2, max_length=255)


class BookingTripBrief(BaseModel):
    id: int
    trip_no: str
    service_date: date
    departure_at: datetime
    estimated_arrival_at: datetime
    status: str
    route_name: str
    origin: str
    destination: str
    bus_no: str | None = None


class BookingOut(BaseModel):
    id: int
    booking_ref: str
    trip_id: int
    passenger_user_id: int | None = None
    passenger_name: str
    contact_demo: str
    quantity: int
    total_fare: Decimal
    status: str
    payment_status_demo: str
    cancellation_reason: str | None = None
    created_at: datetime
    cancelled_at: datetime | None = None
    trip: BookingTripBrief | None = None


class NotificationOut(BaseModel):
    id: int
    user_id: int
    message: str
    is_read: bool
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)
