from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles

from app.config import settings
from app.database import Base, engine
from app.routers import auth_users, bookings_reports, master_data, operations

PROJECT_ROOT = Path(__file__).resolve().parents[2]
FRONTEND_DIST = (
    PROJECT_ROOT
    / "City_Bus_Management_System_React_Frontend"
    / "City-Bus-Management-System-Frontend"
    / "dist"
)


@asynccontextmanager
async def lifespan(_: FastAPI):
    Base.metadata.create_all(bind=engine)
    yield


app = FastAPI(
    title=settings.APP_NAME,
    description="Training/Demo API for CityTransit City Bus Management System. NOT LIVE TRANSIT.",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(HTTPException)
async def http_exception_handler(_: Request, exc: HTTPException) -> JSONResponse:
    error = exc.detail if isinstance(exc.detail, dict) and "code" in exc.detail else {
        "code": "HTTP_ERROR", "message": str(exc.detail), "details": {}
    }
    return JSONResponse(status_code=exc.status_code, content={"error": error})


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(_: Request, exc: RequestValidationError) -> JSONResponse:
    fields = {
        ".".join(str(p) for p in err.get("loc", []) if p != "body") or "request": err.get("msg", "Invalid")
        for err in exc.errors()
    }
    return JSONResponse(
        status_code=400,
        content={"error": {"code": "VALIDATION_ERROR", "message": "Validation failed", "details": {"fields": fields}}},
    )


@app.exception_handler(Exception)
async def unhandled_exception_handler(_: Request, __: Exception) -> JSONResponse:
    return JSONResponse(
        status_code=500,
        content={"error": {"code": "INTERNAL_SERVER_ERROR", "message": "Unexpected server error", "details": {}}},
    )


@app.get("/api/health", tags=["Health"])
def health():
    return {"status": "ok", "mode": "DEMO / NOT LIVE TRANSIT", "app": settings.APP_NAME}


app.include_router(auth_users.router, prefix="/api")
app.include_router(master_data.router, prefix="/api")
app.include_router(operations.router, prefix="/api")
app.include_router(bookings_reports.router, prefix="/api")


# ==============================================================================
# FRONTEND SPA HOSTING (serves React production bundle directly on port 8000)
# ==============================================================================

assets_dir = FRONTEND_DIST / "assets"
if assets_dir.is_dir():
    app.mount("/assets", StaticFiles(directory=str(assets_dir)), name="frontend-assets")


NO_STORE = {"Cache-Control": "no-store"}


@app.get("/", include_in_schema=False)
def serve_root():
    index_file = FRONTEND_DIST / "index.html"
    if index_file.is_file():
        return FileResponse(str(index_file), headers=NO_STORE)
    return RedirectResponse(url="/docs")


@app.get("/{full_path:path}", include_in_schema=False)
def serve_spa(full_path: str):
    if full_path == "api" or full_path.startswith("api/"):
        raise HTTPException(status_code=404, detail="API endpoint not found")

    index_file = FRONTEND_DIST / "index.html"
    if not index_file.is_file():
        return RedirectResponse(url="/docs")

    # Resolve static files safely inside dist/ (e.g., favicon, manifest)
    dist_root = FRONTEND_DIST.resolve()
    candidate = (dist_root / full_path).resolve()
    if candidate.is_relative_to(dist_root) and candidate.is_file():
        return FileResponse(str(candidate))

    return FileResponse(str(index_file), headers=NO_STORE)
