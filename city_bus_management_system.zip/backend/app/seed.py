from datetime import date, datetime, time, timedelta, timezone
from decimal import Decimal

from sqlalchemy.orm import Session

from app.auth import (
    ROLE_ADMIN,
    ROLE_AUDITOR,
    ROLE_CLERK,
    ROLE_DISPATCHER,
    ROLE_DRIVER,
    ROLE_MANAGER,
    ROLE_PASSENGER,
    hash_password,
)
from app.database import Base, SessionLocal, engine
from app.models import (
    AssignmentHistory,
    AuditLog,
    Booking,
    Bus,
    Driver,
    FareRule,
    Notification,
    Role,
    Route,
    RouteStop,
    Schedule,
    Stop,
    Trip,
    TripEvent,
    User,
)

DEMO_PASSWORD = "demo123"


def seed_database(db: Session) -> None:
    if db.query(Role).count() > 0:
        print("Database already seeded. Skipping duplicate seed.")
        return

    roles = {}
    for name, desc in [
        (ROLE_ADMIN, "Full system & user management"),
        (ROLE_MANAGER, "Routes, schedules, trip planning, fleet & reporting"),
        (ROLE_DISPATCHER, "Daily operations, bus/driver assignment, trip status"),
        (ROLE_DRIVER, "Assigned trip updates, departure/arrival & passenger counts"),
        (ROLE_CLERK, "Counter search, passenger bookings, cancellations & attendance"),
        (ROLE_PASSENGER, "Search published trips & manage own demo bookings"),
        (ROLE_AUDITOR, "Read-only operational reports & audit trail"),
    ]:
        r = Role(name=name, description=desc)
        db.add(r)
        roles[name] = r
    db.flush()

    pw_hash = hash_password(DEMO_PASSWORD)
    users = {}
    for name, email, role_name, contact in [
        ("System Administrator", "admin@citytransit.demo", ROLE_ADMIN, "9000000001"),
        ("Demo Transport Manager", "manager@citytransit.demo", ROLE_MANAGER, "9000000002"),
        ("Demo Dispatcher", "dispatcher@citytransit.demo", ROLE_DISPATCHER, "9000000003"),
        ("Ravi Kumar", "driver1@citytransit.demo", ROLE_DRIVER, "9000000101"),
        ("Suresh Reddy", "driver2@citytransit.demo", ROLE_DRIVER, "9000000102"),
        ("Demo Booking Clerk", "clerk@citytransit.demo", ROLE_CLERK, "9000000004"),
        ("Priya Rao", "passenger@citytransit.demo", ROLE_PASSENGER, "9000000199"),
        ("Owen Auditor", "auditor@citytransit.demo", ROLE_AUDITOR, "9000000005"),
    ]:
        u = User(name=name, email=email, password_hash=pw_hash, role_id=roles[role_name].id, contact_demo=contact, active=True)
        db.add(u)
        users[email] = u
    db.flush()

    stops = {}
    for code, name, area in [
        ("ST-001", "Miyapur Metro", "Miyapur"),
        ("ST-002", "KPHB Colony", "Kukatpally"),
        ("ST-003", "Ameerpet", "Ameerpet"),
        ("ST-004", "RGIA Airport", "Shamshabad"),
        ("ST-005", "Secunderabad Hub", "Secunderabad"),
        ("ST-006", "Gachibowli Circle", "Gachibowli"),
    ]:
        s = Stop(stop_code=code, name=name, area=area, active=True)
        db.add(s)
        stops[code] = s
    db.flush()

    r1 = Route(route_code="R-01", name="Airport Express", origin="Miyapur", destination="RGIA Airport", distance_note="42 km", active=True)
    r2 = Route(route_code="R-02", name="City Central", origin="Secunderabad", destination="Mehdipatnam", distance_note="19 km", active=True)
    r3 = Route(route_code="R-03", name="Tech Corridor", origin="Kukatpally", destination="Gachibowli", distance_note="16 km", active=True)
    db.add_all([r1, r2, r3])
    db.flush()

    for code, seq, off in [("ST-001", 1, 0), ("ST-002", 2, 15), ("ST-003", 3, 35), ("ST-004", 4, 90)]:
        db.add(RouteStop(route_id=r1.id, stop_id=stops[code].id, sequence=seq, estimated_offset_min=off))
    for code, seq, off in [("ST-005", 1, 0), ("ST-003", 2, 25)]:
        db.add(RouteStop(route_id=r2.id, stop_id=stops[code].id, sequence=seq, estimated_offset_min=off))
    for code, seq, off in [("ST-002", 1, 0), ("ST-006", 2, 45)]:
        db.add(RouteStop(route_id=r3.id, stop_id=stops[code].id, sequence=seq, estimated_offset_min=off))

    b1 = Bus(bus_no="CT-101", registration_demo="TS09-AB-1001", capacity=40, bus_type="AC Seater", status="Assigned", active=True)
    b2 = Bus(bus_no="CT-102", registration_demo="TS09-AB-1002", capacity=50, bus_type="Non-AC", status="Assigned", active=True)
    b3 = Bus(bus_no="CT-103", registration_demo="TS09-AB-1003", capacity=35, bus_type="Electric", status="Maintenance", active=True)
    b4 = Bus(bus_no="CT-104", registration_demo="TS09-AB-1004", capacity=40, bus_type="AC Seater", status="Available", active=True)
    db.add_all([b1, b2, b3, b4])
    db.flush()

    d1 = Driver(user_id=users["driver1@citytransit.demo"].id, employee_code="DRV-001", name="Ravi Kumar", license_demo="DL-DEMO-001", contact_demo="9000000101", status="Assigned", active=True)
    d2 = Driver(user_id=users["driver2@citytransit.demo"].id, employee_code="DRV-002", name="Suresh Reddy", license_demo="DL-DEMO-002", contact_demo="9000000102", status="Available", active=True)
    d3 = Driver(user_id=None, employee_code="DRV-003", name="Anil Sharma", license_demo="DL-DEMO-003", contact_demo="9000000103", status="On Leave", active=True)
    db.add_all([d1, d2, d3])
    db.flush()

    sch1 = Schedule(route_id=r1.id, departure_time=time(6, 30), duration_min=90, fare=Decimal("250.00"), service_rule="Daily", published=True, active=True)
    sch2 = Schedule(route_id=r2.id, departure_time=time(8, 0), duration_min=55, fare=Decimal("45.00"), service_rule="Mon-Sat", published=True, active=True)
    sch3 = Schedule(route_id=r3.id, departure_time=time(9, 15), duration_min=45, fare=Decimal("35.00"), service_rule="Daily", published=True, active=True)
    db.add_all([sch1, sch2, sch3])
    db.flush()

    db.add(FareRule(route_id=r1.id, fare_amount=Decimal("250.00"), effective_date=date.today(), active=True))

    today = date.today()
    tomorrow = today + timedelta(days=1)

    def make_trip(no, sch, dt, bus=None, drv=None, st="Scheduled", pax=0):
        dep = datetime.combine(dt, sch.departure_time, tzinfo=timezone.utc)
        return Trip(
            trip_no=no, schedule_id=sch.id, service_date=dt,
            departure_at=dep, estimated_arrival_at=dep + timedelta(minutes=sch.duration_min),
            bus_id=bus.id if bus else None, driver_id=drv.id if drv else None,
            status=st, passenger_count=pax, fare_snapshot=sch.fare,
        )

    t1 = make_trip("TR-2601", sch1, today, b1, d1, "Assigned", 28)
    t2 = make_trip("TR-2602", sch2, tomorrow, b2, d2, "Assigned", 0)
    t3 = make_trip("TR-2603", sch1, tomorrow, b1, d1, "Assigned", 0)
    t4 = make_trip("TR-2604", sch3, today, None, None, "Scheduled", 0)
    db.add_all([t1, t2, t3, t4])
    db.flush()

    disp_id = users["dispatcher@citytransit.demo"].id
    db.add(AssignmentHistory(trip_id=t1.id, bus_id=b1.id, driver_id=d1.id, changed_by=disp_id, reason="Initial dispatch seed"))
    db.add(TripEvent(trip_id=t1.id, event_type="assignment", actor_id=disp_id, note="Assigned CT-101 and Ravi Kumar"))
    db.add(Booking(
        booking_ref="BK-8F21A", trip_id=t3.id, passenger_user_id=users["passenger@citytransit.demo"].id,
        passenger_name="Priya Rao", contact_demo="9000000199", quantity=2,
        total_fare=sch1.fare * 2, status="Confirmed", payment_status_demo="Demo Paid", idempotency_key="seed-bk-1",
    ))
    db.add(AuditLog(actor_id=users["admin@citytransit.demo"].id, action="SEED_INIT", entity="System", entity_id="DEMO", reason="Seeded CityTransit demo data"))
    db.add_all(
        [
            Notification(
                user_id=users["admin@citytransit.demo"].id,
                message="CityTransit DEMO initialized with 4 buses, 3 routes, and 4 scheduled trips.",
            ),
            Notification(
                user_id=users["driver1@citytransit.demo"].id,
                message="Assigned to trip TR-2601 with bus CT-101 on today's schedule.",
            ),
            Notification(
                user_id=users["passenger@citytransit.demo"].id,
                message="Booking BK-8F21A confirmed for trip TR-2603 (2 seats).",
            ),
        ]
    )
    db.commit()
    print("Seeded CityTransit (DEMO) dataset successfully.")


def run_seed() -> None:
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        seed_database(db)
    finally:
        db.close()


if __name__ == "__main__":
    run_seed()
