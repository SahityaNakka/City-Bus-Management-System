import math

from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.orm import Session, joinedload

from app.auth import (
    ROLE_ADMIN,
    ROLE_AUDITOR,
    ROLE_DISPATCHER,
    ROLE_MANAGER,
    api_error,
    get_current_user,
    require_roles,
)
from app.database import get_db
from app.models import AssignmentHistory, Bus, Driver, Route, RouteStop, Schedule, Stop, Trip, User
from app.schemas import (
    AssignmentHistoryOut,
    BusCreate,
    BusOut,
    BusUpdate,
    DriverCreate,
    DriverOut,
    DriverUpdate,
    PaginatedResponse,
    RouteCreate,
    RouteDetailOut,
    RouteOut,
    RouteStopIn,
    RouteStopOut,
    RouteUpdate,
    StopCreate,
    StopOut,
    StopUpdate,
)
from app.services import update_route_stops, write_audit

router = APIRouter(tags=["Fleet, Drivers, Routes & Stops"])


# --- Buses ---

@router.get("/buses", response_model=PaginatedResponse[BusOut])
def list_buses(
    search: str | None = None,
    status_filter: str | None = Query(None, alias="status"),
    page: int = Query(1, ge=1),
    size: int = Query(50, ge=1, le=200),
    db: Session = Depends(get_db),
    _: User = Depends(require_roles(ROLE_ADMIN, ROLE_MANAGER, ROLE_DISPATCHER, ROLE_AUDITOR)),
):
    query = db.query(Bus)
    if search:
        term = f"%{search.strip()}%"
        query = query.filter(Bus.bus_no.ilike(term) | Bus.registration_demo.ilike(term) | Bus.bus_type.ilike(term))
    if status_filter:
        query = query.filter(Bus.status == status_filter)
    total = query.count()
    items = query.order_by(Bus.bus_no.asc()).offset((page - 1) * size).limit(size).all()
    return PaginatedResponse(items=[BusOut.model_validate(b) for b in items], total=total, page=page, size=size, total_pages=max(1, math.ceil(total / size)))


@router.post("/buses", response_model=BusOut, status_code=201)
def create_bus(
    payload: BusCreate,
    db: Session = Depends(get_db),
    actor: User = Depends(require_roles(ROLE_ADMIN, ROLE_MANAGER)),
):
    bus_no = payload.bus_no.strip().upper()
    if db.query(Bus).filter(Bus.bus_no == bus_no).first():
        raise api_error(status.HTTP_409_CONFLICT, "DUPLICATE_BUS_NO", f"Bus '{bus_no}' already exists")
    bus = Bus(
        bus_no=bus_no,
        registration_demo=payload.registration_demo.strip().upper(),
        capacity=payload.capacity,
        bus_type=payload.bus_type.strip(),
        status=payload.status,
        active=payload.active and payload.status != "Inactive",
    )
    db.add(bus)
    db.flush()
    write_audit(db, actor.id, "CREATE_BUS", "Bus", bus.id)
    db.commit()
    db.refresh(bus)
    return BusOut.model_validate(bus)


@router.patch("/buses/{bus_id}", response_model=BusOut)
def update_bus(
    bus_id: int,
    payload: BusUpdate,
    db: Session = Depends(get_db),
    actor: User = Depends(require_roles(ROLE_ADMIN, ROLE_MANAGER)),
):
    bus = db.query(Bus).filter(Bus.id == bus_id).first()
    if not bus:
        raise api_error(status.HTTP_404_NOT_FOUND, "NOT_FOUND", "Bus not found")
    if payload.bus_no is not None:
        code = payload.bus_no.strip().upper()
        if db.query(Bus).filter(Bus.bus_no == code, Bus.id != bus_id).first():
            raise api_error(status.HTTP_409_CONFLICT, "DUPLICATE_BUS_NO", f"Bus '{code}' already exists")
        bus.bus_no = code
    if payload.registration_demo is not None:
        bus.registration_demo = payload.registration_demo.strip().upper()
    if payload.capacity is not None:
        bus.capacity = payload.capacity
    if payload.bus_type is not None:
        bus.bus_type = payload.bus_type.strip()
    if payload.status is not None:
        bus.status = payload.status
        bus.active = payload.status != "Inactive"
    if payload.active is not None:
        bus.active = payload.active
        if not payload.active:
            bus.status = "Inactive"

    write_audit(db, actor.id, "UPDATE_BUS", "Bus", bus.id)
    db.commit()
    db.refresh(bus)
    return BusOut.model_validate(bus)


@router.get("/buses/{bus_id}/assignments", response_model=list[AssignmentHistoryOut])
def bus_assignment_history(
    bus_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(require_roles(ROLE_ADMIN, ROLE_MANAGER, ROLE_DISPATCHER, ROLE_AUDITOR)),
):
    if not db.query(Bus).filter(Bus.id == bus_id).first():
        raise api_error(status.HTTP_404_NOT_FOUND, "NOT_FOUND", "Bus not found")
    rows = (
        db.query(AssignmentHistory)
        .options(joinedload(AssignmentHistory.bus), joinedload(AssignmentHistory.driver), joinedload(AssignmentHistory.actor))
        .filter(AssignmentHistory.bus_id == bus_id)
        .order_by(AssignmentHistory.created_at.desc())
        .all()
    )
    return [
        AssignmentHistoryOut(
            id=r.id, trip_id=r.trip_id, bus_id=r.bus_id, bus_no=r.bus.bus_no if r.bus else None,
            driver_id=r.driver_id, driver_name=r.driver.name if r.driver else None,
            changed_by_name=r.actor.name if r.actor else "System", reason=r.reason, created_at=r.created_at,
        )
        for r in rows
    ]


# --- Drivers ---

@router.get("/drivers", response_model=PaginatedResponse[DriverOut])
def list_drivers(
    search: str | None = None,
    status_filter: str | None = Query(None, alias="status"),
    page: int = Query(1, ge=1),
    size: int = Query(50, ge=1, le=200),
    db: Session = Depends(get_db),
    _: User = Depends(require_roles(ROLE_ADMIN, ROLE_MANAGER, ROLE_DISPATCHER, ROLE_AUDITOR)),
):
    query = db.query(Driver)
    if search:
        term = f"%{search.strip()}%"
        query = query.filter(Driver.employee_code.ilike(term) | Driver.name.ilike(term) | Driver.license_demo.ilike(term))
    if status_filter:
        query = query.filter(Driver.status == status_filter)
    total = query.count()
    items = query.order_by(Driver.employee_code.asc()).offset((page - 1) * size).limit(size).all()
    return PaginatedResponse(items=[DriverOut.model_validate(d) for d in items], total=total, page=page, size=size, total_pages=max(1, math.ceil(total / size)))


@router.post("/drivers", response_model=DriverOut, status_code=201)
def create_driver(
    payload: DriverCreate,
    db: Session = Depends(get_db),
    actor: User = Depends(require_roles(ROLE_ADMIN, ROLE_MANAGER)),
):
    code = payload.employee_code.strip().upper()
    if db.query(Driver).filter(Driver.employee_code == code).first():
        raise api_error(status.HTTP_409_CONFLICT, "DUPLICATE_EMPLOYEE_CODE", f"Driver '{code}' already exists")
    drv = Driver(
        employee_code=code, name=payload.name.strip(), license_demo=payload.license_demo.strip().upper(),
        contact_demo=payload.contact_demo.strip(), user_id=payload.user_id,
        status=payload.status, active=payload.active and payload.status != "Inactive",
    )
    db.add(drv)
    db.flush()
    write_audit(db, actor.id, "CREATE_DRIVER", "Driver", drv.id)
    db.commit()
    db.refresh(drv)
    return DriverOut.model_validate(drv)


@router.patch("/drivers/{driver_id}", response_model=DriverOut)
def update_driver(
    driver_id: int,
    payload: DriverUpdate,
    db: Session = Depends(get_db),
    actor: User = Depends(require_roles(ROLE_ADMIN, ROLE_MANAGER)),
):
    drv = db.query(Driver).filter(Driver.id == driver_id).first()
    if not drv:
        raise api_error(status.HTTP_404_NOT_FOUND, "NOT_FOUND", "Driver not found")
    if payload.name is not None:
        drv.name = payload.name.strip()
    if payload.license_demo is not None:
        drv.license_demo = payload.license_demo.strip().upper()
    if payload.contact_demo is not None:
        drv.contact_demo = payload.contact_demo.strip()
    if payload.status is not None:
        drv.status = payload.status
        drv.active = payload.status != "Inactive"
    if payload.active is not None:
        drv.active = payload.active
        if not payload.active:
            drv.status = "Inactive"

    write_audit(db, actor.id, "UPDATE_DRIVER", "Driver", drv.id)
    db.commit()
    db.refresh(drv)
    return DriverOut.model_validate(drv)


@router.get("/drivers/{driver_id}/assignments", response_model=list[AssignmentHistoryOut])
def driver_assignment_history(
    driver_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(require_roles(ROLE_ADMIN, ROLE_MANAGER, ROLE_DISPATCHER, ROLE_AUDITOR)),
):
    if not db.query(Driver).filter(Driver.id == driver_id).first():
        raise api_error(status.HTTP_404_NOT_FOUND, "NOT_FOUND", "Driver not found")
    rows = (
        db.query(AssignmentHistory)
        .options(joinedload(AssignmentHistory.bus), joinedload(AssignmentHistory.driver), joinedload(AssignmentHistory.actor))
        .filter(AssignmentHistory.driver_id == driver_id)
        .order_by(AssignmentHistory.created_at.desc())
        .all()
    )
    return [
        AssignmentHistoryOut(
            id=r.id, trip_id=r.trip_id, bus_id=r.bus_id, bus_no=r.bus.bus_no if r.bus else None,
            driver_id=r.driver_id, driver_name=r.driver.name if r.driver else None,
            changed_by_name=r.actor.name if r.actor else "System", reason=r.reason, created_at=r.created_at,
        )
        for r in rows
    ]


# --- Stops ---

@router.get("/stops", response_model=PaginatedResponse[StopOut])
def list_stops(
    search: str | None = None,
    active: bool | None = None,
    page: int = Query(1, ge=1),
    size: int = Query(100, ge=1, le=200),
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user),
):
    query = db.query(Stop)
    if search:
        term = f"%{search.strip()}%"
        query = query.filter(Stop.stop_code.ilike(term) | Stop.name.ilike(term) | Stop.area.ilike(term))
    if active is not None:
        query = query.filter(Stop.active.is_(active))
    total = query.count()
    items = query.order_by(Stop.stop_code.asc()).offset((page - 1) * size).limit(size).all()
    return PaginatedResponse(items=[StopOut.model_validate(s) for s in items], total=total, page=page, size=size, total_pages=max(1, math.ceil(total / size)))


@router.post("/stops", response_model=StopOut, status_code=201)
def create_stop(
    payload: StopCreate,
    db: Session = Depends(get_db),
    actor: User = Depends(require_roles(ROLE_ADMIN, ROLE_MANAGER)),
):
    code = payload.stop_code.strip().upper()
    if db.query(Stop).filter(Stop.stop_code == code).first():
        raise api_error(status.HTTP_409_CONFLICT, "DUPLICATE_STOP_CODE", f"Stop '{code}' already exists")
    stop = Stop(stop_code=code, name=payload.name.strip(), area=payload.area.strip(), active=payload.active)
    db.add(stop)
    db.flush()
    write_audit(db, actor.id, "CREATE_STOP", "Stop", stop.id)
    db.commit()
    db.refresh(stop)
    return StopOut.model_validate(stop)


@router.patch("/stops/{stop_id}", response_model=StopOut)
def update_stop(
    stop_id: int,
    payload: StopUpdate,
    db: Session = Depends(get_db),
    actor: User = Depends(require_roles(ROLE_ADMIN, ROLE_MANAGER)),
):
    stop = db.query(Stop).filter(Stop.id == stop_id).first()
    if not stop:
        raise api_error(status.HTTP_404_NOT_FOUND, "NOT_FOUND", "Stop not found")
    if payload.name is not None:
        stop.name = payload.name.strip()
    if payload.area is not None:
        stop.area = payload.area.strip()
    if payload.active is not None:
        stop.active = payload.active
    write_audit(db, actor.id, "UPDATE_STOP", "Stop", stop.id)
    db.commit()
    db.refresh(stop)
    return StopOut.model_validate(stop)


# --- Routes & Ordered Stops ---

@router.get("/routes", response_model=PaginatedResponse[RouteOut])
def list_routes(
    search: str | None = None,
    active: bool | None = None,
    page: int = Query(1, ge=1),
    size: int = Query(50, ge=1, le=200),
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user),
):
    query = db.query(Route).options(joinedload(Route.route_stops))
    if search:
        term = f"%{search.strip()}%"
        query = query.filter(Route.route_code.ilike(term) | Route.name.ilike(term) | Route.origin.ilike(term) | Route.destination.ilike(term))
    if active is not None:
        query = query.filter(Route.active.is_(active))
    total = query.count()
    items = query.order_by(Route.route_code.asc()).offset((page - 1) * size).limit(size).all()
    return PaginatedResponse(items=[RouteOut.model_validate(r) for r in items], total=total, page=page, size=size, total_pages=max(1, math.ceil(total / size)))


@router.get("/routes/{route_id}", response_model=RouteDetailOut)
def get_route(route_id: int, db: Session = Depends(get_db), _: User = Depends(get_current_user)):
    route = (
        db.query(Route)
        .options(joinedload(Route.route_stops).joinedload(RouteStop.stop))
        .filter(Route.id == route_id)
        .first()
    )
    if not route:
        raise api_error(status.HTTP_404_NOT_FOUND, "NOT_FOUND", "Route not found")
    return RouteDetailOut.model_validate(route)


@router.post("/routes", response_model=RouteDetailOut, status_code=201)
def create_route(
    payload: RouteCreate,
    db: Session = Depends(get_db),
    actor: User = Depends(require_roles(ROLE_ADMIN, ROLE_MANAGER)),
):
    code = payload.route_code.strip().upper()
    if db.query(Route).filter(Route.route_code == code).first():
        raise api_error(status.HTTP_409_CONFLICT, "DUPLICATE_ROUTE_CODE", f"Route '{code}' already exists")
    route = Route(
        route_code=code, name=payload.name.strip(), origin=payload.origin.strip(),
        destination=payload.destination.strip(), distance_note=payload.distance_note, active=payload.active,
    )
    db.add(route)
    db.flush()
    write_audit(db, actor.id, "CREATE_ROUTE", "Route", route.id)
    db.commit()
    if payload.stops:
        route = update_route_stops(db, route.id, payload.stops, actor.id)
    else:
        route = db.query(Route).options(joinedload(Route.route_stops).joinedload(RouteStop.stop)).filter(Route.id == route.id).first()
    return RouteDetailOut.model_validate(route)


@router.patch("/routes/{route_id}", response_model=RouteOut)
def update_route(
    route_id: int,
    payload: RouteUpdate,
    db: Session = Depends(get_db),
    actor: User = Depends(require_roles(ROLE_ADMIN, ROLE_MANAGER)),
):
    route = db.query(Route).options(joinedload(Route.route_stops)).filter(Route.id == route_id).first()
    if not route:
        raise api_error(status.HTTP_404_NOT_FOUND, "NOT_FOUND", "Route not found")
    if payload.name is not None:
        route.name = payload.name.strip()
    if payload.origin is not None:
        route.origin = payload.origin.strip()
    if payload.destination is not None:
        route.destination = payload.destination.strip()
    if payload.distance_note is not None:
        route.distance_note = payload.distance_note
    if payload.active is not None:
        route.active = payload.active
    write_audit(db, actor.id, "UPDATE_ROUTE", "Route", route.id)
    db.commit()
    db.refresh(route)
    return RouteOut.model_validate(route)


@router.get("/routes/{route_id}/stops", response_model=list[RouteStopOut])
def get_route_stops(route_id: int, db: Session = Depends(get_db), _: User = Depends(get_current_user)):
    route = db.query(Route).options(joinedload(Route.route_stops).joinedload(RouteStop.stop)).filter(Route.id == route_id).first()
    if not route:
        raise api_error(status.HTTP_404_NOT_FOUND, "NOT_FOUND", "Route not found")
    return [RouteStopOut.model_validate(rs) for rs in route.route_stops]


@router.post("/routes/{route_id}/stops", response_model=RouteDetailOut)
@router.put("/routes/{route_id}/stops", response_model=RouteDetailOut)
def set_route_stops(
    route_id: int,
    stops: list[RouteStopIn],
    db: Session = Depends(get_db),
    actor: User = Depends(require_roles(ROLE_ADMIN, ROLE_MANAGER)),
):
    return RouteDetailOut.model_validate(update_route_stops(db, route_id, stops, actor.id))


@router.delete("/buses/{bus_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_bus(
    bus_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(ROLE_ADMIN, ROLE_MANAGER)),
):
    bus = db.query(Bus).filter(Bus.id == bus_id).first()
    if not bus:
        raise api_error(status.HTTP_404_NOT_FOUND, "BUS_NOT_FOUND", "Bus not found")
    assigned_trips = db.query(Trip).filter(Trip.bus_id == bus_id).count()
    if assigned_trips > 0:
        raise api_error(
            status.HTTP_400_BAD_REQUEST,
            "BUS_IN_USE",
            f"Cannot delete bus {bus.bus_no} because it is assigned to {assigned_trips} trip(s).",
        )
    write_audit(db, current_user.id, "DELETE_BUS", "Bus", bus.id, f"Deleted bus {bus.bus_no}")
    db.delete(bus)
    db.commit()
    return None


@router.delete("/drivers/{driver_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_driver(
    driver_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(ROLE_ADMIN, ROLE_MANAGER)),
):
    drv = db.query(Driver).filter(Driver.id == driver_id).first()
    if not drv:
        raise api_error(status.HTTP_404_NOT_FOUND, "DRIVER_NOT_FOUND", "Driver not found")
    # Unassign from trips so driver can be deleted without cascade breakage
    db.query(Trip).filter(Trip.driver_id == driver_id).update({Trip.driver_id: None})
    write_audit(db, current_user.id, "DELETE_DRIVER", "Driver", drv.id, f"Deleted driver {drv.employee_code}")
    db.delete(drv)
    db.commit()
    return None


@router.delete("/stops/{stop_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_stop(
    stop_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(ROLE_ADMIN, ROLE_MANAGER)),
):
    stop = db.query(Stop).filter(Stop.id == stop_id).first()
    if not stop:
        raise api_error(status.HTTP_404_NOT_FOUND, "STOP_NOT_FOUND", "Stop not found")
    linked_routes = db.query(RouteStop).filter(RouteStop.stop_id == stop_id).count()
    if linked_routes > 0:
        raise api_error(
            status.HTTP_400_BAD_REQUEST,
            "STOP_IN_USE",
            f"Cannot delete stop {stop.stop_code} because it is used in {linked_routes} route(s).",
        )
    write_audit(db, current_user.id, "DELETE_STOP", "Stop", stop.id, f"Deleted stop {stop.stop_code}")
    db.delete(stop)
    db.commit()
    return None


@router.delete("/routes/{route_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_route(
    route_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(ROLE_ADMIN, ROLE_MANAGER)),
):
    route = db.query(Route).filter(Route.id == route_id).first()
    if not route:
        raise api_error(status.HTTP_404_NOT_FOUND, "ROUTE_NOT_FOUND", "Route not found")
    linked_schedules = db.query(Schedule).filter(Schedule.route_id == route_id).count()
    if linked_schedules > 0:
        raise api_error(
            status.HTTP_400_BAD_REQUEST,
            "ROUTE_IN_USE",
            f"Cannot delete route {route.route_code} because {linked_schedules} schedule(s) depend on it.",
        )
    db.query(RouteStop).filter(RouteStop.route_id == route_id).delete()
    write_audit(db, current_user.id, "DELETE_ROUTE", "Route", route.id, f"Deleted route {route.route_code}")
    db.delete(route)
    db.commit()
    return None
