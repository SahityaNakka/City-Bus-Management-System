import math

from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.orm import Session, joinedload

from app.auth import (
    ROLE_ADMIN,
    ROLE_PASSENGER,
    api_error,
    create_access_token,
    get_current_user,
    hash_password,
    require_roles,
    verify_password,
)
from app.database import get_db
from app.models import Notification, Role, User
from app.schemas import (
    LoginRequest,
    NotificationOut,
    PaginatedResponse,
    PassengerRegisterRequest,
    RoleOut,
    TokenResponse,
    UserCreate,
    UserOut,
    UserUpdate,
)
from app.services import create_notification, write_audit

router = APIRouter(tags=["Auth & Users"])


@router.post("/auth/login", response_model=TokenResponse)
def login(payload: LoginRequest, db: Session = Depends(get_db)):
    user = (
        db.query(User)
        .options(joinedload(User.role), joinedload(User.driver_profile))
        .filter(User.email == payload.email.lower().strip())
        .first()
    )
    if not user or not verify_password(payload.password, user.password_hash):
        raise api_error(status.HTTP_401_UNAUTHORIZED, "INVALID_CREDENTIALS", "Invalid email or password")
    if not user.active:
        raise api_error(status.HTTP_401_UNAUTHORIZED, "ACCOUNT_INACTIVE", "User account is deactivated")

    token = create_access_token(user.id, user.role.name)
    write_audit(db, user.id, "LOGIN", "User", user.id)
    db.commit()
    return TokenResponse(access_token=token, user=UserOut.model_validate(user))


@router.post("/auth/register", response_model=TokenResponse, status_code=201)
def register_passenger(payload: PassengerRegisterRequest, db: Session = Depends(get_db)):
    email = payload.email.lower().strip()
    if db.query(User).filter(User.email == email).first():
        raise api_error(status.HTTP_409_CONFLICT, "DUPLICATE_EMAIL", "Email is already registered")

    passenger_role = db.query(Role).filter(Role.name == ROLE_PASSENGER).first()
    if not passenger_role:
        raise api_error(status.HTTP_400_BAD_REQUEST, "MISSING_ROLE", "Passenger role not found")

    user = User(
        name=payload.name.strip(),
        email=email,
        password_hash=hash_password(payload.password),
        role_id=passenger_role.id,
        contact_demo=payload.contact_demo.strip(),
        active=True,
    )
    db.add(user)
    db.flush()
    write_audit(db, user.id, "REGISTER_PASSENGER", "User", user.id)
    create_notification(db, user.id, f"Welcome to CityTransit DEMO, {user.name}!")
    db.commit()
    user = db.query(User).options(joinedload(User.role)).filter(User.id == user.id).first()
    return TokenResponse(access_token=create_access_token(user.id, user.role.name), user=UserOut.model_validate(user))


@router.get("/auth/me", response_model=UserOut)
def get_me(current_user: User = Depends(get_current_user)):
    return UserOut.model_validate(current_user)


@router.get("/users/roles", response_model=list[RoleOut])
def list_roles(db: Session = Depends(get_db), _: User = Depends(require_roles(ROLE_ADMIN))):
    return db.query(Role).order_by(Role.id.asc()).all()


@router.get("/users", response_model=PaginatedResponse[UserOut])
def list_users(
    search: str | None = None,
    role_id: int | None = None,
    page: int = Query(1, ge=1),
    size: int = Query(50, ge=1, le=200),
    db: Session = Depends(get_db),
    _: User = Depends(require_roles(ROLE_ADMIN)),
):
    query = db.query(User).options(joinedload(User.role))
    if search:
        term = f"%{search.strip()}%"
        query = query.filter(User.name.ilike(term) | User.email.ilike(term))
    if role_id:
        query = query.filter(User.role_id == role_id)

    total = query.count()
    items = query.order_by(User.id.asc()).offset((page - 1) * size).limit(size).all()
    return PaginatedResponse(
        items=[UserOut.model_validate(u) for u in items],
        total=total,
        page=page,
        size=size,
        total_pages=max(1, math.ceil(total / size)),
    )


@router.post("/users", response_model=UserOut, status_code=201)
def create_user(
    payload: UserCreate,
    db: Session = Depends(get_db),
    actor: User = Depends(require_roles(ROLE_ADMIN)),
):
    email = payload.email.lower().strip()
    if db.query(User).filter(User.email == email).first():
        raise api_error(status.HTTP_409_CONFLICT, "DUPLICATE_EMAIL", "Email already exists")

    role = db.query(Role).filter(Role.id == payload.role_id).first()
    if not role:
        raise api_error(status.HTTP_400_BAD_REQUEST, "INVALID_ROLE", "Invalid role_id")

    user = User(
        name=payload.name.strip(),
        email=email,
        password_hash=hash_password(payload.password),
        role_id=role.id,
        contact_demo=payload.contact_demo,
        active=True,
    )
    db.add(user)
    db.flush()
    write_audit(db, actor.id, "CREATE_USER", "User", user.id, f"Role: {role.name}")
    db.commit()
    user = db.query(User).options(joinedload(User.role)).filter(User.id == user.id).first()
    return UserOut.model_validate(user)


@router.patch("/users/{user_id}", response_model=UserOut)
def update_user(
    user_id: int,
    payload: UserUpdate,
    db: Session = Depends(get_db),
    actor: User = Depends(require_roles(ROLE_ADMIN)),
):
    user = db.query(User).options(joinedload(User.role)).filter(User.id == user_id).first()
    if not user:
        raise api_error(status.HTTP_404_NOT_FOUND, "NOT_FOUND", "User not found")

    if payload.email is not None:
        normalized = payload.email.lower().strip()
        if db.query(User).filter(User.email == normalized, User.id != user_id).first():
            raise api_error(status.HTTP_409_CONFLICT, "DUPLICATE_EMAIL", "Email already in use")
        user.email = normalized
    if payload.role_id is not None:
        if not db.query(Role).filter(Role.id == payload.role_id).first():
            raise api_error(status.HTTP_400_BAD_REQUEST, "INVALID_ROLE", "Invalid role_id")
        user.role_id = payload.role_id
    if payload.name is not None:
        user.name = payload.name.strip()
    if payload.contact_demo is not None:
        user.contact_demo = payload.contact_demo
    if payload.active is not None:
        if user.id == actor.id and not payload.active:
            raise api_error(status.HTTP_400_BAD_REQUEST, "SELF_DEACTIVATE", "Cannot deactivate yourself")
        user.active = payload.active
    if payload.password:
        user.password_hash = hash_password(payload.password)

    write_audit(db, actor.id, "UPDATE_USER", "User", user.id, "Updated account")
    db.commit()
    user = db.query(User).options(joinedload(User.role)).filter(User.id == user.id).first()
    return UserOut.model_validate(user)


@router.delete("/users/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_user(
    user_id: int,
    db: Session = Depends(get_db),
    actor: User = Depends(require_roles(ROLE_ADMIN)),
):
    if actor.id == user_id:
        raise api_error(status.HTTP_400_BAD_REQUEST, "CANNOT_DELETE_SELF", "You cannot delete your own user account.")
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise api_error(status.HTTP_404_NOT_FOUND, "USER_NOT_FOUND", "User not found")
    write_audit(db, actor.id, "DELETE_USER", "User", user.id, f"Deleted user {user.email}")
    db.delete(user)
    db.commit()
    return None


# ==============================================================================
# SECTION 2: IN-APP NOTIFICATIONS
# ==============================================================================


@router.get("/notifications", response_model=list[NotificationOut])
def list_my_notifications(
    limit: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return (
        db.query(Notification)
        .filter(Notification.user_id == current_user.id)
        .order_by(Notification.created_at.desc(), Notification.id.desc())
        .limit(limit)
        .all()
    )


@router.put("/notifications")
def mark_notifications_read(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    updated = (
        db.query(Notification)
        .filter(Notification.user_id == current_user.id, Notification.is_read.is_(False))
        .update({"is_read": True}, synchronize_session=False)
    )
    db.commit()
    return {"message": "Notifications marked as read", "updated_count": updated}
