import math
from datetime import date

from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.orm import Session, joinedload

from app.auth import (
    ROLE_ADMIN,
    ROLE_AUDITOR,
    ROLE_CLERK,
    ROLE_DISPATCHER,
    ROLE_DRIVER,
    ROLE_MANAGER,
    api_error,
    get_current_user,
    require_roles,
)
from app.database import get_db
from app.models import AssignmentHistory, Booking, FareRule, Route, RouteStop, Schedule, Trip, TripEvent, User
from app.schemas import (
    BookingOut,
    BookingTripBrief,
    FareRuleCreate,
    FareRuleOut,
    GenerateTripsRequest,
    PaginatedResponse,
    ScheduleCreate,
    ScheduleOut,
    ScheduleUpdate,
    TripAssignRequest,
    TripDetailOut,
    TripEventCreate,
    TripEventOut,
    TripOut,
    TripStatusRequest,
)
from app.services import (
    assign_trip_resources,
    change_trip_status,
    generate_trips,
    get_booked_seats,
    log_trip_event,
    validate_route_for_publishing,
    write_audit,
)

router = APIRouter(tags=["Schedules, Fare Rules & Trips"])


def _enrich_trip(db: Session, trip: Trip, detail: bool = False):
    booked = get_booked_seats(db, trip.id)
    avail = max(0, trip.bus.capacity - booked) if trip.bus else 0
    model = TripDetailOut.model_validate(trip) if detail else TripOut.model_validate(trip)
    model.available_seats = avail
    return model


# --- Schedules & Fare Rules ---

@router.get("/schedules", response_model=PaginatedResponse[ScheduleOut])
def list_schedules(
    route_id: int | None = None,
    published: bool | None = None,
    page: int = Query(1, ge=1),
    size: int = Query(50, ge=1, le=200),
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user),
):
    query = db.query(Schedule).options(joinedload(Schedule.route).joinedload(Route.route_stops))
    if route_id:
        query = query.filter(Schedule.route_id == route_id)
    if published is not None:
        query = query.filter(Schedule.published.is_(published))
    total = query.count()
    items = query.order_by(Schedule.route_id.asc(), Schedule.departure_time.asc()).offset((page - 1) * size).limit(size).all()
    return PaginatedResponse(items=[ScheduleOut.model_validate(s) for s in items], total=total, page=page, size=size, total_pages=max(1, math.ceil(total / size)))


@router.post("/schedules", response_model=ScheduleOut, status_code=201)
def create_schedule(
    payload: ScheduleCreate,
    db: Session = Depends(get_db),
    actor: User = Depends(require_roles(ROLE_ADMIN, ROLE_MANAGER)),
):
    route = db.query(Route).filter(Route.id == payload.route_id).first()
    if not route:
        raise api_error(status.HTTP_404_NOT_FOUND, "NOT_FOUND", "Route not found")
    if not route.active:
        raise api_error(status.HTTP_400_BAD_REQUEST, "INACTIVE_ROUTE", "Route is inactive")
    if payload.published:
        validate_route_for_publishing(db, payload.route_id)

    sch = Schedule(
        route_id=payload.route_id, departure_time=payload.departure_time,
        duration_min=payload.duration_min, fare=payload.fare,
        service_rule=payload.service_rule.strip(), published=payload.published, active=payload.active,
    )
    db.add(sch)
    db.flush()
    write_audit(db, actor.id, "CREATE_SCHEDULE", "Schedule", sch.id)
    db.commit()
    sch = db.query(Schedule).options(joinedload(Schedule.route).joinedload(Route.route_stops)).filter(Schedule.id == sch.id).first()
    return ScheduleOut.model_validate(sch)


@router.patch("/schedules/{schedule_id}", response_model=ScheduleOut)
def update_schedule(
    schedule_id: int,
    payload: ScheduleUpdate,
    db: Session = Depends(get_db),
    actor: User = Depends(require_roles(ROLE_ADMIN, ROLE_MANAGER)),
):
    sch = db.query(Schedule).options(joinedload(Schedule.route).joinedload(Route.route_stops)).filter(Schedule.id == schedule_id).first()
    if not sch:
        raise api_error(status.HTTP_404_NOT_FOUND, "NOT_FOUND", "Schedule not found")
    if payload.published is True:
        validate_route_for_publishing(db, sch.route_id)
    if payload.departure_time is not None:
        sch.departure_time = payload.departure_time
    if payload.duration_min is not None:
        sch.duration_min = payload.duration_min
    if payload.fare is not None:
        sch.fare = payload.fare
    if payload.service_rule is not None:
        sch.service_rule = payload.service_rule.strip()
    if payload.published is not None:
        sch.published = payload.published
    if payload.active is not None:
        sch.active = payload.active

    write_audit(db, actor.id, "UPDATE_SCHEDULE", "Schedule", sch.id)
    db.commit()
    sch = db.query(Schedule).options(joinedload(Schedule.route).joinedload(Route.route_stops)).filter(Schedule.id == sch.id).first()
    return ScheduleOut.model_validate(sch)


@router.post("/schedules/{schedule_id}/generate-trips")
def generate_schedule_trips(
    schedule_id: int,
    payload: GenerateTripsRequest,
    db: Session = Depends(get_db),
    actor: User = Depends(require_roles(ROLE_ADMIN, ROLE_MANAGER)),
):
    return generate_trips(db, schedule_id, payload.service_dates, actor)


@router.get("/fare-rules", response_model=list[FareRuleOut])
def list_fare_rules(db: Session = Depends(get_db), _: User = Depends(get_current_user)):
    return db.query(FareRule).order_by(FareRule.effective_date.desc()).all()


@router.post("/fare-rules", response_model=FareRuleOut, status_code=201)
def create_fare_rule(
    payload: FareRuleCreate,
    db: Session = Depends(get_db),
    actor: User = Depends(require_roles(ROLE_ADMIN, ROLE_MANAGER)),
):
    if not payload.route_id and not payload.schedule_id:
        raise api_error(status.HTTP_400_BAD_REQUEST, "MISSING_TARGET", "Provide route_id or schedule_id")
    rule = FareRule(
        route_id=payload.route_id, schedule_id=payload.schedule_id,
        fare_amount=payload.fare_amount, effective_date=payload.effective_date, active=payload.active,
    )
    db.add(rule)
    db.flush()
    write_audit(db, actor.id, "CREATE_FARE_RULE", "FareRule", rule.id)
    db.commit()
    db.refresh(rule)
    return FareRuleOut.model_validate(rule)


@router.patch("/fare-rules/{rule_id}", response_model=FareRuleOut)
def toggle_fare_rule(
    rule_id: int,
    active: bool,
    db: Session = Depends(get_db),
    actor: User = Depends(require_roles(ROLE_ADMIN, ROLE_MANAGER)),
):
    rule = db.query(FareRule).filter(FareRule.id == rule_id).first()
    if not rule:
        raise api_error(status.HTTP_404_NOT_FOUND, "NOT_FOUND", "Fare rule not found")
    rule.active = active
    write_audit(db, actor.id, "UPDATE_FARE_RULE", "FareRule", rule.id, f"active={active}")
    db.commit()
    db.refresh(rule)
    return FareRuleOut.model_validate(rule)


# --- Trips ---

@router.get("/trips", response_model=PaginatedResponse[TripOut])
def list_trips(
    service_date: date | None = None,
    route_id: int | None = None,
    status_filter: str | None = Query(None, alias="status"),
    search: str | None = None,
    page: int = Query(1, ge=1),
    size: int = Query(50, ge=1, le=200),
    db: Session = Depends(get_db),
    current_user: User = Depends(
        require_roles(ROLE_ADMIN, ROLE_MANAGER, ROLE_DISPATCHER, ROLE_DRIVER, ROLE_CLERK, ROLE_AUDITOR)
    ),
):
    query = db.query(Trip).options(
        joinedload(Trip.schedule).joinedload(Schedule.route).joinedload(Route.route_stops),
        joinedload(Trip.bus),
        joinedload(Trip.driver),
    )
    if current_user.role and current_user.role.name == ROLE_DRIVER:
        if not current_user.driver_profile:
            return PaginatedResponse(items=[], total=0, page=page, size=size, total_pages=1)
        query = query.filter(Trip.driver_id == current_user.driver_profile.id)

    if service_date:
        query = query.filter(Trip.service_date == service_date)
    if route_id:
        query = query.join(Trip.schedule).filter(Schedule.route_id == route_id)
    if status_filter:
        query = query.filter(Trip.status == status_filter)
    if search:
        query = query.filter(Trip.trip_no.ilike(f"%{search.strip()}%"))

    total = query.count()
    items = query.order_by(Trip.service_date.desc(), Trip.departure_at.asc()).offset((page - 1) * size).limit(size).all()
    return PaginatedResponse(items=[_enrich_trip(db, t) for t in items], total=total, page=page, size=size, total_pages=max(1, math.ceil(total / size)))


@router.get("/trips/{trip_id}", response_model=TripDetailOut)
def get_trip(trip_id: int, db: Session = Depends(get_db), _: User = Depends(get_current_user)):
    trip = (
        db.query(Trip)
        .options(
            joinedload(Trip.schedule).joinedload(Schedule.route).joinedload(Route.route_stops).joinedload(RouteStop.stop),
            joinedload(Trip.bus),
            joinedload(Trip.driver),
        )
        .filter(Trip.id == trip_id)
        .first()
    )
    if not trip:
        raise api_error(status.HTTP_404_NOT_FOUND, "NOT_FOUND", "Trip not found")
    return _enrich_trip(db, trip, detail=True)


@router.patch("/trips/{trip_id}/assignment", response_model=TripOut)
def assign_trip(
    trip_id: int,
    payload: TripAssignRequest,
    db: Session = Depends(get_db),
    actor: User = Depends(require_roles(ROLE_ADMIN, ROLE_MANAGER, ROLE_DISPATCHER)),
):
    assign_trip_resources(db, trip_id, payload.bus_id, payload.driver_id, payload.reason, actor)
    trip = db.query(Trip).options(
        joinedload(Trip.schedule).joinedload(Schedule.route).joinedload(Route.route_stops),
        joinedload(Trip.bus),
        joinedload(Trip.driver),
    ).filter(Trip.id == trip_id).first()
    return _enrich_trip(db, trip)


@router.patch("/trips/{trip_id}/status", response_model=TripOut)
def update_trip_status(
    trip_id: int,
    payload: TripStatusRequest,
    db: Session = Depends(get_db),
    actor: User = Depends(require_roles(ROLE_ADMIN, ROLE_MANAGER, ROLE_DISPATCHER)),
):
    change_trip_status(db, trip_id, payload.status, payload.reason, actor)
    trip = db.query(Trip).options(
        joinedload(Trip.schedule).joinedload(Schedule.route).joinedload(Route.route_stops),
        joinedload(Trip.bus),
        joinedload(Trip.driver),
    ).filter(Trip.id == trip_id).first()
    return _enrich_trip(db, trip)


@router.get("/trips/{trip_id}/events", response_model=list[TripEventOut])
def list_trip_events(trip_id: int, db: Session = Depends(get_db), _: User = Depends(get_current_user)):
    if not db.query(Trip).filter(Trip.id == trip_id).first():
        raise api_error(status.HTTP_404_NOT_FOUND, "NOT_FOUND", "Trip not found")
    events = db.query(TripEvent).options(joinedload(TripEvent.actor)).filter(TripEvent.trip_id == trip_id).order_by(TripEvent.timestamp.desc()).all()
    return [
        TripEventOut(
            id=e.id, trip_id=e.trip_id, event_type=e.event_type, delay_category=e.delay_category,
            passenger_count=e.passenger_count, note=e.note, actor_id=e.actor_id,
            actor_name=e.actor.name if e.actor else "System", timestamp=e.timestamp,
        )
        for e in events
    ]


@router.post("/trips/{trip_id}/events", response_model=TripEventOut, status_code=201)
def create_trip_event(
    trip_id: int,
    payload: TripEventCreate,
    db: Session = Depends(get_db),
    actor: User = Depends(require_roles(ROLE_ADMIN, ROLE_MANAGER, ROLE_DISPATCHER, ROLE_DRIVER)),
):
    ev = log_trip_event(db, trip_id, payload, actor)
    return TripEventOut(
        id=ev.id, trip_id=ev.trip_id, event_type=ev.event_type, delay_category=ev.delay_category,
        passenger_count=ev.passenger_count, note=ev.note, actor_id=ev.actor_id,
        actor_name=actor.name, timestamp=ev.timestamp,
    )


@router.get("/trips/{trip_id}/bookings", response_model=list[BookingOut])
def trip_bookings_followup(
    trip_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(require_roles(ROLE_ADMIN, ROLE_MANAGER, ROLE_DISPATCHER, ROLE_CLERK, ROLE_AUDITOR)),
):
    trip = db.query(Trip).options(joinedload(Trip.schedule).joinedload(Schedule.route), joinedload(Trip.bus)).filter(Trip.id == trip_id).first()
    if not trip:
        raise api_error(status.HTTP_404_NOT_FOUND, "NOT_FOUND", "Trip not found")
    rows = db.query(Booking).filter(Booking.trip_id == trip_id).order_by(Booking.created_at.desc()).all()
    return [
        BookingOut(
            id=b.id, booking_ref=b.booking_ref, trip_id=b.trip_id, passenger_user_id=b.passenger_user_id,
            passenger_name=b.passenger_name, contact_demo=b.contact_demo, quantity=b.quantity,
            total_fare=b.total_fare, status=b.status, payment_status_demo=b.payment_status_demo,
            cancellation_reason=b.cancellation_reason, created_at=b.created_at, cancelled_at=b.cancelled_at,
            trip=BookingTripBrief(
                id=trip.id, trip_no=trip.trip_no, service_date=trip.service_date,
                departure_at=trip.departure_at, estimated_arrival_at=trip.estimated_arrival_at,
                status=trip.status, route_name=trip.schedule.route.name,
                origin=trip.schedule.route.origin, destination=trip.schedule.route.destination,
                bus_no=trip.bus.bus_no if trip.bus else None,
            ),
        )
        for b in rows
    ]


@router.get("/public/trips/search", response_model=list[TripDetailOut])
def public_trip_search(
    origin: str | None = None,
    destination: str | None = None,
    service_date: date | None = None,
    db: Session = Depends(get_db),
):
    query = (
        db.query(Trip)
        .join(Trip.schedule)
        .join(Schedule.route)
        .options(
            joinedload(Trip.schedule).joinedload(Schedule.route).joinedload(Route.route_stops).joinedload(RouteStop.stop),
            joinedload(Trip.bus),
            joinedload(Trip.driver),
        )
        .filter(
            Schedule.published.is_(True),
            Schedule.active.is_(True),
            Route.active.is_(True),
            Trip.status.notin_(("Cancelled", "Completed")),
        )
    )
    if service_date:
        query = query.filter(Trip.service_date == service_date)
    if origin:
        term = f"%{origin.strip()}%"
        query = query.filter(Route.origin.ilike(term) | Route.name.ilike(term))
    if destination:
        term = f"%{destination.strip()}%"
        query = query.filter(Route.destination.ilike(term) | Route.name.ilike(term))

    trips = query.order_by(Trip.service_date.asc(), Trip.departure_at.asc()).limit(50).all()
    return [_enrich_trip(db, t, detail=True) for t in trips]


@router.delete("/schedules/{schedule_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_schedule(
    schedule_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(ROLE_ADMIN, ROLE_MANAGER)),
):
    sch = db.query(Schedule).filter(Schedule.id == schedule_id).first()
    if not sch:
        raise api_error(status.HTTP_404_NOT_FOUND, "SCHEDULE_NOT_FOUND", "Schedule not found")
    linked_trips = db.query(Trip).filter(Trip.schedule_id == schedule_id).count()
    if linked_trips > 0:
        raise api_error(
            status.HTTP_400_BAD_REQUEST,
            "SCHEDULE_IN_USE",
            f"Cannot delete schedule #{schedule_id} because {linked_trips} trip(s) depend on it.",
        )
    write_audit(db, current_user.id, "DELETE_SCHEDULE", "Schedule", sch.id, f"Deleted schedule #{sch.id}")
    db.delete(sch)
    db.commit()
    return None


@router.delete("/trips/{trip_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_trip(
    trip_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(ROLE_ADMIN, ROLE_MANAGER, ROLE_DISPATCHER)),
):
    trip = db.query(Trip).filter(Trip.id == trip_id).first()
    if not trip:
        raise api_error(status.HTTP_404_NOT_FOUND, "TRIP_NOT_FOUND", "Trip not found")
    confirmed_bks = db.query(Booking).filter(Booking.trip_id == trip_id, Booking.status == "Confirmed").count()
    if confirmed_bks > 0:
        raise api_error(
            status.HTTP_400_BAD_REQUEST,
            "TRIP_HAS_BOOKINGS",
            f"Cannot delete trip {trip.trip_no} because it has {confirmed_bks} confirmed booking(s).",
        )
    db.query(AssignmentHistory).filter(AssignmentHistory.trip_id == trip_id).delete()
    db.query(TripEvent).filter(TripEvent.trip_id == trip_id).delete()
    db.query(Booking).filter(Booking.trip_id == trip_id).delete()
    write_audit(db, current_user.id, "DELETE_TRIP", "Trip", trip.id, f"Deleted trip {trip.trip_no}")
    db.delete(trip)
    db.commit()
    return None
