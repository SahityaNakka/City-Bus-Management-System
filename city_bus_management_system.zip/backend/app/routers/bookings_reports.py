import math
from collections import defaultdict
from datetime import date

from fastapi import APIRouter, Depends, Header, Query, status
from sqlalchemy.orm import Session, joinedload

from app.auth import (
    ROLE_ADMIN,
    ROLE_AUDITOR,
    ROLE_CLERK,
    ROLE_DISPATCHER,
    ROLE_DRIVER,
    ROLE_MANAGER,
    ROLE_PASSENGER,
    api_error,
    require_roles,
)
from app.database import get_db
from app.models import AuditLog, Booking, Route, RouteStop, Schedule, Trip, TripEvent, User
from app.schemas import (
    BookingCancelRequest,
    BookingCreate,
    BookingOut,
    BookingStatusRequest,
    BookingTripBrief,
    PaginatedResponse,
)
from app.services import (
    build_dashboard_summary,
    cancel_demo_booking,
    create_demo_booking,
    get_booked_seats,
    utc_aware,
    write_audit,
)

router = APIRouter(tags=["Bookings, Dashboard & Reports"])


def _to_booking_out(b: Booking) -> BookingOut:
    brief = None
    if b.trip:
        brief = BookingTripBrief(
            id=b.trip.id, trip_no=b.trip.trip_no, service_date=b.trip.service_date,
            departure_at=b.trip.departure_at, estimated_arrival_at=b.trip.estimated_arrival_at,
            status=b.trip.status, route_name=b.trip.schedule.route.name,
            origin=b.trip.schedule.route.origin, destination=b.trip.schedule.route.destination,
            bus_no=b.trip.bus.bus_no if b.trip.bus else None,
        )
    return BookingOut(
        id=b.id, booking_ref=b.booking_ref, trip_id=b.trip_id, passenger_user_id=b.passenger_user_id,
        passenger_name=b.passenger_name, contact_demo=b.contact_demo, quantity=b.quantity,
        total_fare=b.total_fare, status=b.status, payment_status_demo=b.payment_status_demo,
        cancellation_reason=b.cancellation_reason, created_at=b.created_at, cancelled_at=b.cancelled_at,
        trip=brief,
    )


# --- Bookings ---

@router.post("/bookings", response_model=BookingOut, status_code=201)
def create_booking(
    payload: BookingCreate,
    idempotency_key: str | None = Header(default=None, alias="Idempotency-Key"),
    db: Session = Depends(get_db),
    actor: User = Depends(require_roles(ROLE_PASSENGER, ROLE_CLERK, ROLE_ADMIN, ROLE_MANAGER)),
):
    key = idempotency_key or payload.idempotency_key
    booking = create_demo_booking(
        db, payload.trip_id, payload.passenger_name, payload.contact_demo, payload.quantity, key, actor
    )
    booking = (
        db.query(Booking)
        .options(joinedload(Booking.trip).joinedload(Trip.schedule).joinedload(Schedule.route), joinedload(Booking.trip).joinedload(Trip.bus))
        .filter(Booking.id == booking.id)
        .first()
    )
    return _to_booking_out(booking)


@router.get("/bookings/me", response_model=PaginatedResponse[BookingOut])
def my_bookings(
    page: int = Query(1, ge=1),
    size: int = Query(50, ge=1, le=200),
    db: Session = Depends(get_db),
    user: User = Depends(require_roles(ROLE_PASSENGER, ROLE_CLERK, ROLE_ADMIN, ROLE_MANAGER)),
):
    query = (
        db.query(Booking)
        .options(joinedload(Booking.trip).joinedload(Trip.schedule).joinedload(Schedule.route), joinedload(Booking.trip).joinedload(Trip.bus))
        .filter(Booking.passenger_user_id == user.id)
    )
    total = query.count()
    items = query.order_by(Booking.created_at.desc()).offset((page - 1) * size).limit(size).all()
    return PaginatedResponse(items=[_to_booking_out(b) for b in items], total=total, page=page, size=size, total_pages=max(1, math.ceil(total / size)))


@router.get("/bookings", response_model=PaginatedResponse[BookingOut])
def list_bookings(
    search: str | None = None,
    status_filter: str | None = Query(None, alias="status"),
    page: int = Query(1, ge=1),
    size: int = Query(50, ge=1, le=200),
    db: Session = Depends(get_db),
    _: User = Depends(require_roles(ROLE_ADMIN, ROLE_MANAGER, ROLE_CLERK, ROLE_DISPATCHER, ROLE_AUDITOR)),
):
    query = db.query(Booking).options(
        joinedload(Booking.trip).joinedload(Trip.schedule).joinedload(Schedule.route),
        joinedload(Booking.trip).joinedload(Trip.bus),
    )
    if search:
        term = f"%{search.strip()}%"
        query = query.filter(Booking.booking_ref.ilike(term) | Booking.passenger_name.ilike(term) | Booking.contact_demo.ilike(term))
    if status_filter:
        query = query.filter(Booking.status == status_filter)
    total = query.count()
    items = query.order_by(Booking.created_at.desc()).offset((page - 1) * size).limit(size).all()
    return PaginatedResponse(items=[_to_booking_out(b) for b in items], total=total, page=page, size=size, total_pages=max(1, math.ceil(total / size)))


@router.patch("/bookings/{booking_id}/cancel", response_model=BookingOut)
def cancel_booking(
    booking_id: int,
    payload: BookingCancelRequest,
    db: Session = Depends(get_db),
    actor: User = Depends(require_roles(ROLE_PASSENGER, ROLE_CLERK, ROLE_ADMIN, ROLE_MANAGER)),
):
    booking = cancel_demo_booking(db, booking_id, payload.reason, actor)
    booking = (
        db.query(Booking)
        .options(joinedload(Booking.trip).joinedload(Trip.schedule).joinedload(Schedule.route), joinedload(Booking.trip).joinedload(Trip.bus))
        .filter(Booking.id == booking.id)
        .first()
    )
    return _to_booking_out(booking)


@router.patch("/bookings/{booking_id}/status", response_model=BookingOut)
def update_booking_status(
    booking_id: int,
    payload: BookingStatusRequest,
    db: Session = Depends(get_db),
    actor: User = Depends(require_roles(ROLE_CLERK, ROLE_ADMIN, ROLE_MANAGER, ROLE_DISPATCHER)),
):
    booking = db.query(Booking).filter(Booking.id == booking_id).first()
    if not booking:
        raise api_error(status.HTTP_404_NOT_FOUND, "NOT_FOUND", "Booking not found")
    if booking.status == "Cancelled":
        raise api_error(status.HTTP_409_CONFLICT, "INVALID_BOOKING_STATE", "Cancelled bookings cannot be modified")
    booking.status = payload.status
    write_audit(db, actor.id, "UPDATE_BOOKING_STATUS", "Booking", booking.id, payload.reason)
    db.commit()
    booking = (
        db.query(Booking)
        .options(joinedload(Booking.trip).joinedload(Trip.schedule).joinedload(Schedule.route), joinedload(Booking.trip).joinedload(Trip.bus))
        .filter(Booking.id == booking.id)
        .first()
    )
    return _to_booking_out(booking)


@router.delete("/bookings/{booking_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_booking(
    booking_id: int,
    db: Session = Depends(get_db),
    actor: User = Depends(require_roles(ROLE_ADMIN, ROLE_MANAGER, ROLE_CLERK)),
):
    bk = db.query(Booking).filter(Booking.id == booking_id).first()
    if not bk:
        raise api_error(status.HTTP_404_NOT_FOUND, "BOOKING_NOT_FOUND", "Booking not found")
    if bk.status == "Confirmed":
        trip = db.query(Trip).filter(Trip.id == bk.trip_id).first()
        if trip and trip.passenger_count >= bk.quantity:
            trip.passenger_count -= bk.quantity
    write_audit(db, actor.id, "DELETE_BOOKING", "Booking", bk.id, f"Deleted booking {bk.booking_ref}")
    db.delete(bk)
    db.commit()
    return None


# --- Dashboard & Reports ---

@router.get("/dashboard/summary")
def dashboard_summary(
    target_date: date | None = None,
    db: Session = Depends(get_db),
    _: User = Depends(require_roles(ROLE_ADMIN, ROLE_MANAGER, ROLE_DISPATCHER, ROLE_DRIVER, ROLE_CLERK, ROLE_AUDITOR)),
):
    return build_dashboard_summary(db, target_date or date.today())


@router.get("/reports/trips")
def trip_operations_report(
    service_date: date | None = None,
    route_id: int | None = None,
    bus_id: int | None = None,
    driver_id: int | None = None,
    status_filter: str | None = Query(None, alias="status"),
    db: Session = Depends(get_db),
    _: User = Depends(require_roles(ROLE_ADMIN, ROLE_MANAGER, ROLE_DISPATCHER, ROLE_AUDITOR)),
):
    query = db.query(Trip).options(
        joinedload(Trip.schedule).joinedload(Schedule.route), joinedload(Trip.bus), joinedload(Trip.driver), joinedload(Trip.events)
    )
    if service_date:
        query = query.filter(Trip.service_date == service_date)
    if route_id:
        query = query.join(Trip.schedule).filter(Schedule.route_id == route_id)
    if bus_id:
        query = query.filter(Trip.bus_id == bus_id)
    if driver_id:
        query = query.filter(Trip.driver_id == driver_id)
    if status_filter:
        query = query.filter(Trip.status == status_filter)
    trips = query.order_by(Trip.service_date.desc(), Trip.departure_at.asc()).all()
    return [
        {
            "trip_no": t.trip_no,
            "service_date": t.service_date,
            "route_code": t.schedule.route.route_code,
            "route_name": t.schedule.route.name,
            "bus_no": t.bus.bus_no if t.bus else None,
            "driver_name": t.driver.name if t.driver else None,
            "status": t.status,
            "departure_at": t.departure_at,
            "actual_departure_at": t.actual_departure_at,
            "actual_arrival_at": t.actual_arrival_at,
            "passenger_count": t.passenger_count,
            "booked_seats": get_booked_seats(db, t.id),
            "delay_category": next((e.delay_category for e in t.events if e.delay_category), None),
        }
        for t in trips
    ]


@router.get("/reports/route-schedules")
def route_schedule_report(
    route_id: int | None = None,
    service_date: date | None = None,
    active: bool | None = None,
    db: Session = Depends(get_db),
    _: User = Depends(require_roles(ROLE_ADMIN, ROLE_MANAGER, ROLE_DISPATCHER, ROLE_AUDITOR)),
):
    query = db.query(Schedule).options(joinedload(Schedule.route).joinedload(Route.route_stops).joinedload(RouteStop.stop))
    if route_id:
        query = query.filter(Schedule.route_id == route_id)
    if active is not None:
        query = query.filter(Schedule.active.is_(active))
    schedules = query.order_by(Schedule.route_id.asc(), Schedule.departure_time.asc()).all()
    trip_counts = {}
    if service_date:
        rows = db.query(Trip.schedule_id).filter(Trip.service_date == service_date).all()
        for (sid,) in rows:
            trip_counts[sid] = trip_counts.get(sid, 0) + 1
    return [
        {
            "route_code": s.route.route_code,
            "route_name": s.route.name,
            "stop_sequence": " -> ".join(f"{rs.sequence}. {rs.stop.name} (+{rs.estimated_offset_min}m)" for rs in sorted(s.route.route_stops, key=lambda x: x.sequence)) or "No stops",
            "departure_time": s.departure_time.strftime("%H:%M"),
            "duration_min": s.duration_min,
            "fare": float(s.fare),
            "published": s.published,
            "active": s.active and s.route.active,
            "trips_on_date": trip_counts.get(s.id, 0) if service_date else None,
        }
        for s in schedules
    ]


@router.get("/reports/bookings")
def booking_summary_report(
    date_from: date | None = None,
    date_to: date | None = None,
    route_id: int | None = None,
    trip_id: int | None = None,
    status_filter: str | None = Query(None, alias="status"),
    db: Session = Depends(get_db),
    _: User = Depends(require_roles(ROLE_ADMIN, ROLE_MANAGER, ROLE_CLERK, ROLE_AUDITOR)),
):
    query = db.query(Booking).options(joinedload(Booking.trip).joinedload(Trip.schedule).joinedload(Schedule.route))
    if date_from or date_to:
        query = query.join(Booking.trip)
        if date_from:
            query = query.filter(Trip.service_date >= date_from)
        if date_to:
            query = query.filter(Trip.service_date <= date_to)
    if trip_id:
        query = query.filter(Booking.trip_id == trip_id)
    if status_filter:
        query = query.filter(Booking.status == status_filter)
    rows = query.order_by(Booking.created_at.desc()).all()
    return [
        {
            "booking_ref": b.booking_ref,
            "trip_no": b.trip.trip_no,
            "route_name": b.trip.schedule.route.name,
            "service_date": b.trip.service_date,
            "passenger_name": b.passenger_name,
            "quantity": b.quantity,
            "total_fare": float(b.total_fare),
            "status": b.status,
            "payment_status_demo": b.payment_status_demo,
        }
        for b in rows
        if not route_id or b.trip.schedule.route_id == route_id
    ]


@router.get("/reports/bus-utilization")
def bus_utilization_report(
    service_date: date | None = None,
    bus_id: int | None = None,
    db: Session = Depends(get_db),
    _: User = Depends(require_roles(ROLE_ADMIN, ROLE_MANAGER, ROLE_DISPATCHER, ROLE_AUDITOR)),
):
    query = db.query(Trip).options(joinedload(Trip.bus)).filter(Trip.bus_id.isnot(None))
    if service_date:
        query = query.filter(Trip.service_date == service_date)
    if bus_id:
        query = query.filter(Trip.bus_id == bus_id)
    grouped = defaultdict(list)
    for t in query.all():
        grouped[(t.bus_id, t.service_date)].append(t)

    result = []
    for (_, svc_date), group in grouped.items():
        bus = group[0].bus
        booked = sum(get_booked_seats(db, t.id) for t in group)
        carried = sum(t.passenger_count for t in group)
        cap = bus.capacity * len(group)
        used = carried if carried > 0 else booked
        result.append({
            "bus_no": bus.bus_no,
            "bus_type": bus.bus_type,
            "capacity": bus.capacity,
            "service_date": svc_date,
            "trips_assigned": len(group),
            "booked_seats": booked,
            "total_passengers_carried": carried,
            "utilization_percent": round((used / cap) * 100, 1) if cap > 0 else 0.0,
        })
    return result


@router.get("/reports/driver-assignments")
def driver_assignment_report(
    service_date: date | None = None,
    driver_id: int | None = None,
    status_filter: str | None = Query(None, alias="status"),
    db: Session = Depends(get_db),
    _: User = Depends(require_roles(ROLE_ADMIN, ROLE_MANAGER, ROLE_DISPATCHER, ROLE_AUDITOR)),
):
    query = db.query(Trip).options(joinedload(Trip.driver)).filter(Trip.driver_id.isnot(None))
    if service_date:
        query = query.filter(Trip.service_date == service_date)
    if driver_id:
        query = query.filter(Trip.driver_id == driver_id)
    grouped = defaultdict(list)
    for t in query.all():
        if status_filter and t.driver.status != status_filter:
            continue
        grouped[(t.driver_id, t.service_date)].append(t)

    return [
        {
            "employee_code": group[0].driver.employee_code,
            "driver_name": group[0].driver.name,
            "service_date": svc_date,
            "trips_assigned": len(group),
            "trip_numbers": ", ".join(t.trip_no for t in group),
            "driver_status": group[0].driver.status,
        }
        for (_, svc_date), group in grouped.items()
    ]


@router.get("/reports/cancellations")
def cancellation_report(
    route_id: int | None = None,
    date_from: date | None = None,
    date_to: date | None = None,
    db: Session = Depends(get_db),
    _: User = Depends(require_roles(ROLE_ADMIN, ROLE_MANAGER, ROLE_DISPATCHER, ROLE_CLERK, ROLE_AUDITOR)),
):
    items = []
    cancelled_bookings = (
        db.query(Booking)
        .options(joinedload(Booking.trip).joinedload(Trip.schedule).joinedload(Schedule.route), joinedload(Booking.canceller))
        .filter(Booking.status == "Cancelled")
        .all()
    )
    for b in cancelled_bookings:
        if route_id and b.trip.schedule.route_id != route_id:
            continue
        dt = (b.cancelled_at or b.created_at).date()
        if date_from and dt < date_from:
            continue
        if date_to and dt > date_to:
            continue
        items.append({
            "cancellation_date": b.cancelled_at or b.created_at,
            "booking_ref": b.booking_ref,
            "trip_no": b.trip.trip_no,
            "route_name": b.trip.schedule.route.name,
            "reason": b.cancellation_reason or "No reason recorded",
            "cancelled_by_name": b.canceller.name if b.canceller else b.passenger_name,
            "status": "Booking Cancelled",
        })
    cancelled_trips = (
        db.query(Trip)
        .options(joinedload(Trip.schedule).joinedload(Schedule.route), joinedload(Trip.events).joinedload(TripEvent.actor))
        .filter(Trip.status == "Cancelled")
        .all()
    )
    for t in cancelled_trips:
        if route_id and t.schedule.route_id != route_id:
            continue
        ev = next((e for e in t.events if e.event_type == "status_change" and "Cancelled" in (e.note or "")), None)
        cancel_dt = ev.timestamp if ev else t.created_at
        if date_from and cancel_dt.date() < date_from:
            continue
        if date_to and cancel_dt.date() > date_to:
            continue
        items.append({
            "cancellation_date": cancel_dt,
            "booking_ref": None,
            "trip_no": t.trip_no,
            "route_name": t.schedule.route.name,
            "reason": ev.note if ev and ev.note else "Trip cancelled",
            "cancelled_by_name": ev.actor.name if ev and ev.actor else "Operations",
            "status": "Trip Cancelled",
        })
    return sorted(items, key=lambda x: utc_aware(x["cancellation_date"]), reverse=True)


@router.get("/audit-logs")
def list_audit_logs(
    action: str | None = None,
    entity: str | None = None,
    page: int = Query(1, ge=1),
    size: int = Query(50, ge=1, le=200),
    db: Session = Depends(get_db),
    _: User = Depends(require_roles(ROLE_ADMIN, ROLE_MANAGER, ROLE_AUDITOR)),
):
    query = db.query(AuditLog).options(joinedload(AuditLog.actor))
    if action:
        query = query.filter(AuditLog.action.ilike(f"%{action.strip()}%"))
    if entity:
        query = query.filter(AuditLog.entity.ilike(f"%{entity.strip()}%"))
    total = query.count()
    rows = query.order_by(AuditLog.created_at.desc()).offset((page - 1) * size).limit(size).all()
    return {
        "items": [
            {
                "id": r.id,
                "actor_name": r.actor.name if r.actor else "System",
                "action": r.action,
                "entity": r.entity,
                "entity_id": r.entity_id,
                "reason": r.reason,
                "created_at": r.created_at,
            }
            for r in rows
        ],
        "total": total,
        "page": page,
        "size": size,
        "total_pages": max(1, math.ceil(total / size)),
    }
