import base64
import hashlib
import hmac
import secrets
from datetime import datetime, timedelta, timezone

import jwt
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session, joinedload

from app.config import settings
from app.database import get_db
from app.models import User

# All 7 Project 22 Roles
ROLE_ADMIN = "Administrator"
ROLE_MANAGER = "Transport Manager"
ROLE_DISPATCHER = "Dispatcher"
ROLE_DRIVER = "Driver"
ROLE_CLERK = "Booking Clerk"
ROLE_PASSENGER = "Passenger"
ROLE_AUDITOR = "Auditor/Viewer"

bearer_scheme = HTTPBearer(auto_error=False)


def api_error(status_code: int, code: str, message: str, details: dict | None = None) -> HTTPException:
    return HTTPException(
        status_code=status_code,
        detail={"code": code, "message": message, "details": details or {}},
    )


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 210_000)
    return f"pbkdf2_sha256$210000${base64.b64encode(salt).decode()}${base64.b64encode(dk).decode()}"


def verify_password(plain_password: str, stored_hash: str) -> bool:
    try:
        alg, iters, salt_b64, dk_b64 = stored_hash.split("$", 3)
        if alg != "pbkdf2_sha256":
            return False
        actual = hashlib.pbkdf2_hmac(
            "sha256", plain_password.encode("utf-8"), base64.b64decode(salt_b64), int(iters)
        )
        return hmac.compare_digest(actual, base64.b64decode(dk_b64))
    except Exception:
        return False


def create_access_token(user_id: int, role_name: str) -> str:
    now = datetime.now(timezone.utc)
    payload = {
        "sub": str(user_id),
        "role": role_name,
        "iat": int(now.timestamp()),
        "exp": int((now + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)).timestamp()),
    }
    return jwt.encode(payload, settings.SECRET_KEY, algorithm=settings.ALGORITHM)


def get_current_user(
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme),
    db: Session = Depends(get_db),
) -> User:
    if not credentials or not credentials.credentials:
        raise api_error(status.HTTP_401_UNAUTHORIZED, "UNAUTHORIZED", "Authentication token required")
    try:
        payload = jwt.decode(credentials.credentials, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        user_id = int(payload["sub"])
    except (jwt.PyJWTError, KeyError, ValueError):
        raise api_error(status.HTTP_401_UNAUTHORIZED, "UNAUTHORIZED", "Invalid or expired token")

    user = (
        db.query(User)
        .options(joinedload(User.role), joinedload(User.driver_profile))
        .filter(User.id == user_id)
        .first()
    )
    if not user or not user.active:
        raise api_error(status.HTTP_401_UNAUTHORIZED, "UNAUTHORIZED", "User is inactive or missing")
    return user


def require_roles(*allowed_roles: str):
    def check_role(current_user: User = Depends(get_current_user)) -> User:
        role_name = current_user.role.name if current_user.role else ""
        if role_name not in allowed_roles:
            raise api_error(
                status.HTTP_403_FORBIDDEN,
                "FORBIDDEN",
                f"Role '{role_name}' is not allowed to perform this action",
            )
        return current_user

    return check_role
