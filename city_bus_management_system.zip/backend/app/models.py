from datetime import date, datetime, time, timezone
from decimal import Decimal

from sqlalchemy import (
    Boolean,
    CheckConstraint,
    Date,
    DateTime,
    ForeignKey,
    Integer,
    Numeric,
    String,
    Text,
    Time,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database import Base


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


# ==============================================================================
# SECTION 1: ACCESS CONTROL & AUTHENTICATION
# ==============================================================================


class Role(Base):
    __tablename__ = "roles"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)
    description: Mapped[str | None] = mapped_column(String(255))
    users: Mapped[list["User"]] = relationship(back_populates="role")


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    email: Mapped[str] = mapped_column(String(180), unique=True, nullable=False, index=True)
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    role_id: Mapped[int] = mapped_column(ForeignKey("roles.id"), nullable=False)
    contact_demo: Mapped[str | None] = mapped_column(String(120))
    active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)

    role: Mapped["Role"] = relationship(back_populates="users")
    driver_profile: Mapped["Driver | None"] = relationship(back_populates="user", uselist=False)


# ==============================================================================
# SECTION 2: FLEET ASSETS & ROUTES
# ==============================================================================


class Bus(Base):
    __tablename__ = "buses"
    __table_args__ = (CheckConstraint("capacity > 0", name="ck_bus_capacity_positive"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    bus_no: Mapped[str] = mapped_column(String(40), unique=True, nullable=False)
    registration_demo: Mapped[str] = mapped_column(String(60), nullable=False)
    capacity: Mapped[int] = mapped_column(Integer, nullable=False)
    bus_type: Mapped[str] = mapped_column(String(60), nullable=False)
    status: Mapped[str] = mapped_column(String(32), default="Available", nullable=False)
    active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)


class Driver(Base):
    __tablename__ = "drivers"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), unique=True)
    employee_code: Mapped[str] = mapped_column(String(40), unique=True, nullable=False)
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    license_demo: Mapped[str] = mapped_column(String(60), nullable=False)
    contact_demo: Mapped[str] = mapped_column(String(80), nullable=False)
    status: Mapped[str] = mapped_column(String(32), default="Available", nullable=False)
    active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)

    user: Mapped["User | None"] = relationship(back_populates="driver_profile")


class Route(Base):
    __tablename__ = "routes"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    route_code: Mapped[str] = mapped_column(String(40), unique=True, nullable=False)
    name: Mapped[str] = mapped_column(String(150), nullable=False)
    origin: Mapped[str] = mapped_column(String(120), nullable=False)
    destination: Mapped[str] = mapped_column(String(120), nullable=False)
    distance_note: Mapped[str | None] = mapped_column(String(120))
    active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)

    route_stops: Mapped[list["RouteStop"]] = relationship(
        back_populates="route", cascade="all, delete-orphan", order_by="RouteStop.sequence"
    )

    @property
    def stops_count(self) -> int:
        return len(self.route_stops)


class Stop(Base):
    __tablename__ = "stops"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    stop_code: Mapped[str] = mapped_column(String(40), unique=True, nullable=False)
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    area: Mapped[str] = mapped_column(String(120), nullable=False)
    active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)


class RouteStop(Base):
    __tablename__ = "route_stops"
    __table_args__ = (
        UniqueConstraint("route_id", "sequence", name="uq_route_stop_sequence"),
        CheckConstraint("sequence >= 1", name="ck_route_stop_seq_positive"),
        CheckConstraint("estimated_offset_min >= 0", name="ck_route_stop_offset_nonneg"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    route_id: Mapped[int] = mapped_column(ForeignKey("routes.id", ondelete="CASCADE"), nullable=False)
    stop_id: Mapped[int] = mapped_column(ForeignKey("stops.id"), nullable=False)
    sequence: Mapped[int] = mapped_column(Integer, nullable=False)
    estimated_offset_min: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    route: Mapped["Route"] = relationship(back_populates="route_stops")
    stop: Mapped["Stop"] = relationship()


# ==============================================================================
# SECTION 3: SCHEDULES, FARES & TRIPS
# ==============================================================================


class Schedule(Base):
    __tablename__ = "schedules"
    __table_args__ = (
        CheckConstraint("duration_min > 0", name="ck_schedule_duration_positive"),
        CheckConstraint("fare >= 0", name="ck_schedule_fare_nonneg"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    route_id: Mapped[int] = mapped_column(ForeignKey("routes.id"), nullable=False)
    departure_time: Mapped[time] = mapped_column(Time, nullable=False)
    duration_min: Mapped[int] = mapped_column(Integer, nullable=False)
    fare: Mapped[Decimal] = mapped_column(Numeric(10, 2), nullable=False)
    service_rule: Mapped[str] = mapped_column(String(120), default="Daily", nullable=False)
    published: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)

    route: Mapped["Route"] = relationship()


class FareRule(Base):
    __tablename__ = "fare_rules"
    __table_args__ = (CheckConstraint("fare_amount >= 0", name="ck_fare_rule_nonneg"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    route_id: Mapped[int | None] = mapped_column(ForeignKey("routes.id"))
    schedule_id: Mapped[int | None] = mapped_column(ForeignKey("schedules.id"))
    fare_amount: Mapped[Decimal] = mapped_column(Numeric(10, 2), nullable=False)
    effective_date: Mapped[date] = mapped_column(Date, nullable=False)
    active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)


class Trip(Base):
    __tablename__ = "trips"
    __table_args__ = (
        UniqueConstraint("schedule_id", "service_date", name="uq_trip_schedule_date"),
        CheckConstraint("passenger_count >= 0", name="ck_trip_passenger_nonneg"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    trip_no: Mapped[str] = mapped_column(String(48), unique=True, nullable=False)
    schedule_id: Mapped[int] = mapped_column(ForeignKey("schedules.id"), nullable=False)
    service_date: Mapped[date] = mapped_column(Date, nullable=False, index=True)
    departure_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    estimated_arrival_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    actual_departure_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    actual_arrival_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    bus_id: Mapped[int | None] = mapped_column(ForeignKey("buses.id"))
    driver_id: Mapped[int | None] = mapped_column(ForeignKey("drivers.id"))
    status: Mapped[str] = mapped_column(String(32), default="Scheduled", nullable=False)
    passenger_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    fare_snapshot: Mapped[Decimal] = mapped_column(Numeric(10, 2), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)

    schedule: Mapped["Schedule"] = relationship()
    bus: Mapped["Bus | None"] = relationship()
    driver: Mapped["Driver | None"] = relationship()
    events: Mapped[list["TripEvent"]] = relationship(
        back_populates="trip", order_by="TripEvent.timestamp.desc()"
    )


class AssignmentHistory(Base):
    __tablename__ = "assignment_history"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    trip_id: Mapped[int] = mapped_column(ForeignKey("trips.id", ondelete="CASCADE"), nullable=False)
    bus_id: Mapped[int | None] = mapped_column(ForeignKey("buses.id"))
    driver_id: Mapped[int | None] = mapped_column(ForeignKey("drivers.id"))
    changed_by: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    reason: Mapped[str] = mapped_column(String(255), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)

    bus: Mapped["Bus | None"] = relationship()
    driver: Mapped["Driver | None"] = relationship()
    actor: Mapped["User"] = relationship()


class TripEvent(Base):
    __tablename__ = "trip_events"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    trip_id: Mapped[int] = mapped_column(ForeignKey("trips.id", ondelete="CASCADE"), nullable=False)
    event_type: Mapped[str] = mapped_column(String(40), nullable=False)
    delay_category: Mapped[str | None] = mapped_column(String(60))
    passenger_count: Mapped[int | None] = mapped_column(Integer)
    note: Mapped[str | None] = mapped_column(Text)
    actor_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    timestamp: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)

    trip: Mapped["Trip"] = relationship(back_populates="events")
    actor: Mapped["User"] = relationship()


# ==============================================================================
# SECTION 4: BOOKINGS, AUDIT LOGS & NOTIFICATIONS
# ==============================================================================


class Booking(Base):
    __tablename__ = "bookings"
    __table_args__ = (CheckConstraint("quantity > 0", name="ck_booking_qty_positive"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    booking_ref: Mapped[str] = mapped_column(String(40), unique=True, nullable=False)
    trip_id: Mapped[int] = mapped_column(ForeignKey("trips.id"), nullable=False)
    passenger_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    passenger_name: Mapped[str] = mapped_column(String(120), nullable=False)
    contact_demo: Mapped[str] = mapped_column(String(120), nullable=False)
    quantity: Mapped[int] = mapped_column(Integer, nullable=False)
    total_fare: Mapped[Decimal] = mapped_column(Numeric(10, 2), nullable=False)
    status: Mapped[str] = mapped_column(String(32), default="Confirmed", nullable=False)
    payment_status_demo: Mapped[str] = mapped_column(String(32), default="Demo Paid", nullable=False)
    idempotency_key: Mapped[str | None] = mapped_column(String(120), unique=True)
    cancellation_reason: Mapped[str | None] = mapped_column(String(255))
    cancelled_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)
    cancelled_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    trip: Mapped["Trip"] = relationship()
    canceller: Mapped["User | None"] = relationship(foreign_keys=[cancelled_by])


class AuditLog(Base):
    __tablename__ = "audit_logs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    actor_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    action: Mapped[str] = mapped_column(String(64), nullable=False)
    entity: Mapped[str] = mapped_column(String(64), nullable=False)
    entity_id: Mapped[str] = mapped_column(String(64), nullable=False)
    reason: Mapped[str | None] = mapped_column(String(255))
    details: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)

    actor: Mapped["User | None"] = relationship()


class Notification(Base):
    __tablename__ = "notifications"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
    )
    message: Mapped[str] = mapped_column(String(255), nullable=False)
    is_read: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)

    user: Mapped["User"] = relationship()
