import json
import secrets
from collections import defaultdict
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal

from fastapi import status
from sqlalchemy import func, text
from sqlalchemy.orm import Session, joinedload

from app.auth import ROLE_DRIVER, ROLE_PASSENGER, api_error
from app.config import settings
from app.models import (
    AssignmentHistory,
    AuditLog,
    Booking,
    Bus,
    Driver,
    FareRule,
    Notification,
    Route,
    RouteStop,
    Schedule,
    Stop,
    Trip,
    TripEvent,
    User,
)
from app.schemas import RouteStopIn, TripEventCreate

ACTIVE_TRIP_STATUSES = ("Scheduled", "Assigned", "Boarding", "In Progress", "Delayed")

ALLOWED_TRIP_TRANSITIONS: dict[str, set[str]] = {
    "Scheduled": {"Assigned", "Cancelled"},
    "Assigned": {"Boarding", "In Progress", "Delayed", "Cancelled"},
    "Boarding": {"In Progress", "Delayed", "Cancelled"},
    "In Progress": {"Delayed", "Completed", "Cancelled"},
    "Delayed": {"In Progress", "Completed", "Cancelled"},
    "Completed": set(),
    "Cancelled": set(),
}


def utc_aware(dt: datetime) -> datetime:
    return dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt


def write_audit(
    db: Session,
    actor_id: int | None,
    action: str,
    entity: str,
    entity_id: str | int,
    reason: str | None = None,
    details: dict | None = None,
) -> None:
    db.add(
        AuditLog(
            actor_id=actor_id,
            action=action,
            entity=entity,
            entity_id=str(entity_id),
            reason=reason,
            details=json.dumps(details, default=str) if details else None,
        )
    )


def create_notification(db: Session, user_id: int | None, message: str) -> None:
    if not user_id:
        return
    db.add(Notification(user_id=user_id, message=message[:255]))


# ==============================================================================
# SECTION 2: ROUTE & STOP VALIDATION
# ==============================================================================

def validate_route_for_publishing(db: Session, route_id: int) -> Route:
    route = (
        db.query(Route)
        .options(joinedload(Route.route_stops).joinedload(RouteStop.stop))
        .filter(Route.id == route_id)
        .first()
    )
    if not route:
        raise api_error(status.HTTP_404_NOT_FOUND, "NOT_FOUND", "Route not found")
    if not route.active:
        raise api_error(status.HTTP_400_BAD_REQUEST, "INACTIVE_ROUTE", "Inactive route cannot be published")

    inactive_stops = [rs.stop.stop_code for rs in route.route_stops if rs.stop and not rs.stop.active]
    if inactive_stops:
        raise api_error(
            status.HTTP_400_BAD_REQUEST,
            "INACTIVE_STOP_ON_ROUTE",
            f"Route contains inactive stop(s): {', '.join(inactive_stops)}",
        )

    distinct_stops = {rs.stop_id for rs in route.route_stops if rs.stop and rs.stop.active}
    if len(distinct_stops) < 2:
        raise api_error(
            status.HTTP_400_BAD_REQUEST,
            "INSUFFICIENT_ROUTE_STOPS",
            "Route must have at least two distinct active stops before publishing",
        )
    return route


def update_route_stops(db: Session, route_id: int, items: list[RouteStopIn], actor_id: int) -> Route:
    route = db.query(Route).filter(Route.id == route_id).first()
    if not route:
        raise api_error(status.HTTP_404_NOT_FOUND, "NOT_FOUND", "Route not found")
    if not items:
        raise api_error(status.HTTP_400_BAD_REQUEST, "EMPTY_STOPS", "At least one stop is required")

    sequences = [item.sequence for item in items]
    if len(sequences) != len(set(sequences)):
        raise api_error(
            status.HTTP_409_CONFLICT,
            "DUPLICATE_SEQUENCE",
            "Stop sequence numbers must be unique within a route",
        )

    stops_by_id = {
        s.id: s for s in db.query(Stop).filter(Stop.id.in_([i.stop_id for i in items])).all()
    }
    for item in items:
        stop = stops_by_id.get(item.stop_id)
        if not stop:
            raise api_error(status.HTTP_404_NOT_FOUND, "NOT_FOUND", f"Stop {item.stop_id} not found")
        if not stop.active:
            raise api_error(
                status.HTTP_400_BAD_REQUEST,
                "INACTIVE_STOP",
                f"Stop '{stop.stop_code}' is inactive and cannot be added",
            )

    db.query(RouteStop).filter(RouteStop.route_id == route_id).delete()
    db.flush()
    for item in sorted(items, key=lambda x: x.sequence):
        db.add(
            RouteStop(
                route_id=route_id,
                stop_id=item.stop_id,
                sequence=item.sequence,
                estimated_offset_min=item.estimated_offset_min,
            )
        )

    write_audit(db, actor_id, "UPDATE_ROUTE_STOPS", "Route", route_id, "Updated ordered stops")
    db.commit()
    return (
        db.query(Route)
        .options(joinedload(Route.route_stops).joinedload(RouteStop.stop))
        .filter(Route.id == route_id)
        .first()
    )


# ==============================================================================
# SECTION 3: SCHEDULE, TRIP ASSIGNMENT & OPERATIONS
# ==============================================================================

def generate_trips(db: Session, schedule_id: int, dates: list[date], actor: User) -> dict:
    schedule = db.query(Schedule).filter(Schedule.id == schedule_id).first()
    if not schedule:
        raise api_error(status.HTTP_404_NOT_FOUND, "NOT_FOUND", "Schedule not found")
    if not schedule.active or not schedule.published:
        raise api_error(
            status.HTTP_400_BAD_REQUEST,
            "UNPUBLISHED_SCHEDULE",
            "Schedule must be active and published before generating trips",
        )

    route = validate_route_for_publishing(db, schedule.route_id)
    created, skipped = [], []

    for svc_date in sorted(set(dates)):
        exists = (
            db.query(Trip)
            .filter(Trip.schedule_id == schedule.id, Trip.service_date == svc_date)
            .first()
        )
        if exists:
            skipped.append(svc_date.isoformat())
            continue

        fare_rule = (
            db.query(FareRule)
            .filter(
                FareRule.active.is_(True),
                FareRule.effective_date <= svc_date,
                (FareRule.schedule_id == schedule.id) | (FareRule.route_id == route.id),
            )
            .order_by(FareRule.schedule_id.desc(), FareRule.effective_date.desc())
            .first()
        )
        dep_at = datetime.combine(svc_date, schedule.departure_time, tzinfo=timezone.utc)
        trip = Trip(
            trip_no=f"TR-{route.route_code}-{svc_date.strftime('%Y%m%d')}-S{schedule.id}",
            schedule_id=schedule.id,
            service_date=svc_date,
            departure_at=dep_at,
            estimated_arrival_at=dep_at + timedelta(minutes=schedule.duration_min),
            status="Scheduled",
            fare_snapshot=fare_rule.fare_amount if fare_rule else schedule.fare,
        )
        db.add(trip)
        db.flush()
        created.append(trip.trip_no)

    write_audit(db, actor.id, "GENERATE_TRIPS", "Schedule", schedule.id, f"Generated {len(created)} trip(s)")
    db.commit()
    return {"created_count": len(created), "skipped_dates": skipped, "trip_numbers": created}


def assign_trip_resources(
    db: Session, trip_id: int, bus_id: int, driver_id: int, reason: str, actor: User
) -> Trip:
    trip = db.query(Trip).filter(Trip.id == trip_id).first()
    if not trip:
        raise api_error(status.HTTP_404_NOT_FOUND, "NOT_FOUND", "Trip not found")
    if trip.status in ("Completed", "Cancelled"):
        raise api_error(
            status.HTTP_409_CONFLICT, "INVALID_TRIP_STATE", f"Cannot assign a {trip.status} trip"
        )

    bus = db.query(Bus).filter(Bus.id == bus_id).first()
    if not bus:
        raise api_error(status.HTTP_404_NOT_FOUND, "NOT_FOUND", "Bus not found")
    if not bus.active or bus.status in ("Maintenance", "Inactive"):
        raise api_error(
            status.HTTP_400_BAD_REQUEST, "INELIGIBLE_BUS", f"Bus '{bus.bus_no}' is {bus.status}"
        )

    driver = db.query(Driver).filter(Driver.id == driver_id).first()
    if not driver:
        raise api_error(status.HTTP_404_NOT_FOUND, "NOT_FOUND", "Driver not found")
    if not driver.active or driver.status in ("On Leave", "Inactive"):
        raise api_error(
            status.HTTP_400_BAD_REQUEST, "INELIGIBLE_DRIVER", f"Driver '{driver.name}' is {driver.status}"
        )

    booked = get_booked_seats(db, trip.id)
    if booked > bus.capacity:
        raise api_error(
            status.HTTP_409_CONFLICT,
            "CAPACITY_TOO_SMALL",
            f"Bus capacity ({bus.capacity}) is below booked seats ({booked})",
        )

    # Overlap check on same service_date for active trips
    bus_overlap = (
        db.query(Trip)
        .filter(
            Trip.id != trip.id,
            Trip.bus_id == bus.id,
            Trip.service_date == trip.service_date,
            Trip.status.in_(ACTIVE_TRIP_STATUSES),
            Trip.departure_at < trip.estimated_arrival_at,
            Trip.estimated_arrival_at > trip.departure_at,
        )
        .first()
    )
    if bus_overlap:
        raise api_error(
            status.HTTP_409_CONFLICT,
            "BUS_ASSIGNMENT_CONFLICT",
            f"Bus '{bus.bus_no}' overlaps with trip {bus_overlap.trip_no}",
        )

    driver_overlap = (
        db.query(Trip)
        .filter(
            Trip.id != trip.id,
            Trip.driver_id == driver.id,
            Trip.service_date == trip.service_date,
            Trip.status.in_(ACTIVE_TRIP_STATUSES),
            Trip.departure_at < trip.estimated_arrival_at,
            Trip.estimated_arrival_at > trip.departure_at,
        )
        .first()
    )
    if driver_overlap:
        raise api_error(
            status.HTTP_409_CONFLICT,
            "DRIVER_ASSIGNMENT_CONFLICT",
            f"Driver '{driver.name}' overlaps with trip {driver_overlap.trip_no}",
        )

    trip.bus_id = bus.id
    trip.driver_id = driver.id
    if trip.status == "Scheduled":
        trip.status = "Assigned"
    if bus.status == "Available":
        bus.status = "Assigned"
    if driver.status == "Available":
        driver.status = "Assigned"

    db.add(
        AssignmentHistory(
            trip_id=trip.id, bus_id=bus.id, driver_id=driver.id, changed_by=actor.id, reason=reason
        )
    )
    db.add(
        TripEvent(
            trip_id=trip.id,
            event_type="assignment",
            actor_id=actor.id,
            note=f"Assigned {bus.bus_no} & {driver.name} ({reason})",
        )
    )
    write_audit(db, actor.id, "ASSIGN_TRIP", "Trip", trip.id, reason)
    create_notification(
        db,
        driver.user_id,
        f"Assigned to trip {trip.trip_no} with bus {bus.bus_no} on {trip.service_date.isoformat()}.",
    )
    db.commit()
    return trip


def _release_idle_resources(db: Session, trip: Trip) -> None:
    if trip.bus_id:
        active_cnt = db.query(Trip).filter(
            Trip.id != trip.id, Trip.bus_id == trip.bus_id, Trip.status.in_(ACTIVE_TRIP_STATUSES)
        ).count()
        if active_cnt == 0:
            bus = db.query(Bus).filter(Bus.id == trip.bus_id).first()
            if bus and bus.status == "Assigned":
                bus.status = "Available"

    if trip.driver_id:
        active_cnt = db.query(Trip).filter(
            Trip.id != trip.id, Trip.driver_id == trip.driver_id, Trip.status.in_(ACTIVE_TRIP_STATUSES)
        ).count()
        if active_cnt == 0:
            drv = db.query(Driver).filter(Driver.id == trip.driver_id).first()
            if drv and drv.status == "Assigned":
                drv.status = "Available"


def change_trip_status(db: Session, trip_id: int, new_status: str, reason: str, actor: User) -> Trip:
    trip = db.query(Trip).filter(Trip.id == trip_id).first()
    if not trip:
        raise api_error(status.HTTP_404_NOT_FOUND, "NOT_FOUND", "Trip not found")
    if new_status == trip.status:
        return trip

    if new_status not in ALLOWED_TRIP_TRANSITIONS.get(trip.status, set()):
        raise api_error(
            status.HTTP_409_CONFLICT,
            "INVALID_STATUS_TRANSITION",
            f"Cannot transition from {trip.status} to {new_status}",
        )
    if new_status in ("Assigned", "Boarding", "In Progress") and (not trip.bus_id or not trip.driver_id):
        raise api_error(
            status.HTTP_400_BAD_REQUEST,
            "MISSING_ASSIGNMENT",
            "Bus and driver must be assigned first",
        )

    old_status = trip.status
    trip.status = new_status
    now = datetime.now(timezone.utc)
    if new_status == "In Progress" and not trip.actual_departure_at:
        trip.actual_departure_at = now
    elif new_status == "Completed":
        trip.actual_departure_at = trip.actual_departure_at or now
        trip.actual_arrival_at = now
    if new_status in ("Completed", "Cancelled"):
        _release_idle_resources(db, trip)

    db.add(
        TripEvent(
            trip_id=trip.id,
            event_type="status_change",
            actor_id=actor.id,
            note=f"{old_status} -> {new_status}: {reason}",
        )
    )
    write_audit(db, actor.id, "UPDATE_TRIP_STATUS", "Trip", trip.id, reason)
    if new_status == "Cancelled":
        affected = (
            db.query(Booking)
            .filter(
                Booking.trip_id == trip.id,
                Booking.status == "Confirmed",
                Booking.passenger_user_id.is_not(None),
            )
            .all()
        )
        for uid in {b.passenger_user_id for b in affected if b.passenger_user_id}:
            create_notification(
                db,
                uid,
                f"Trip {trip.trip_no} was cancelled ({reason}). Please review your booking.",
            )
    db.commit()
    return trip


def log_trip_event(db: Session, trip_id: int, data: TripEventCreate, actor: User) -> TripEvent:
    trip = db.query(Trip).options(joinedload(Trip.bus)).filter(Trip.id == trip_id).first()
    if not trip:
        raise api_error(status.HTTP_404_NOT_FOUND, "NOT_FOUND", "Trip not found")

    if actor.role and actor.role.name == ROLE_DRIVER:
        if not actor.driver_profile or trip.driver_id != actor.driver_profile.id:
            raise api_error(status.HTTP_403_FORBIDDEN, "FORBIDDEN", "Drivers can only update their own trips")

    if trip.status == "Cancelled":
        raise api_error(status.HTTP_409_CONFLICT, "TRIP_CANCELLED", "Trip is cancelled")

    if data.passenger_count is not None:
        if trip.bus and data.passenger_count > trip.bus.capacity:
            raise api_error(
                status.HTTP_400_BAD_REQUEST,
                "PASSENGER_COUNT_EXCEEDS_CAPACITY",
                f"Passenger count ({data.passenger_count}) exceeds bus capacity ({trip.bus.capacity})",
            )
        trip.passenger_count = data.passenger_count

    if data.event_type == "delay" and not data.delay_category:
        raise api_error(status.HTTP_400_BAD_REQUEST, "DELAY_CATEGORY_REQUIRED", "Delay category is required")

    now = datetime.now(timezone.utc)
    if data.event_type == "departure":
        trip.actual_departure_at = trip.actual_departure_at or now
        if trip.status in ("Scheduled", "Assigned", "Boarding"):
            trip.status = "In Progress"
    elif data.event_type == "delay":
        trip.status = "Delayed"
    elif data.event_type == "arrival":
        trip.actual_departure_at = trip.actual_departure_at or now
        trip.actual_arrival_at = now
        trip.status = "Completed"
        _release_idle_resources(db, trip)

    ev = TripEvent(
        trip_id=trip.id,
        event_type=data.event_type,
        delay_category=data.delay_category,
        passenger_count=data.passenger_count,
        note=data.note,
        actor_id=actor.id,
        timestamp=now,
    )
    db.add(ev)
    write_audit(db, actor.id, "RECORD_TRIP_EVENT", "Trip", trip.id, data.note or data.event_type)
    db.commit()
    db.refresh(ev)
    return ev


# ==============================================================================
# SECTION 4: BOOKINGS & CAPACITY LOCKING
# ==============================================================================

def get_booked_seats(db: Session, trip_id: int) -> int:
    total = (
        db.query(func.coalesce(func.sum(Booking.quantity), 0))
        .filter(Booking.trip_id == trip_id, Booking.status.in_(("Confirmed", "Completed")))
        .scalar()
    )
    return int(total or 0)


def create_demo_booking(
    db: Session,
    trip_id: int,
    passenger_name: str,
    contact_demo: str,
    quantity: int,
    idempotency_key: str | None,
    actor: User,
) -> Booking:
    if idempotency_key:
        existing = db.query(Booking).filter(Booking.idempotency_key == idempotency_key).first()
        if existing:
            return existing

    # Lock trip row for concurrent booking safety
    bind = db.get_bind()
    if bind and bind.dialect.name == "sqlite":
        if not db.in_transaction():
            db.begin()
        db.execute(text("UPDATE trips SET id = id WHERE id = :tid"), {"tid": trip_id})
        trip = db.query(Trip).options(joinedload(Trip.bus), joinedload(Trip.schedule)).filter(Trip.id == trip_id).first()
    else:
        trip = (
            db.query(Trip)
            .options(joinedload(Trip.bus), joinedload(Trip.schedule))
            .filter(Trip.id == trip_id)
            .with_for_update()
            .first()
        )

    if not trip:
        raise api_error(status.HTTP_404_NOT_FOUND, "NOT_FOUND", "Trip not found")
    if not trip.schedule.published or not trip.schedule.active or trip.status in ("Cancelled", "Completed"):
        raise api_error(status.HTTP_409_CONFLICT, "TRIP_NOT_BOOKABLE", "Trip is not open for bookings")
    if not trip.bus:
        raise api_error(status.HTTP_400_BAD_REQUEST, "NO_BUS_ASSIGNED", "No bus assigned to trip yet")

    remaining = trip.bus.capacity - get_booked_seats(db, trip.id)
    if quantity > remaining:
        raise api_error(
            status.HTTP_409_CONFLICT,
            "CAPACITY_EXCEEDED",
            f"Requested {quantity} seat(s), but only {max(0, remaining)} remain",
            {"remaining_seats": max(0, remaining)},
        )

    is_passenger = actor.role and actor.role.name == ROLE_PASSENGER
    booking = Booking(
        booking_ref=f"BK-{trip.service_date.strftime('%Y%m%d')}-{secrets.token_hex(3).upper()}",
        trip_id=trip.id,
        passenger_user_id=actor.id if is_passenger else None,
        passenger_name=passenger_name.strip(),
        contact_demo=contact_demo.strip(),
        quantity=quantity,
        total_fare=trip.fare_snapshot * quantity,
        status="Confirmed",
        payment_status_demo="Demo Paid",
        idempotency_key=idempotency_key,
    )
    db.add(booking)
    db.flush()
    write_audit(db, actor.id, "CREATE_BOOKING", "Booking", booking.id, booking.booking_ref)
    if booking.passenger_user_id:
        create_notification(
            db,
            booking.passenger_user_id,
            f"Booking {booking.booking_ref} confirmed for trip {trip.trip_no} ({booking.quantity} seat(s)).",
        )
    db.commit()
    db.refresh(booking)
    return booking


def cancel_demo_booking(db: Session, booking_id: int, reason: str, actor: User) -> Booking:
    booking = db.query(Booking).options(joinedload(Booking.trip)).filter(Booking.id == booking_id).first()
    if not booking:
        raise api_error(status.HTTP_404_NOT_FOUND, "NOT_FOUND", "Booking not found")

    if actor.role and actor.role.name == ROLE_PASSENGER and booking.passenger_user_id != actor.id:
        raise api_error(status.HTTP_403_FORBIDDEN, "FORBIDDEN", "Passengers can only cancel their own bookings")
    if booking.status != "Confirmed":
        raise api_error(status.HTTP_409_CONFLICT, "INVALID_BOOKING_STATE", f"Booking is already {booking.status}")

    now = datetime.now(timezone.utc)
    cutoff = utc_aware(booking.trip.departure_at) - timedelta(minutes=settings.BOOKING_CANCEL_CUTOFF_MINUTES)
    if booking.trip.status != "Cancelled" and now > cutoff:
        raise api_error(
            status.HTTP_400_BAD_REQUEST,
            "CANCELLATION_CUTOFF_PASSED",
            f"Cancellation closed {settings.BOOKING_CANCEL_CUTOFF_MINUTES} minutes prior to departure",
        )

    booking.status = "Cancelled"
    booking.payment_status_demo = "Demo Refunded"
    booking.cancellation_reason = reason
    booking.cancelled_by = actor.id
    booking.cancelled_at = now
    write_audit(db, actor.id, "CANCEL_BOOKING", "Booking", booking.id, reason)
    if booking.passenger_user_id:
        create_notification(
            db,
            booking.passenger_user_id,
            f"Booking {booking.booking_ref} cancelled (Demo Refunded).",
        )
    db.commit()
    db.refresh(booking)
    return booking


# ==============================================================================
# SECTION 5: DASHBOARD SUMMARY
# ==============================================================================

def build_dashboard_summary(db: Session, target_date: date) -> dict:
    trips = (
        db.query(Trip)
        .options(joinedload(Trip.schedule).joinedload(Schedule.route))
        .filter(Trip.service_date == target_date)
        .all()
    )
    trip_ids = [t.id for t in trips]
    bookings = db.query(Booking).filter(Booking.trip_id.in_(trip_ids)).all() if trip_ids else []
    valid_bookings = [b for b in bookings if b.status in ("Confirmed", "Completed")]

    route_map = {t.id: t.schedule.route for t in trips if t.schedule and t.schedule.route}
    by_route: dict[str, dict] = {}
    for b in valid_bookings:
        rt = route_map.get(b.trip_id)
        if not rt:
            continue
        bucket = by_route.setdefault(
            rt.route_code,
            {"route_code": rt.route_code, "route_name": rt.name, "booking_count": 0, "seats_booked": 0, "revenue_demo": 0.0},
        )
        bucket["booking_count"] += 1
        bucket["seats_booked"] += b.quantity
        bucket["revenue_demo"] += float(b.total_fare)

    buses = db.query(Bus).filter(Bus.active.is_(True)).all()
    drivers = db.query(Driver).filter(Driver.active.is_(True)).all()
    events = (
        db.query(TripEvent)
        .options(joinedload(TripEvent.trip), joinedload(TripEvent.actor))
        .order_by(TripEvent.timestamp.desc())
        .limit(8)
        .all()
    )

    return {
        "today": target_date,
        "scheduled_trips": len(trips),
        "completed_trips": sum(1 for t in trips if t.status == "Completed"),
        "delayed_trips": sum(1 for t in trips if t.status == "Delayed"),
        "cancelled_trips": sum(1 for t in trips if t.status == "Cancelled"),
        "total_bookings": len(valid_bookings),
        "total_passengers_booked": sum(b.quantity for b in valid_bookings),
        "total_buses": len(buses),
        "available_buses": sum(1 for b in buses if b.status == "Available"),
        "maintenance_buses": sum(1 for b in buses if b.status == "Maintenance"),
        "total_drivers": len(drivers),
        "available_drivers": sum(1 for d in drivers if d.status == "Available"),
        "unassigned_trips": sum(1 for t in trips if (not t.bus_id or not t.driver_id) and t.status != "Cancelled"),
        "revenue_demo": sum((b.total_fare for b in valid_bookings), Decimal("0.00")),
        "bookings_by_route": sorted(by_route.values(), key=lambda x: x["route_code"]),
        "recent_events": [
            {
                "id": e.id,
                "trip_no": e.trip.trip_no if e.trip else str(e.trip_id),
                "event_type": e.event_type,
                "delay_category": e.delay_category,
                "note": e.note,
                "actor_name": e.actor.name if e.actor else "System",
                "timestamp": e.timestamp.isoformat(),
            }
            for e in events
        ],
    }
