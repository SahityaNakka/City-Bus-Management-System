import os
import subprocess
import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
VENV_PYTHON = BASE_DIR / ".venv" / "Scripts" / "python.exe"

# If invoked with system Python, automatically switch to the project's virtual environment
if VENV_PYTHON.is_file() and Path(sys.executable).resolve() != VENV_PYTHON.resolve():
    os.chdir(BASE_DIR)
    sys.exit(subprocess.call([str(VENV_PYTHON), str(Path(__file__).resolve()), *sys.argv[1:]]))

os.chdir(BASE_DIR)
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

import uvicorn

from app.seed import run_seed

if __name__ == "__main__":
    run_seed()
    print("\n" + "=" * 60)
    print("CityTransit Web App : http://127.0.0.1:8000/")
    print("Swagger API Docs    : http://127.0.0.1:8000/docs")
    print("=" * 60 + "\n")
    uvicorn.run(
        "app.main:app",
        host="127.0.0.1",
        port=8000,
        reload=os.getenv("UVICORN_RELOAD") == "1",
    )
